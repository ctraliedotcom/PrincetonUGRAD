%patchNum is the number of random 11x11x3 patches to take out of
%each training image and test image
%CodeBookNum is Number of clusters to take in kmeans during training
%usecorners is 1 if the trainer should use corners as patches, and 0 if it
%should be completely random
function [ ConfusionMatrix ] = ImClassify( patchNum, CodeBookNum, distanceType, useCorners )
%Define all of the parameters to be used
basepath = 'images';
classes = {'airplane', 'butterfly', 'camera', 'helicopter', 'lotus','panda', 'pizza', 'pyramid', 'snoopy', 'yin_yang'};
ImPerClass = 30;
TrainNum = 10;%Number of images to take out of each class and make the
%training set

%Load in all images
numClasses = size(classes);
numClasses = numClasses(2);

fprintf(1, 'Loading images...\n\n');
for class = 1:numClasses
    for num = 1:ImPerClass
       %TODO: Preallocate space for the list
       images{class}{num} = imread(sprintf('%s\\%s\\image_%.4i.jpg', basepath, classes{class}, num));
       imsize = size(size(images{class}{num}));
       if (imsize(2) == 3)
          %If the image is RGB, convert it to grayscale
          images{class}{num} = rgb2gray(images{class}{num});
       end
       %Normalize for numerical computations
       images{class}{num} = double(images{class}{num}) / 255.0;
    end
end
fprintf(1, 'Finished loading images.\n\n');

[CodeBook, ClassHist] = TrainCodeBook( numClasses, TrainNum, patchNum, CodeBookNum, images, distanceType, useCorners );

OutputCodeBook(CodeBook);

%Now try to classify the remaining images in the test set using Naive Bayes
ConfusionMatrix = zeros(numClasses, numClasses);
fprintf(1, 'Beginning image classification phase...\n\n');
for class = 1:numClasses
   %The test set consists of all images not in the training set
   for num = TrainNum+1:ImPerClass
       classGuess = estimateClass(images{class}{num}, CodeBook, ClassHist, patchNum, distanceType, useCorners);
       ConfusionMatrix(classGuess, class) = ConfusionMatrix(classGuess, class) + 1;
   end
end
ConfusionMatrix = ConfusionMatrix / double(ImPerClass - TrainNum);
fprintf(1, '\nFinished image classification phase\n\n');

end

