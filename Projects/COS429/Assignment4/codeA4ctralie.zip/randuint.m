function [ out ] = randuint( start, finish )
val = start + (finish - start)*rand();
out = uint32(val);
end

