%Roll the 1D codewords back into 2D images and output them as a png file
function [ ] = OutputCodeBook( CodeBook )
cbsize = size(CodeBook);
im = zeros(11 * cbsize(1), 11);
for i = 1:cbsize(1)
    image = zeros(11, 11);
    for row = 1:11
       image(row, :) = CodeBook(i, 1 + (row - 1)*11 : row*11); 
    end
    im(1 + (i - 1)*11 : i*11, 1:11) = image;
end

imsize = size(im);
while mod(imsize(1), 2) == 0
   half = imsize(1) / 2;
   im1 = im(1:half, 1:imsize(2));
   im2 = im(half+1:imsize(1), 1:imsize(2));
   im = [im1 im2];
   imsize = size(im);
end

imwrite(im, 'codebook.png', 'png');

end