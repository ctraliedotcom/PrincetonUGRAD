function [ MAPClass ] = estimateClass( image, CodeBook, ClassHist, patchNum, distanceType, useCorners)
histSize = size(ClassHist);
PixelDim = size(image);
%For each image in test set:
%Set the (un-normalized) probability of each class to 1
ClassProb = ones(histSize(1), 1);
CBSize = size(CodeBook);
%For each of n randomly-selected patches:
if useCorners == 1
    [Fx, Fy, MagGrad, EdgeOrient] = CannyGradient(image, 1);
    [eigs] = CornerFind(Fx, Fy, 5, 0.1);
end
for i = 1:patchNum
    if useCorners == 1
        if eigs(i) > 0.05
             row = eigs(i, 2);
             col = eigs(i, 3);
             if row < 50 || row > PixelDim(1) - 50 || col < 50 || col > PixelDim(2) - 50
                patch = getRandPatch(image, 11);
             else
                sample = image(row - 5:row + 5, col - 5:col + 5);
                patch = sample(:);
             end
        else
             patch = getRandPatch(image, 11);
        end
    else
        patch = getRandPatch(image, 11);
    end
    if (strcmp(distanceType, 'sqEuclidean') == 1)
        %Find the the nearest codeword in the codebook, minimizing squared
        %euclidean distance
        compare = CodeBook - ones(CBSize(1), 1) * patch';
        compare = compare .* compare;
        compare = sum(compare');
    end
    if (strcmp(distanceType, 'cityblock') == 1)
        compare = CodeBook - ones(CBSize(1), 1) * patch';
        compare = abs(compare);
        compare = sum(compare');
    end
    [~, codeword] = min(compare);
    
    %multiply the probability of each class by one plus the count of the
    %most likely codeword in the class's histogram
    ClassProb = ClassProb .* (1 + ClassHist(:, codeword));
end
%Select the class with the Maximum A Posteriori (MAP) probability.
[~, MAPClass] = max(ClassProb);
end

