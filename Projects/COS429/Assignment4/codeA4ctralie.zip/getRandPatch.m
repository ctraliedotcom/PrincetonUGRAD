%image is a grayscale image
%dim is the dimension of the square to sample
%Sample a dim X dim RGB image and roll it out into a 1D vector
function [ sampleVec ] = getRandPatch( image, dim )
pixelDim = size(image);
if (pixelDim(1) < dim || pixelDim(2) < dim)
    fprintf(1, 'ERROR: Image dimension less than patch size\n\n');
end
maxX = pixelDim(2) - dim;
maxY = pixelDim(1) - dim;
startX = randuint(1, maxX);
startY = randuint(1, maxY);
sample = image(startY:startY+dim-1, startX:startX+dim-1);
sampleVec = double(sample);%Convert to normalized grayscale
sampleVec = sampleVec(:);
end

