function [ CodeBook, ClassHist ] = TrainCodeBook( numClasses, TrainNum, patchNum, CodeBookNum, images, distanceType, useCorners )
fprintf(1, 'Training on %i random patches per training image...\n\n', patchNum);
%Randomly select n patches of size 11x11x3 from each training image (stored
%as 1x11*11 vectors)
%Preallocate space to hold the patches
patches = zeros(numClasses*TrainNum*patchNum, 11*11);
index = 1;
for class = 1:numClasses
   for num = 1:TrainNum
      im = images{class}{num};
      PixelDim = size(im);
      if useCorners == 1
          fprintf(1, '\n\n');
          [Fx, Fy, MagGrad, EdgeOrient] = CannyGradient(im, 1);
          [eigs] = CornerFind(Fx, Fy, 5, 0.1);
          for i = 1:patchNum
              if eigs(i) > 0.05
                 row = eigs(i, 2);
                 col = eigs(i, 3);
                 %Try to keep the corners towards the center of the image
                 %(since some of the images are bordered by some constant
                 %color, which would fire the corner detector)
                 if row < 50 || row > PixelDim(1) - 50 || col < 50 || col > PixelDim(2) - 50
                    patches(index, :) = getRandPatch(im, 11);
                 else
                    fprintf(1, '%i, %i\n', row, col);
                    sample = im(row - 5:row + 5, col - 5:col + 5);
                    patches(index, :) = sample(:);
                 end
             else %If the corner is too weak, get a random patch instead
                 patches(index, :) = getRandPatch(im, 11); 
              end
              index = index + 1;
          end
      else
          for i = 1:patchNum
              sample = getRandPatch(im, 11);
              patches(index, :) = sample;
              index = index + 1;
          end
      end
   end
end
fprintf(1, 'Finished getting random patches.\n\n');

%Now run kmeans 
fprintf(1, 'Starting kmeans clustering...\n\n');
[IDX, CodeBook] = kmeans(patches, CodeBookNum, 'Distance', distanceType, 'emptyaction', 'singleton');
fprintf(1, 'Finished kmeans clustering.\n\n');

%Learn a patch histogram for each class with the info from kmeans;
%Find the nearest vector in the codebook, and increment a counter
%for that codeword's entry in a 100-dimensional histogram for the class
ClassHist = zeros(numClasses, CodeBookNum);
%Index the histogram by class first, then codeword within each class
index = 1;
for class = 1:numClasses
  for num = 1:TrainNum
     for i = 1:patchNum
         ClassHist(class, IDX(index)) = ClassHist(class, IDX(index)) + 1;
         index = index + 1;
     end
  end
end

end