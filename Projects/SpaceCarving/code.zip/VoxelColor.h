#ifndef VOXELCOLOR_H
#define VOXELCOLOR_H

#include <stdio.h>
#include <stdlib.h>
#include <vector>
#include <CImg.h>
#include "Camera.h"
#include "TNT_Utils.h"
#include "Voxel.h"
#include "VoxelCloud.h"
#include "Ransac.h"

#define LUMINANCE_THRESH 20

class VoxelColor {
public:
	VoxelColor(double sx, double sy, double sz, uint rx, uint ry, uint rz, double vr, double stdev);
	~VoxelColor();


	vector<struct Pixel> getPixels(int camera, double wX, double wY, double wZ, bool projectCenter);
	struct Pixel checkConsistency();
	int doColoring();

	uint resx, resy, resz;
	double vres;//The length of a side of a voxel (in cm)
	double max_stdev;//The maximum standard devation of color to accept voxel
	double startx, starty, startz;
	uint colored;

	//Voxel Coloring variables
	VoxelCloud* voxels;
	vector<Camera*> cameras;
	vector<struct Pixel> projPixels;//All of the pixels from all different 
	//cameras to which a particular voxel projects
};

#endif
