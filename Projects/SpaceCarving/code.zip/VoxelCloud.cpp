#include "VoxelCloud.h"
#include <stdio.h>
#include <stdlib.h>

VoxelCloud::VoxelCloud(uint rx, uint ry, uint rz, double csize) {
     resx = rx;
     resy = ry;
     resz = rz;
     cellsize = csize;
     //Allocate space for the data structure
     voxels = new Voxel[rx*ry*rz];
}

VoxelCloud::VoxelCloud(const char* filename) {
     FILE* fp = fopen(filename, "rb");
     if (fp == NULL) {
          fprintf(stderr, "ERROR: Opening file %s for voxel structure input\n", filename);
          return;
     }
     fread(&resx, sizeof(uint), 1, fp);
     fread(&resy, sizeof(uint), 1, fp);
     fread(&resz, sizeof(uint), 1, fp);
     fread(&cellsize, sizeof(double), 1, fp);
     voxels = new Voxel[resx*resy*resz];
     fread(voxels, sizeof(Voxel), resx*resy*resz, fp);
     fclose(fp);
}

VoxelCloud::~VoxelCloud() {
     delete[] voxels;
}

Voxel* VoxelCloud::voxelAt(uint x, uint y, uint z) {
     //Convert a 3D index to a 1D index
     uint index = (x + resx*y)*resz + z;
     return &voxels[index];
}

void VoxelCloud::write(const char* filename) {
     FILE* fp = fopen(filename, "wb");
     if (fp == NULL) {
          fprintf(stderr, "ERROR: Opening file %s for voxel structure output\n", filename);
          return;
     }
     fwrite(&resx, sizeof(uint), 1, fp);
     fwrite(&resy, sizeof(uint), 1, fp);
     fwrite(&resz, sizeof(uint), 1, fp);
     fwrite(&cellsize, sizeof(double), 1, fp);
     fwrite(voxels, sizeof(Voxel), resx*resy*resz, fp);
     fclose(fp);
}
