// Include files for R3 package
#ifndef R3_INCLUDED
#define R3_INCLUDED



#ifdef _WIN32
#include <windows.h>
#pragma warning(disable:4996)
#endif

// Dependency include files 

#include <stdio.h>
#include <stdlib.h>
#include <stdarg.h>
#include <assert.h>
#include <string.h>
#include <math.h>
#include <limits.h>
#ifdef __APPLE__
#include <OpenGL/gl.h>
#include <OpenGL/glu.h>
#else
#include <GL/gl.h>
#include <GL/glu.h>
#endif


// Constant declarations

#define R3_X 0
#define R3_Y 1
#define R3_Z 2



// Class declarations

class R3Point;
class R3Vector;
class R3Line;
class R3Ray;
class R3Segment;
class R3Plane;
class R3Box;
class R3Sphere;
class R3Matrix;



// Class include files

#include "R3Point.h"
#include "R3Vector.h"
#include "R3Line.h"
#include "R3Ray.h"
#include "R3Segment.h"
#include "R3Plane.h"
#include "R3Box.h"
#include "R3Matrix.h"



// Utility include files

#include "R3Distance.h"



#endif
