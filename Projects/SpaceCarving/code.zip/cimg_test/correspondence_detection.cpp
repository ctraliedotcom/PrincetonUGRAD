#include "CImg.h"
#include <vector>
#include <iostream>
#include <sstream>
#include <fstream> 
#include <tnt/tnt.h>
#include <jama/jama_eig.h>
#include <boost/shared_ptr.hpp>
#include <sys/stat.h>

using namespace cimg_library;
using namespace std;

class Point2D;
class ColorDist;
class HistDist;
class ColorHist;
class VideoImage;

typedef unsigned int uint;
typedef unsigned char u8;
typedef boost::shared_ptr<Point2D> Point2DPtr;
typedef boost::shared_ptr<ColorDist> ColorDistPtr;
typedef boost::shared_ptr<ColorHist> ColorHistPtr;
typedef boost::shared_ptr<vector<ColorHistPtr> > VectColorHistPtr;
typedef boost::shared_ptr<HistDist> HistDistPtr;
typedef boost::shared_ptr<CImg<u8> > CImgPtr;
typedef boost::shared_ptr<VideoImage> VideoImagePtr;

// colors
u8 c_red[] = {255, 0, 0};
u8 c_green[] = {0, 255, 0};
u8 c_blue[] = {0, 0, 255};
u8 c_yellow[] = {255, 255, 0};
u8 c_magenta[] = {255, 0, 255};
u8 c_cyan[] = {0, 255, 255};
u8 c_white[] = {255, 255, 255};
u8 c_black[] = {0, 0, 0};
u8 c_gray[] = {150, 150, 150};

enum { D_HIST, D_PERIM_HIST, D_N_PERIM_HIST};
enum { E_RED=0, E_GREEN=1, E_BLUE=2, E_YELLOW=3, E_MAGENTA=4, E_CYAN=5 };
u8* colors[] = {c_red, c_green, c_blue, c_yellow, c_magenta, c_cyan};
u8* display_order[] = {c_red, c_white, c_magenta, c_blue, c_cyan, c_green, c_gray, c_black};

class Descriptor {
public:
  uint frame_num;
  uint x;
  uint y;

  Descriptor() :
    frame_num(0), x(0), y(0) { }
};

class VideoImage {
public:
  uint frame_num;
  CImgPtr image;

  VideoImage(uint frame_num, CImgPtr image) :
    frame_num(frame_num), image(image) { }
};

class ColorHist: public Descriptor {
public:
  uint colors[6];

  ColorHist() {
    for (uint i=0; i<6; i++) {
      colors[i] = 0;
    }
  }
};

class ColorChain {
public:
  vector<u8> colors;

  void add_color(u8 color);
  ColorHistPtr calculate_hist();
};

void ColorChain::add_color(u8 color) {
  colors.push_back(color);
}

ColorHistPtr ColorChain::calculate_hist() {
  ColorHistPtr hist = ColorHistPtr(new ColorHist());
  if (colors.size() == 0) {
    return hist;
  }

  uint start=0,end=0;

  u8 cur_color = colors[0];
  uint count=1;
  // calculate first color
  for (uint i=1; i<colors.size(); i++) {
    if (colors[i] == cur_color) {
      count++;
    }
    else {
      start = i;
      break;
    }
  }
  // check for first color in opposite direction from back of array
  for (uint i=colors.size()-1; i>start; i--) {
    if (colors[i] == cur_color) {
      count++;
    }
    else {
      end = i;
      break;
    }
  }
  hist->colors[cur_color] = count;

  // only 1 color
  if (start==end) {
    return hist;
  }

  cur_color = colors[start];
  count = 1;
  for (uint i=start; i<=end; i++) {
    if (colors[i] == cur_color) {
      count++;
    }
    else {
      if (count > hist->colors[cur_color]) {
        hist->colors[cur_color] = count;
      }
      cur_color = colors[i];
      count = 1;
    }
  }

  if (count > hist->colors[cur_color]) {
    hist->colors[cur_color] = count;
  }

  return hist;
}

/* Helper class used for sorting points by the small eigenvalue of the covariance matrix */
class Point2D {
public:
  uint x;
  uint y;
  double I2; // small eigenvalue of covariance matrix of neighborhood around point
  u8 corner_type;

  Point2D(int x, int y, double I2) :
    x(x), y(y), I2(I2) { }

  static bool sort_points(Point2DPtr, Point2DPtr);

  bool in_neighborhood(Point2D&, uint);
};

bool Point2D::sort_points(Point2DPtr A, Point2DPtr B) {
  return A->I2 > B->I2;
}

bool Point2D::in_neighborhood(Point2D& pt, uint nwidth) {
  if (abs(this->x - pt.x) <= nwidth && abs(this->y - pt.y) <= nwidth) {
    return true;
  }
  else {
    return false;
  }
}

/* Helper class used for sorting color distances */
class ColorDist {
public:
  u8 color;
  uint dist;
  
  ColorDist(u8 color, uint dist) :
    color(color), dist(dist) { }

  ColorDist(u8 color, u8* c1, u8* c2) :
    color(color), dist(calc_color_dist(c1,c2)) {}

  static bool sort_color_dist(ColorDistPtr, ColorDistPtr);

  static uint calc_color_dist(u8* c1, u8* c2);
};

bool ColorDist::sort_color_dist(ColorDistPtr A, ColorDistPtr B) {
  return A->dist < B->dist;
}

/* Returns the squared Euclidean distance between colors */
uint ColorDist::calc_color_dist(u8* c1, u8* c2) {
  uint dist = 0;
  for (int i=0; i < 3; i++) {
    dist += pow((int)c1[i]-(int)c2[i],2);
  }
  return dist;
}

/* Helper class used for calculating and sorting histogram distances */
class HistDist {
public:
  u8 corner_type;
  uint dist;
  
  HistDist(u8 corner_type, uint dist) :
    corner_type(corner_type), dist(dist) { }

  HistDist(u8 corner_type, ColorHistPtr hist1, ColorHistPtr hist2) :
    corner_type(corner_type), dist(calc_hist_dist(hist1,hist2)) {}

  static bool sort_hist_dist(HistDistPtr, HistDistPtr);

  static uint calc_hist_dist(ColorHistPtr, ColorHistPtr);
};

bool HistDist::sort_hist_dist(HistDistPtr A, HistDistPtr B) {
  return A->dist < B->dist;
}

/* Returns the squared Euclidean distance between histograms */
uint HistDist::calc_hist_dist(ColorHistPtr hist1, ColorHistPtr hist2) {
  uint dist = 0;
  for (int i=0; i < 6; i++) {
    dist += pow((int)hist1->colors[i]-(int)hist2->colors[i],2);
  }
  return dist;
}

u8 calc_nearest_color(u8 R, u8 G, u8 B, uint& dist) {
  u8 color[] = {R, G, B};

  // Calculate squared euclidean distance to each reference color
  vector<ColorDistPtr> dists;
  dists.push_back(ColorDistPtr(new ColorDist(E_RED, c_red, color)));
  dists.push_back(ColorDistPtr(new ColorDist(E_GREEN, c_green, color)));
  dists.push_back(ColorDistPtr(new ColorDist(E_BLUE, c_blue, color)));
  dists.push_back(ColorDistPtr(new ColorDist(E_YELLOW, c_yellow, color)));
  dists.push_back(ColorDistPtr(new ColorDist(E_MAGENTA, c_magenta, color)));
  dists.push_back(ColorDistPtr(new ColorDist(E_CYAN, c_cyan, color)));

  sort(dists.begin(),
       dists.end(),
       ColorDist::sort_color_dist);

  dist = dists[0]->dist;
  return dists[0]->color;
}

/* Create a histogram of perimeter pixels in cnwidth x cnwidth grid around specified corner point.
   Note that histogram values correspond to the max length of chains of pixels of that color */
ColorHistPtr create_neighbor_perim_histogram(CImg<u8>& img, uint x, uint y, uint cnwidth, uint cdist_threshold) {
  ColorHistPtr hist = ColorHistPtr(new ColorHist());
  uint x2 = x - cnwidth;
  uint y2 = y - cnwidth;

  ColorChain CC;

  // trace around the perimeter
  do {
    if (y2 == y - cnwidth && x2 != x+cnwidth) {
      x2++;
    }
    else if (x2 == x+cnwidth && y2 != y+cnwidth) {
      y2++;
    }
    else if (y2 == y+cnwidth && x2 != x-cnwidth) {
      x2--;
    }
    else if (x2 == x-cnwidth) {
      y2--;
    }
    
    uint dist;
    u8 nc = calc_nearest_color(img(x2,y2,E_RED), img(x2,y2,E_GREEN), img(x2,y2,E_BLUE), dist);
    if (dist < cdist_threshold) {
      CC.add_color(nc);
    }
  } while (x2 != (x - cnwidth) || y2 != (y - cnwidth));
  return CC.calculate_hist();;
}

/* Calculates perim histogram values, discarding the coordinates and frame_num since they aren't needed anymore */
void calculate_neighbor_perim_histogram(vector<VideoImagePtr>& video, ColorHistPtr& hist, uint cnwidth, uint cdist_threshold) {
  uint frame=0;
  for (uint f=0; f < video.size(); f++) {
    if (video[f]->frame_num == hist->frame_num) {
      frame = f;
      break;
    }
  }

  hist = create_neighbor_perim_histogram(*(video[frame]->image), hist->x, hist->y, cnwidth, cdist_threshold);
}

/* Create a histogram of perimeter pixels in cnwidth x cnwidth grid around specified corner point  */
ColorHistPtr create_perim_histogram(CImg<u8>& img, uint x, uint y, uint cnwidth, uint cdist_threshold) {
  ColorHistPtr hist = ColorHistPtr(new ColorHist());
  uint x2 = x - cnwidth;
  uint y2 = y - cnwidth;
  // trace around the perimeter
  do {
    if (y2 == y - cnwidth && x2 != x+cnwidth) {
      x2++;
    }
    else if (x2 == x+cnwidth && y2 != y+cnwidth) {
      y2++;
    }
    else if (y2 == y+cnwidth && x2 != x-cnwidth) {
      x2--;
    }
    else if (x2 == x-cnwidth) {
      y2--;
    }

    uint dist;
    u8 color = calc_nearest_color(img(x2,y2,E_RED), img(x2,y2,E_GREEN), img(x2,y2,E_BLUE), dist);
    if (dist < cdist_threshold) {
      hist->colors[color]++;
    }
  } while (x2 != (x - cnwidth) || y2 != (y - cnwidth));
  return hist;
}

/* Calculates perim histogram values, discarding the coordinates and frame_num since they aren't needed anymore */
void calculate_perim_histogram(vector<VideoImagePtr>& video, ColorHistPtr& hist, uint cnwidth, uint cdist_threshold) {
  uint frame=0;
  for (uint f=0; f < video.size(); f++) {
    if (video[f]->frame_num == hist->frame_num) {
      frame = f;
      break;
    }
  }

  hist = create_perim_histogram(*(video[frame]->image), hist->x, hist->y, cnwidth, cdist_threshold);
}

/* Create a histogram of pixels in cnwidth x cnwidth grid around specified corner point */
ColorHistPtr create_histogram(CImg<u8>& img, uint x, uint y, uint cnwidth, uint cdist_threshold) {
  ColorHistPtr hist = ColorHistPtr(new ColorHist());
  for (uint x2 = x - cnwidth; x2 <= x + cnwidth; x2++) {
    for (uint y2 = y - cnwidth; y2 <= y + cnwidth; y2++) {
      // create color vector for this point
      uint dist;
      u8 color = calc_nearest_color(img(x2,y2,E_RED), img(x2,y2,E_GREEN), img(x2,y2,E_BLUE), dist);

      // Increment the closest color in the histogram if it falls
      // within a specified threshold
      
      if (dist < cdist_threshold) {
        hist->colors[color]++;
      }
    }
  }
  return hist;
}

/* Calculates histogram values, discarding the coordinates and frame_num since they aren't needed anymore */
void calculate_histogram(vector<VideoImagePtr>& video, ColorHistPtr& hist, uint cnwidth, uint cdist_threshold) {
  int frame=-1;
  for (uint f=0; f < video.size(); f++) {
    if (video[f]->frame_num == hist->frame_num) {
      frame = f;
      break;
    }
  }
  if (frame >= 0) {
    hist = create_histogram(*(video[frame]->image), hist->x, hist->y, cnwidth, cdist_threshold);
  }
  else {
    cerr << "I can't find frame number " << hist->frame_num << " in memory." <<
            " You may be using the wrong point set for the given video file." << endl; 
  }
  //cout << hist2->colors[0] << hist2->colors[1] << hist2->colors[2] << hist2->colors[3] << endl;
}

// From http://www.techbytes.ca/techbyte103.html
bool FileExists(string strFilename) {
  struct stat stFileInfo;
  bool blnReturn;
  int intStat;

  // Attempt to get the file attributes
  intStat = stat(strFilename.c_str(),&stFileInfo);
  if(intStat == 0) {
    // We were able to get the file attributes
    // so the file obviously exists.
    blnReturn = true;
  } else {
    // We were not able to get the file attributes.
    // This may mean that we don't have permission to
    // access the folder which contains this file. If you
    // need to do that level of checking, lookup the
    // return values of stat which will give you
    // more details on why stat failed.
    blnReturn = false;
  }
  
  return(blnReturn);
}

/* If a file_name is specified, decompress the specified video into png files and
   load every xth frame corresponding to the skip_frames parameter. If no file_name
   is specified, load the images located in the frames directory. */
bool load_video(vector<VideoImagePtr>& video, const char* file_name, uint skip_frames) {
  if (strlen(file_name) > 0) {
    int r = system("rm -r frames");
    r = system("mkdir frames");
    stringstream video_to_frames;
    video_to_frames << "ffmpeg -i " << file_name << " ./frames/frame%06d.png";
    cout << "decompressing video to frames..." << endl;
    r = system(video_to_frames.str().c_str());
    cout << "finished decompressing video." << endl;
  }
  else {
    if (!FileExists("frames")) {
      cerr << "You must load a video file or already have a frames directory in order to use the program" << endl;
      return false;
    }
  }

  cout << "loading frames into memory..." << endl;
  uint cur_frame = 1;
  while (true) {
    char framename[64];
    sprintf(framename, "frames/frame\%06i.png", cur_frame);

    if (FileExists(framename)) {
      CImgPtr img = CImgPtr(new CImg<u8>(framename));
      video.push_back(VideoImagePtr(new VideoImage(cur_frame,img)));
      cout << "loading frame " << cur_frame << endl;
      cur_frame += skip_frames;
    }
    else {
      // last frame
      break;
    }
  }
  return true;
}

/* Save the x and y coordinates of each manually entered corner so the data
   can be used the next time the user runs the program on this input file */
bool save_histograms(vector<VectColorHistPtr>& ColorHists) {
  string file_name;
  cout << "Type a file name for the corner file (no spaces)." << endl;
  cin >> file_name;
  ofstream out(file_name.c_str()); 
  if(!out) { 
    cerr << "Cannot open file." << endl; 
    return false;
  } 
  for (uint i=0; i<ColorHists.size(); i++) {
    for (uint j=0; j<ColorHists[i]->size(); j++) {
      out << i << " " << (*ColorHists[i])[j]->frame_num << " "
          << (*ColorHists[i])[j]->x << " "
          << (*ColorHists[i])[j]->y << endl;
    }
  }
  out.close();
  cout << "Successfully wrote file " << file_name << endl;
  return true;
}

/* Load the x and y coordinates of corner_types from a file */
bool load_histograms(vector<VectColorHistPtr>& ColorHists, const char* file_name) {
  // erase current histograms
  for (uint i=0; i<ColorHists.size(); i++) {
    ColorHists[i]->clear();
  }

  string line;
  ifstream corner_file (file_name);
  if (corner_file.is_open()) {
    while (!corner_file.eof() ) {
      // corner_type frame_num x y
      getline (corner_file,line);
      if (corner_file.eof()) { 
        break;
      }
      stringstream sline (line);
      uint val, corner_type;
      sline >> corner_type;
      ColorHistPtr hist = ColorHistPtr(new ColorHist());
      ColorHists[corner_type]->push_back(hist);
      sline >> val;
      (*ColorHists[corner_type])[ColorHists[corner_type]->size()-1]->frame_num = val;
      sline >> val;
      (*ColorHists[corner_type])[ColorHists[corner_type]->size()-1]->x = val;
      sline >> val;
      (*ColorHists[corner_type])[ColorHists[corner_type]->size()-1]->y = val;
/*
      cout << "loaded: " << corner_type << " | "
           << (*ColorHists[corner_type])[ColorHists[corner_type]->size()-1]->frame_num << " | "
           << (*ColorHists[corner_type])[ColorHists[corner_type]->size()-1]->x << " | "
           << (*ColorHists[corner_type])[ColorHists[corner_type]->size()-1]->y << endl;
*/
    }
    cout << "Finished loading file." << endl;
  }
  else {
    cout << "Failed to open file" << endl;
    return false;
  }
  return true;
}

void print_histogram(ColorHistPtr hist) {
  for (uint k=0; k<6; k++) {
     cout << (uint)hist->colors[k] << " ";
  }
  cout << endl;
}

void print_histograms(vector<VectColorHistPtr>& ColorHists) {
  for (uint i=0; i<ColorHists.size(); i++) {
    for (uint j=0; j<ColorHists[i]->size(); j++) {
      cout << "Type " << i << " | ";
      print_histogram((*ColorHists[i])[j]);
    }
  }
}

void print_selected_points(vector<VectColorHistPtr>& ColorHists) {
  for (uint i=0; i<ColorHists.size(); i++) {
    for (uint j=0; j<ColorHists[i]->size(); j++) {
      cout << "Type " << i << " | (" << (*ColorHists[i])[j]->x << "," << (*ColorHists[i])[j]->y << ")" << endl;
    }
  }
}

/* Average all the histograms of the same type together, so that there will be
   only one histogram for each corner type */
void average_histograms(vector<VectColorHistPtr>& ColorHists) {
  for (uint i=0; i<ColorHists.size(); i++) {
    if (ColorHists[i]->empty()) continue;
  
    ColorHistPtr hist = ColorHistPtr(new ColorHist());
    for (uint j=0; j<ColorHists[i]->size(); j++) {
      for (uint k=0; k<6; k++) {
        hist->colors[k] += (*ColorHists[i])[j]->colors[k];
      }
    }
    for (uint k=0; k<6; k++) {
      hist->colors[k] /= ColorHists[i]->size();
    }
    cout << "Average for type " << i << ":" << endl;
    print_histogram(hist);
    ColorHists[i]->clear();
    ColorHists[i]->push_back(hist);
  }
}

void corner_detect(CImg<u8>& img, uint nwidth, uint cnwidth, double alpha, double ET,
                   uint hist_threshold, uint cdist_threshold, u8 descriptor,
                   vector<VectColorHistPtr>& ColorHists, vector<Point2DPtr>& points,
                   uint max_corners) {
  cout << "Starting corner detection with:" << endl;
  cout << "(n) nwidth = " << nwidth << endl;
  cout << "(w) cnwidth = " << cnwidth << endl;
  cout << "(g) gaussian width = " << alpha << endl;
  cout << "(e) ET = " << ET << endl;
  cout << "(h) hist_threshold = " << hist_threshold << endl;
  cout << "(i) color_threshold = " << cdist_threshold << endl;
  cout << "max_corners = " << max_corners << endl;

  switch (descriptor) {
    case D_HIST:
      cout << "Using basic histogram descriptor." << endl;
      break;
    case D_PERIM_HIST:
      cout << "Using perimeter histogram descriptor." << endl;
      break;
    case D_N_PERIM_HIST:
      cout << "Using perimeter neighbors histogram descriptor." << endl;
      break;
  }

  //CImgDisplay disp(img,"Original Image");
  CImg<> visu_bw = CImg<>(img).get_norm_pointwise().normalize(0,255);
  CImgList<> grad(visu_bw.blur((float)alpha).normalize(0,255).get_gradientXY(3));

  // Calculate covariance matrix for basic corner detection
  for (uint x = nwidth; x<visu_bw.width - nwidth; x++) {
    for (uint y = nwidth; y<visu_bw.height - nwidth; y++) {
      Array2D<double> C(2, 2, 0.0); // covariance matrix
      for (uint x2 = x - nwidth; x2 <= x + nwidth; x2++) {
        for (uint y2 = y - nwidth; y2 <= y + nwidth; y2++) {
          C[0][0] = C[0][0] + pow(grad[0](x2, y2), 2);
          C[1][1] = C[1][1] + pow(grad[1](x2, y2), 2);
          C[0][1] = C[0][1] + grad[0](x2, y2) * grad[1](x2, y2);        
        }
      }
      Array1D<double> EigValues(2,2);
      JAMA::Eigenvalue<double> C_eig = JAMA::Eigenvalue<double>(C);
      C_eig.getRealEigenvalues(EigValues);
      double min_eig = (EigValues[0] < EigValues[1]) ? EigValues[0] : EigValues[1];
      if (min_eig > ET) {
        points.push_back(Point2DPtr(new Point2D(x,y,min_eig)));
      }
    }
  }

  sort(points.begin(),
       points.end(),
       Point2D::sort_points);

  if (points.size() > max_corners) {
    cout << "There are " << points.size() << " corners to analyze. Since this is above the threshold you set, " << max_corners
         << ", we won't bother continuing the process because it'll probably take way too long."
         << " Try using the interface to change some of the parameters." << endl;
    points.clear();
    return;
  }
  else {
    cout << "num potential corners: " << points.size() << endl;
  }

  // Remove points that don't correspond to one of the predefined color histograms
  for (uint i=0; i < points.size(); i++) {
    ColorHistPtr new_hist = ColorHistPtr(new ColorHist);
    switch (descriptor) {
      case D_HIST:
        new_hist = create_histogram(img, points[i]->x, points[i]->y, cnwidth, cdist_threshold);
        break;
      case D_PERIM_HIST:
        new_hist = create_perim_histogram(img, points[i]->x, points[i]->y, cnwidth, cdist_threshold);
        break;
      case D_N_PERIM_HIST:
        new_hist = create_neighbor_perim_histogram(img, points[i]->x, points[i]->y, cnwidth, cdist_threshold);
        break;
    }
    vector<HistDistPtr> dists;
    for (uint j=0; j < ColorHists.size(); j++) {
      for (uint k=0; k < ColorHists[j]->size(); k++) {
        dists.push_back(HistDistPtr(new HistDist(j, new_hist, (*ColorHists[j])[k])));
      }
    }

    sort(dists.begin(),
         dists.end(),
         HistDist::sort_hist_dist);

    if (dists[0]->dist < hist_threshold) {
      points[i]->corner_type = dists[0]->corner_type;
    }
    else {
      points.erase (points.begin()+i);
      i--;
    }
  }
  cout << "Num corners after color-histogram check: " << points.size() << endl;

  // For each point p, remove all points in the neighborhood of p that occur lower in L. 
  for (uint i=0; i < points.size(); i++) {
    for (uint j=i+1; j < points.size(); j++) {
      if (points[i]->in_neighborhood(*points[j], 2*nwidth)) {
        points.erase (points.begin()+j);
        j--;
      }
    }
  }
  cout << "Num corners after neighborhood check: " << points.size() << endl;
}

void output_color_chart() {
  cout << "Type 0 - green-cyan corner - red box" << endl;
  cout << "Type 1 - magenta-cyan corner - white box" << endl;
  cout << "Type 2 - blue-cyan corner - magenta box" << endl;
  cout << "Type 3 - red-cyan corner - blue box" << endl;
  cout << "Type 4 - red-green corner - cyan box" << endl;
  cout << "Type 5 - red-blue corner - green box" << endl;
  cout << "Type 6 - magenta-green corner - gray box" << endl;
  cout << "Type 7 - magenta-blue corner - black box" << endl;
  cout << "R G B Y M C" << endl;
}

int main(int argc,char **argv) {
  cimg_usage("...");
  const char* video_name =  cimg_option("-i", "","Input video.");
  const char* histogram_file =  cimg_option("-l", "","Histogram file.");
  uint skip_frames = cimg_option("-fs",10,"Skip frames during video load.");
  double alpha = cimg_option("-a",1.0,"Blurring the gradient image.");
  double ET = cimg_option("-t",.01,"Eigenvalue threshold.");
  uint hist_threshold = cimg_option("-h",10,"Histogram threshold.");
  uint cdist_threshold = cimg_option("-c",500000,"Color distance threshold.");
  uint neighborhood = cimg_option("-n",5,"Neighborhood for corner detection.");
  uint c_neighborhood = cimg_option("-cn",11,"Neighborhood for color histograms.");
  uint max_corners = cimg_option("-mc",18000,"Maximum number of corners to proceed with after basic detection.");
  uint nwidth = neighborhood/2;
  uint cnwidth = c_neighborhood/2;

  vector<VectColorHistPtr> ColorHists;

  for (uint i=0; i < 8; i++) {
    VectColorHistPtr new_vect = VectColorHistPtr(new vector<ColorHistPtr>());
    ColorHists.push_back(new_vect);
  }

  vector<VideoImagePtr> video;

  if (!load_video(video, video_name, skip_frames)) {
    exit(1);
  }  

  if (strlen(histogram_file) > 0) {
    load_histograms(ColorHists,histogram_file);
  }

  uint cur_vid_image = 0;
  CImg<u8> img(*(video[cur_vid_image]->image));
  CImg<u8> hist_view = img.get_crop(300,300,300+c_neighborhood,300+c_neighborhood);

  CImgDisplay color_select(img,"Select Corners [t-list types/colors, #-change type]",0), histogram_view(hist_view,"Histogram view",0);

  u8 corner_type = 0;
  string file_name;
  ofstream out;
  cout << "Click a feature point:" << endl;
  // Enter event loop. This loop ends when the display window is closed
  while (!color_select.is_closed) {
    //show histogram area in another window
    int x = color_select.mouse_x;
    int y = color_select.mouse_y;
    if (color_select.button == 1) {
      ColorHistPtr hist = ColorHistPtr(new ColorHist);
      hist->x = x;
      hist->y = y;
      hist->frame_num = video[cur_vid_image]->frame_num;

      ColorHists[corner_type]->push_back(hist);
      cout << "Added new corner of type " << (int) corner_type << " | hist # " << ColorHists[corner_type]->size() << endl;
      cimg::wait(1000);
    }

    if (color_select.key == 'q') {
      cout << "Done selecting corners..." << endl;
      break;
    }

    if (x > 0 && y > 0) {
      histogram_view << video[cur_vid_image]->image->get_crop(x-cnwidth,y-cnwidth,x+cnwidth,y+cnwidth);
    }
    
    switch (color_select.key) {
      // change corner_type
      case '0':
      case '1':
      case '2':
      case '3':
      case '4':
      case '5':
      case '6':
      case '7':
        corner_type = color_select.key - '0';
        cout << "Changed corner type to " << (int) corner_type << endl;
        cimg::wait(500);
        break;
      // print suggested corner-type/color correspondence
      case 't':
        output_color_chart();
        cimg::wait(200);
        break;

      // print seleted corners
      case 'p':
        print_selected_points(ColorHists);
        cimg::wait(200);
        break;

      // save selected corners
      case 's':
        save_histograms(ColorHists);
        cimg::wait(200);
        break;

      // load selected corners
      case 'l': {
        string file_name;
        string line;
        cout << "Type a file name to load (no spaces)." << endl;
        cin >> file_name;

        load_histograms(ColorHists,file_name.c_str());
        cimg::wait(200);
        break;}

      case cimg::keyARROWLEFT:
        if (cur_vid_image > 0) {
          cur_vid_image--;
          color_select << *video[cur_vid_image]->image;
          cimg::wait(100);
        }
        break;
      case cimg::keyARROWRIGHT:
        if (cur_vid_image < video.size() - 1) {
          cur_vid_image++;
          color_select << *video[cur_vid_image]->image;
          cimg::wait(100);
        }
        break;
    }

    // Handle display window resizing (if any)
    if (color_select.is_resized) color_select.resize().display(img);

    cimg::wait(10); // Temporize event loop
  }

  color_select.close();

  CImg<u8> img2 = *(video[cur_vid_image]->image); // for drawing boxes on
  CImgDisplay main_disp(img2,"Press up arrow for correspondence detection",0);
  vector<Point2DPtr> points;
  u8 descriptor = D_HIST;
  // Enter event loop. This loop ends when the display window is closed
  while (!main_disp.is_closed) {
    if (main_disp.button == 1) {

    }
    // Handle display window resizing (if any)
    if (main_disp.is_resized) main_disp.resize().display(img2);

    switch (main_disp.key) {
      case 'n':
        cout << "Enter an integer for nwidth." << endl;
        cin >> nwidth;
        break;
      case 'w':
        cout << "Enter an integer for cnwidth." << endl;
        cin >> cnwidth;
        break;
     case 'h':
        cout << "Enter an integer for hist_threshold." << endl;
        cin >> hist_threshold;
        break;
     case 'i':
        cout << "Enter an integer for the color distance threshold." << endl;
        cin >> cdist_threshold;
        break;
      case 'g':
        cout << "Enter a double for the gaussian width." << endl;
        cin >> alpha;
        break;
      case 'e':
        cout << "Enter a double for ET." << endl;
        cin >> ET;
        break;

      // load selected corners
      case 'l': {
        string file_name;
        string line;
        cout << "Type a file name to load (no spaces)." << endl;
        cin >> file_name;

        load_histograms(ColorHists,file_name.c_str());
        cimg::wait(200);
        break;}

      // print seleted corners
      case 'p':
        print_histograms(ColorHists);
        cimg::wait(200);
        break;

      //calc average
      case 'z':
        average_histograms(ColorHists);
        cimg::wait(200);
        break;

      // calculate histogram values from points
      case 'a':
        cout << "Calculating basic histogram for points" << endl;
        for (uint i=0; i<ColorHists.size(); i++) {
          for (uint j=0; j<ColorHists[i]->size(); j++) {
            cout << "hist " << i << " " << j << " frame num " << ((*ColorHists[i])[j])->frame_num << endl;
              
            calculate_histogram(video, (*ColorHists[i])[j], cnwidth, cdist_threshold);
          }
        }
        cout << "Done!" << endl;
        descriptor = D_HIST;
        cimg::wait(200);
        break;
      case 'b':
        cout << "Calculating perimter histogram for points" << endl;
        for (uint i=0; i<ColorHists.size(); i++) {
          for (uint j=0; j<ColorHists[i]->size(); j++) {
            calculate_perim_histogram(video, (*ColorHists[i])[j], cnwidth, cdist_threshold);
          }
        }
        cout << "Done!" << endl;
        descriptor = D_PERIM_HIST;
        cimg::wait(200);
        break;
      case 'c':
        cout << "Calculating neighbor perimeter histogram for points" << endl;
        for (uint i=0; i<ColorHists.size(); i++) {
          for (uint j=0; j<ColorHists[i]->size(); j++) {
            calculate_neighbor_perim_histogram(video, (*ColorHists[i])[j], cnwidth, cdist_threshold);
          }
        }
        cout << "Done!" << endl;
        descriptor = D_N_PERIM_HIST;
        cimg::wait(200);
        break;
        
      case cimg::keyARROWUP:
        points.clear();
        corner_detect(*(video[cur_vid_image]->image), nwidth, cnwidth, alpha,
                      ET, hist_threshold, cdist_threshold, descriptor, ColorHists, points, max_corners);
        img2 = *(video[cur_vid_image]->image); // for drawing boxes on
        
        // Draw boxes around points
        for (uint i=0; i < points.size(); i++) {

          img2.draw_rectangle(points[i]->x - nwidth, points[i]->y - nwidth,
                              points[i]->x + nwidth, points[i]->y + nwidth,
                              display_order[points[i]->corner_type],1);
        }
        main_disp << img2;
        output_color_chart();
        cimg::wait(100);
        break;
      case cimg::keyARROWLEFT:
        if (cur_vid_image > 0) {
          cur_vid_image--;
          main_disp << *video[cur_vid_image]->image;
          cimg::wait(100);
        }
        break;
      case cimg::keyARROWRIGHT:
        if (cur_vid_image < video.size() - 1) {
          cur_vid_image++;
          main_disp << *video[cur_vid_image]->image;
          cimg::wait(100);
        }
        break;
    }

    cimg::wait(20); // Temporize event loop
  }

  return 0;
}
