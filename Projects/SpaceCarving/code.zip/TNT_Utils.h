#ifndef TNT_UTILS
#define TNT_UTILS

#include <tnt/tnt.h>
#include <tnt/tnt_cmat.h>
#include <jama/jama_svd.h>
#include <jama/jama_lu.h>

#include <stdio.h>

using namespace std;

class TNT_Utils {
public:
     TNT::Array2D<double> eye(int dim);
     TNT::Array2D<double> invert(const TNT::Array2D<double> &M);
     TNT::Array2D<double> transpose(const TNT::Array2D<double> &M);
     TNT::Array2D<double> matmult(TNT::Array2D<double> a1, TNT::Array2D<double> a2);
     TNT::Array2D<double> leastSquares(TNT::Array2D<double> A, TNT::Array2D<double> y);
     void print(Array2D<double> mat);
};

#endif
