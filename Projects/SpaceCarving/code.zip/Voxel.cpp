#include "Voxel.h"

Voxel::Voxel() {
     R = 0;
     B = 0;
     G = 0;
     occupied = true;
}
