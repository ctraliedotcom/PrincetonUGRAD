#ifndef RANSAC_H
#define RANSAC_H

#include <vector>
#include "Camera.h"

#define MIN_POINTS_PER_LINE 4
#define TOTAL_ITERATIONS 20

using namespace std;

typedef unsigned int uint;
typedef unsigned char u8;

class Point2D {
public:
	uint x;
	uint y;
	double I2; // small eigenvalue of covariance matrix of neighborhood around point
	u8 corner_type;

	Point2D();
	Point2D(int x, int y, double I2) :
	x(x), y(y), I2(I2) { }
}; 

//I tried to store lines in normal form (better descriptor in general
//for lines closer to vertical), but this didn't work, so I'm back to
//slope intercept form
class Line2D {
public:
	Line2D();
	Line2D(double slope, double intercept);
	Line2D(double x1, double x2, double y1, double y2);
	double getDist(double x, double y);
	int getY(int x);
	double refitModel();//Using least squares, refit a model
	//with all of the points in the consensus set
	
	double m, b;
	size_t numPoints; //The number of points that were used
	//to construct this line
	double error;
	int pointclass;
	vector<Point2D> consensus_set;
};

//Take a bunch of points 

class Ransac {
public:
	Ransac(vector<Point2D> points, double t);
	
	vector<Point2D> classpoints[8];
	vector<Line2D> classlines;
};

class RansacColor {
public: 
	RansacColor(vector<struct Pixel>* pixels, double t);
	
	vector<int> consensus_set;//Store the indexes of the points
	//that fall in the consensus set
	struct Pixel bestColor;
	double stdev;
};


#endif
