#include "VoxelColor.h"

using namespace std;
using namespace cimg_library;


VoxelColor::VoxelColor(double sx, double sy, double sz, uint rx, uint ry, uint rz, double vr, double stdev) {
	startx = sx;
	starty = sy;
	startz = sz;
	resx = rx;
	resy = ry;
	resz = rz;
	vres = vr;
	max_stdev = stdev;
	voxels = new VoxelCloud(resx, resy, resz, vres);
	colored = 0;
}

VoxelColor::~VoxelColor() {
	delete voxels;
}

double getLuminance(struct Pixel pix) {
	return 0.3*pix.R + 0.59*pix.G + 0.11*pix.B;
}

vector<struct Pixel> VoxelColor::getPixels(int camera, double wX, double wY, double wZ, bool projectCenter) {
	struct Coord pix;
	vector<struct Pixel> ret;
	
	if (projectCenter) {
		//Simpler, just project the point at the center of each voxel
		//to every camera viewing plane
		pix = cameras[camera]->projectPixel(wX + vres/2, wY - vres/2, wZ - vres/2, false, false);
		int x = lround(pix.x), y = lround(pix.y);
		struct Pixel pixel = cameras[camera]->getPixel(x, y);
		
		if (pixel.x < 0) //Invalid pixel
			return ret;
			
		if (getLuminance(pixel) < LUMINANCE_THRESH)//Discount black pixels
			return ret;
		
		//If this pixel hasn't been marked yet to a voxel, use it
		//(otherwise, this voxel will already have been occluded by another voxel)
		if (!cameras[camera]->isMasked(x, y)) {
			pixel.camera = camera;
			ret.push_back(pixel);
		}
		return ret;
	}

	//Project the cube of the voxel onto the hexagon that it occupies on the image plane
	//Return all pixels in the 2D spatial bounding box of that hexagon
	//Go through all 7 remaining points on the cube of the voxel
	
	pix = cameras[camera]->projectPixel(wX, wY, wZ, false, false);
	//Start off the bounding box as the point 
	double leftx = lround(pix.x), bottomy = lround(pix.y), rightx = leftx, topy = bottomy;
	
	for (int i = 0; i < 2; i++) {
		for (int j = 0; j < 2; j++) {
			for (int k = 0; k < 2; k++) {
				if (i == 0 && j == 0 && k == 0)
					continue;
				double X = wX + vres*i;
				double Y = wY - vres*j;
				double Z = wZ + vres*k;
				pix = cameras[camera]->projectPixel(X, Y, Z, false, false);
				double x = lround(pix.x), y = lround(pix.y);
				//See if the bounding box needs to be increased in size
				if (x < leftx)	leftx = x;
				if (x > rightx) rightx = x;
				if (y < bottomy) bottomy = y;
				if (y > topy) topy = y;
			}
		}
	}
	double endw = (double)(cameras[camera]->width - 1);
	double endh = (double)(cameras[camera]->height - 1);
	int startx = std::max(leftx, 0.0);
	int endx = std::min(rightx, endw);
	int starty = std::max(bottomy, 0.0);
	int endy = std::min(topy, endh);
	//Now put all of the pixels in the bounding box into a vector and return it
	for (int x = startx; x < endx; x++) {
		for (int y = starty; y < endy; y++) {
			if (cameras[camera]->isMasked(x, y))
				//Don't include pixels that are already associated with
				//an accepted voxel
				continue;
			struct Pixel pixel = cameras[camera]->getPixel(x, y);
			if (pixel.x < 0)  //Invalid pixel
				continue;
			if (getLuminance(pixel) < LUMINANCE_THRESH)//Discount black pixels
				continue;
			pixel.camera = camera;
			ret.push_back(pixel);
		}
	}
	return ret;
}

struct Pixel VoxelColor::checkConsistency() {
	struct Pixel ret;//Holds the color of the agreed-upon pixel
	
	RansacColor colorGuess(&projPixels, 100.0);
	if (colorGuess.stdev < max_stdev) {
		/*if (getLuminance(colorGuess.bestColor) < LUMINANCE_THRESH) {
			ret.x = -1;
			return ret;
		}*/
		//printf("%.3f\n", colorGuess.stdev);
		vector<struct Pixel> consensus_set;
		for (size_t i = 0; i < colorGuess.consensus_set.size(); i++) {
			//Copy all of the points that are part of the best cluster
			consensus_set.push_back(projPixels[colorGuess.consensus_set[i]]);
		}
		ret = colorGuess.bestColor;
		projPixels = consensus_set;
		ret.x = 0;//If x is -1, it should be carved, otherwise, use
		//the color that is returned
	}
	else {
		ret.x = -1;
	}
	return ret;
}

int VoxelColor::doColoring() {
	printf("%i, %i, %i\n", resx, resy, resz);
	//Sweep plane across the Z-axis
	for (uint z = 0; z < resz; z++) {
		//Then look at every voxel on the plane defined by Z = k
		printf("z = %i, colored = %u\n", z, colored);
		for (uint x = 0; x < resx; x++) {
			for (uint y = 0; y < resy; y++) {
				//printf("%.2lf percent\n", (double)(z*resx*resy + x*resy + y) / (double)(resx*resy*resz));
				//Look at one voxel
				/*NOTE: The y coordinate is inverted because +y is down,
				 *but y=0 is defined to be the top of the calibration target
				 *So to go "up" along the object to be scanned, go along -y*/
				projPixels.clear();
				double wX = startx+vres*x, wY = starty-vres*y, wZ = startz+vres*z;
				for (size_t i = 0; i < cameras.size(); i++) {
					vector<struct Pixel> pixels = getPixels(i, wX, wY, wZ, false);
					//a.insert(a.end(), b.begin(), b.end())
					projPixels.insert(projPixels.end(), pixels.begin(), pixels.end());
				}
				//Check consistency and see if the voxel needs to be carved
				struct Pixel color = checkConsistency();
				Voxel* voxel = voxels->voxelAt(x, y, z);
				if (color.x == -1) {
					//Carve the voxel
					voxel->occupied = false;
				}
				else {
					//Set the voxel to the agreed-upon color (at this point,
					//the voxel has been accepted as being part of the 3D object)
					voxel->R = color.R;
					voxel->G = color.G;
					voxel->B = color.B;
					//Mask all of the pixels that participated in 
					//the consistency check so that they are not
					//considered later (in the case that another voxel would
					//project to the same spot, where it was clearly occluded)
					for (size_t i = 0; i < projPixels.size(); i++) {
						int cam = projPixels[i].camera;
						cameras[cam]->maskPixel(projPixels[i].x, projPixels[i].y);
					}
					colored++;
				}
			}
		}
	}
	
	//TODO: (?) Sweep plane across other principal directions to improve estimates
	// (but check to see what the results are like just doing the one direction first)
	
	voxels->write("model.vox");
	return 0;
}
