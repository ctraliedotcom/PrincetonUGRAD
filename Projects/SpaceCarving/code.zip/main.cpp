#include <stdio.h>
#include "Camera.h"
#include "VoxelCloud.h"
#include "VoxelColor.h"
#include "Voxel.h"
#include <CImg.h>

using namespace std;
using namespace cimg_library;

CImgList<unsigned char> images;

uint resx, resy, resz;
double startx, starty, startz;
double vres, max_stdev;
char* videodir;

void parseArgs(int argc, char** argv) {
	if (argc < 10) {
		fprintf(stderr, "Usage: VoxelColor <video directory> <startx> <starty> <startz> <voxelresx> <voxelresy> <voxelresz> <cm per voxel> <max stdev>");
		exit(0);
	}
	videodir = argv[1];
	startx = (double)atof(argv[2]);
	starty = (double)atof(argv[3]);
	startz = (double)atof(argv[4]);
	resx = (uint)atoi(argv[5]);
	resy = (uint)atoi(argv[6]);
	resz = (uint)atoi(argv[7]);
	vres = (double)atof(argv[8]);
	max_stdev = (double)atof(argv[9]);
	
}

int main(int argc, char** argv) {
	parseArgs(argc, argv);
	VoxelColor colorer(startx, starty, startz, resx, resy, resz, vres, max_stdev);
	//Load all of the cameras into the colorer
	int frame = 1;
	while (true) {
		char framefile[256];
		char correspfile[256];
		sprintf(framefile, "%s/frame%i.jpg", videodir, frame);
		sprintf(correspfile, "%s/corresp%i.txt", videodir, frame);
		FILE* f = fopen(framefile, "r");
		if (f == NULL)
			break;
		Camera* camera = new Camera();
		CImg<unsigned char>* image = new CImg<u8>((const char*)framefile);
		camera->setImage(image);
		camera->getCorresp(correspfile);
		camera->getProjMatrix();
		colorer.cameras.push_back(camera);
		printf("Finished calibrating camera %i\n", frame);
		frame++;
	}
	colorer.doColoring();
	return 0;
}

