//Programmer: Chris Tralie (modified from COS 426 Assignment #2
//http://www.cs.princeton.edu/courses/archive/spring09/cos426/assn2/COS426_assignment2.zip

//Purpose: To provide an interactive voxel cloud viewer where the user can
//rotate the voxel cloud about its center, zoom in/zoom out, and translate the voxel cloud

#include <iostream>
#include <vector>
#include <stdio.h>

#ifdef _WIN32
#include <windows.h>
#define M_PI 3.1415925
#endif

#ifdef __APPLE__
#include <GLUT/glut.h>
#else
#include <GL/glut.h>
#endif
#include "R3/R3.h"
#include "VoxelCloud.h"

using namespace std;

// Display variables

static R3Point camera_eye (0, 0, 4);
static R3Vector camera_towards(0, 0, -1);
static R3Vector camera_up(0, 1, 0);
static R3Point mesh_center;
static double mesh_radius = 1;
static double camera_yfov = 0.75;

// GLUT variables 

static int GLUTwindow = 0;
static int GLUTwindow_height = 800;
static int GLUTwindow_width = 800;
static int GLUTmouse[2] = { 0, 0 };
static int GLUTbutton[3] = { 0, 0, 0 };
static int GLUTmodifiers = 0;

//Voxel structure variables
VoxelCloud* voxelcloud;
double csize;

////////////////////////////////////////////////////////////
// GLUT USER INTERFACE CODE
////////////////////////////////////////////////////////////

void GLUTMainLoop(void)
{
	camera_eye = mesh_center + 2.5 * mesh_radius * camera_towards;

	// Run main loop -- never returns 
	glutMainLoop();
}

void GLUTStop(void)
{
	// Destroy window 
	glutDestroyWindow(GLUTwindow);

	// Exit
	exit(0);
}



void GLUTResize(int w, int h)
{
	// Resize window
	glViewport(0, 0, w, h);

	// Remember window size 
	GLUTwindow_width = w;
	GLUTwindow_height = h;

	// Redraw
	glutPostRedisplay();
}


void GLUTRedraw(void)
{
	// Set projection transformation
	glMatrixMode(GL_PROJECTION);
	glLoadIdentity();
	gluPerspective(180.0*camera_yfov/M_PI, (GLdouble) GLUTwindow_width /(GLdouble) GLUTwindow_height, 
	0.01 * mesh_radius, 100 * mesh_radius);

	// Set camera transformation
	R3Vector& t = camera_towards;
	R3Vector& u = camera_up;
	R3Vector r = camera_towards % camera_up;
	GLdouble camera_matrix[16] = { r[0], u[0], t[0], 0, r[1], u[1], t[1], 0, r[2], u[2], t[2], 0, 0, 0, 0, 1 };
	glMatrixMode(GL_MODELVIEW);
	glLoadIdentity();
	glMultMatrixd(camera_matrix);
	glTranslated(-camera_eye[0], -camera_eye[1], -camera_eye[2]);

	// Clear window 
	glClearColor(0.0, 0.0, 0.0, 0.0);
	glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

	// Set lights
	static GLfloat light0_position[] = { 3.0, 4.0, 5.0, 0.0 };
	glLightfv(GL_LIGHT0, GL_POSITION, light0_position);
	static GLfloat light1_position[] = { -3.0, -2.0, -3.0, 0.0 };
	glLightfv(GL_LIGHT1, GL_POSITION, light1_position);



	glDisable(GL_LIGHTING);
	//TODO: Draw voxel structure
	double dx = csize / 2;
	for (uint x = 0; x < voxelcloud->resx; x++) {
		for (uint y = 0; y < voxelcloud->resy; y++) {
			for (uint z = 0; z < voxelcloud->resz; z++) {
				Voxel* v = voxelcloud->voxelAt(x, y, z);
				if (v->occupied) {
					//Draw the colored cube
					double xc = (double)x * csize;
					double yc = (double)y * csize;
					double zc = (double)z * csize;
					//Set the color of the voxel
					glColor3b(v->R, v->G, v->B);
					glBegin(GL_QUADS);
						//Back face
						glVertex3f(xc - dx, yc - dx, zc - dx);
						glVertex3f(xc - dx, yc + dx, zc - dx);
						glVertex3f(xc - dx, yc + dx, zc + dx);
						glVertex3f(xc - dx, yc - dx, zc + dx);
						
						//Front Face
						glVertex3f(xc + dx, yc - dx, zc - dx);
						glVertex3f(xc + dx, yc + dx, zc - dx);
						glVertex3f(xc + dx, yc + dx, zc + dx);
						glVertex3f(xc + dx, yc - dx, zc + dx);
						
						//Left Face
						glVertex3f(xc - dx, yc - dx, zc - dx);
						glVertex3f(xc + dx, yc - dx, zc - dx);
						glVertex3f(xc + dx, yc - dx, zc + dx);
						glVertex3f(xc - dx, yc - dx, zc + dx);
						
						//Right Face
						glVertex3f(xc - dx, yc + dx, zc - dx);
						glVertex3f(xc + dx, yc + dx, zc - dx);
						glVertex3f(xc + dx, yc + dx, zc + dx);
						glVertex3f(xc - dx, yc + dx, zc + dx);
						
						//Top Face
						glVertex3f(xc - dx, yc - dx, zc + dx);
						glVertex3f(xc + dx, yc - dx, zc + dx);
						glVertex3f(xc + dx, yc + dx, zc + dx);
						glVertex3f(xc - dx, yc + dx, zc + dx);

						//Bottom Face
						glVertex3f(xc - dx, yc - dx, zc - dx);
						glVertex3f(xc + dx, yc - dx, zc - dx);
						glVertex3f(xc + dx, yc + dx, zc - dx);
						glVertex3f(xc - dx, yc + dx, zc - dx);
					glEnd();
				}
			}
		}
	}

	// Swap buffers 
	glutSwapBuffers();
}    

void GLUTMotion(int x, int y)
{
	// Invert y coordinate
	y = GLUTwindow_height - y;

	// Compute mouse movement
	int dx = x - GLUTmouse[0];
	int dy = y - GLUTmouse[1];

	// Process mouse motion event
	if ((dx != 0) || (dy != 0)) {
		if (GLUTbutton[0]) {
			// Rotate world
			double vx = (double) dx / (double) GLUTwindow_width;
			double vy = (double) dy / (double) GLUTwindow_height;
			double theta = 4.0 * (fabs(vx) + fabs(vy));
			R3Vector camera_right = camera_towards % camera_up;
			R3Vector vector = (camera_right * vx) + (camera_up * vy);
			R3Vector rotation_axis = vector % camera_towards;
			rotation_axis.Normalize();
			camera_eye.Rotate(R3Line(mesh_center, rotation_axis), theta);
			camera_towards.Rotate(rotation_axis, theta);
			camera_up.Rotate(rotation_axis, theta);
			camera_right = camera_towards % camera_up;
			camera_up = camera_right % camera_towards;
			camera_towards.Normalize();
			camera_up.Normalize();
			glutPostRedisplay();
		}
		else if (GLUTbutton[1]) {
			// Scale world 
			double factor = (double) dx / (double) GLUTwindow_width;
			factor += (double) dy / (double) GLUTwindow_height;
			factor = exp(2.0 * factor);
			factor = (factor - 1.0) / factor;
			R3Vector translation = (mesh_center - camera_eye) * factor;
			camera_eye += translation;
			glutPostRedisplay();
		}
		else if (GLUTbutton[2]) {
			// Translate world
			double length = R3Distance(mesh_center, camera_eye) * tan(camera_yfov);
			double vx = length * (double) dx / (double) GLUTwindow_width;
			double vy = length * (double) dy / (double) GLUTwindow_height;
			R3Vector camera_right = camera_towards % camera_up;
			R3Vector translation = -((camera_right * vx) + (camera_up * vy));
			camera_eye += translation;
			glutPostRedisplay();
		}
	}

	// Remember mouse position 
	GLUTmouse[0] = x;
	GLUTmouse[1] = y;
}

void GLUTMouse(int button, int state, int x, int y)
{
	// Invert y coordinate
	y = GLUTwindow_height - y;

	// Process mouse button event
	if (state == GLUT_DOWN) {
	if (button == GLUT_LEFT_BUTTON) {
	}
	else if (button == GLUT_MIDDLE_BUTTON) {
	}
	else if (button == GLUT_RIGHT_BUTTON) {
	}
	}

	// Remember button state 
	int b = (button == GLUT_LEFT_BUTTON) ? 0 : ((button == GLUT_MIDDLE_BUTTON) ? 1 : 2);
	GLUTbutton[b] = (state == GLUT_DOWN) ? 1 : 0;

	// Remember modifiers 
	GLUTmodifiers = glutGetModifiers();

	// Remember mouse position 
	GLUTmouse[0] = x;
	GLUTmouse[1] = y;

	// Redraw
	glutPostRedisplay();
}

void GLUTKeyboard(unsigned char key, int x, int y)
{
	// Invert y coordinate
	y = GLUTwindow_height - y;

	// Process keyboard button event 
	switch (key) {

	case 27: // ESCAPE
		GLUTStop();
		break;
	}

	// Remember mouse position 
	GLUTmouse[0] = x;
	GLUTmouse[1] = y;

	// Remember modifiers 
	GLUTmodifiers = glutGetModifiers();

	// Redraw
	glutPostRedisplay();
}


void GLUTInit(int *argc, char **argv)
{
	// Open window 
	glutInit(argc, argv);
	glutInitWindowPosition(100, 100);
	glutInitWindowSize(GLUTwindow_width, GLUTwindow_height);
	glutInitDisplayMode(GLUT_DOUBLE | GLUT_RGB | GLUT_DEPTH); // | GLUT_STENCIL
	GLUTwindow = glutCreateWindow("Interactive Voxel Viewer");

	// Initialize GLUT callback functions 
	glutReshapeFunc(GLUTResize);
	glutDisplayFunc(GLUTRedraw);
	glutKeyboardFunc(GLUTKeyboard);
	glutMouseFunc(GLUTMouse);
	glutMotionFunc(GLUTMotion);

	// Initialize lights 
	static GLfloat lmodel_ambient[] = { 0.2, 0.2, 0.2, 1.0 };
	glLightModelfv(GL_LIGHT_MODEL_AMBIENT, lmodel_ambient);
	glLightModeli(GL_LIGHT_MODEL_LOCAL_VIEWER, GL_TRUE);
	static GLfloat light0_diffuse[] = { 1.0, 1.0, 1.0, 1.0 };
	glLightfv(GL_LIGHT0, GL_DIFFUSE, light0_diffuse);
	glEnable(GL_LIGHT0);
	static GLfloat light1_diffuse[] = { 0.5, 0.5, 0.5, 1.0 };
	glLightfv(GL_LIGHT1, GL_DIFFUSE, light1_diffuse);
	glEnable(GL_LIGHT1);
	glEnable(GL_NORMALIZE);
	glEnable(GL_LIGHTING);

	// Initialize graphics modes 
	glEnable(GL_DEPTH_TEST);
}


int main(int argc, char** argv) {
	if (argc < 2) {
		fprintf(stderr, "Usage: VoxelView <filename>\n");
		return 1;
	}
	// Initialize GLUT
	GLUTInit(&argc, argv);

	voxelcloud = new VoxelCloud(argv[1]);
	csize = voxelcloud->cellsize;
	mesh_center.SetX((double)voxelcloud->resx * csize / 2.0);
	mesh_center.SetY((double)voxelcloud->resy * csize / 2.0);
	mesh_center.SetZ((double)voxelcloud->resz * csize / 2.0);

	mesh_radius = (double)voxelcloud->resx * csize;
	// Run GLUT interface
	GLUTMainLoop();

	// Return success 
	return 0;
}
