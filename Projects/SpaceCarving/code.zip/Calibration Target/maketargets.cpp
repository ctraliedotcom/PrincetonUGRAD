#include "CImg.h"
#include <stdlib.h>
#include <stdio.h>

#define CM_PER_PIXEL 0.026458333

using namespace cimg_library;

typedef unsigned char u8;

u8 c_red[] = {255, 0, 0};
u8 c_green[] = {0, 255, 0};
u8 c_blue[] = {0, 0, 255};
u8 c_yellow[] = {255, 255, 0};
u8 c_magenta[] = {255, 0, 255};
u8 c_cyan[] = {0, 255, 255};
u8 c_black[] = {0, 0, 0};

int blocks = 8;
double block_width = 2.0;//In centimeters

int cmToPix(double cm) {
	return (int)(cm / CM_PER_PIXEL);
}

//Make the special top face
void makeTopFace(int resx, int resy) {
	CImg<u8> img(resx, resy, 1, 3);
	//Yellow background
	img.draw_rectangle(0, 0, resx, resy, c_black, 1);
	int top = 0;
	int bottom = cmToPix((blocks - 1)*block_width);
	int width = cmToPix(block_width);
	for (int i = 1; i < blocks - 1; i++) {
		int startx = cmToPix(i*block_width);
		if (i % 2 == 0)
			img.draw_rectangle(startx, top, startx + width, top + width, c_cyan);
		else
			img.draw_rectangle(startx, bottom, startx + width, bottom + width, c_cyan);
	}
	int left = 0;
	int right = cmToPix((blocks - 1)*block_width);
	for (int j = 1; j < blocks - 1; j++) {
		int starty = cmToPix(j*block_width);
		if (j % 2 == 1)
			img.draw_rectangle(left, starty, left + width, starty + width, c_cyan);
		else
			img.draw_rectangle(right, starty, right + width, starty + width, c_cyan);
	}
	img.save("top.png");
}

//Make one of the oridnary lateral faces
void makeFace(int resx, int resy, u8* color, const char* name) {
	CImg<u8> img(resx, resy, 1, 3);
	//Yellow background
	img.draw_rectangle(0, 0, resx, resy, c_black, 1);
	int top = 0;
	int bottom = cmToPix((blocks - 1)*block_width);
	int width = cmToPix(block_width);
	for (int i = 0; i < blocks; i++) {
		int startx = cmToPix(i*block_width);
		if (i % 2 == 0) //Blocks start on the left on top
			img.draw_rectangle(startx, top, startx + width, top + width, color);
		else
			img.draw_rectangle(startx, bottom, startx + width, bottom + width, color);
	}
	int left = 0;
	int right = cmToPix((blocks - 1)*block_width);
	for (int j = 0; j < blocks; j++) {
		int starty = cmToPix(j*block_width);
		if (j % 2 == 0)
			img.draw_rectangle(left, starty, left + width, starty + width, color);
		else
			img.draw_rectangle(right, starty, right + width, starty + width, color);
	}
	img.save(name);
}

int main(int argc, char** argv) {
	int resx = cmToPix(blocks*block_width);
	int resy = resx;
	makeFace(resx, resy, c_red, "R.png");
	makeFace(resx, resy, c_green, "G.png");
	makeFace(resx, resy, c_blue, "B.png");
	makeFace(resx, resy, c_magenta, "M.png");
	makeTopFace(resx, resy);
	return 0;
}
