#include <stdio.h>
#include "Camera.h"


//Uncomment this to visuall debug the projection matrices
int main(int argc, char** argv) {
     if (argc < 6) {
          fprintf(stderr, "USAGE: TestProjection <imagefilename> <correspfilename> <wX> <wY> <wZ>\n\n");
          return 1;
     }
     Camera camera(argv[1]);
     camera.getCorresp(argv[2]);
     camera.getProjMatrix();
     //camera.getExplicitParams();
     struct Coord coord = camera.projectPixel(atof(argv[3]), atof(argv[4]), atof(argv[5]), false, true);
     printf("(x, y) = (%.3f, %.3f)\n", coord.x, coord.y);
     //camera.inFrontOfCamera(0, 0, 0);
     return 0;
}
