#ifndef VOXEL_H
#define VOXEL_H

typedef unsigned char u8;

class Voxel {
public:
     Voxel();
     u8 R, G, B;
     bool occupied;
};

#endif
