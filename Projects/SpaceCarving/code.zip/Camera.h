#ifndef CAMERA_H
#define CAMERA_H

#include "TNT_Utils.h"
#include "CImg.h"
#include <vector>

using namespace std;
using namespace cimg_library;

typedef unsigned char u8;

struct Coord {
     double x, y;
};

struct Pixel {
	u8 R, G, B;
	int x, y;
	int camera;
};

class Camera {
public:
     Camera(char* filename);
     Camera();
     ~Camera();
     void getCorresp(char* filename);//Get correspondences from a file
     void getProjMatrix();//Do the implicit calibration
     void getExplicitParams();//Do the explicit calibration (more involved)
     void setImage(CImg<u8>* im);
     void maskPixel(int x, int y);
     bool isMasked(int x, int y);
     bool inFrontOfCamera(double wX, double wY, double wZ);
     
     //Given 3 world coordinates, return the corresponding pixel
     //on the image
     struct Coord projectPixel(double wX, double wY, double wZ, bool expl, bool draw);
     struct Pixel getPixel(int x, int y);
     
     Array2D<double>* corresp;//Point correspondences
     CImg<u8>* image;
     bool* mask;//Mask for whether pixels have been checked
     int width, height;//Width and height of image
     Matrix<double> proj;//Projection matrix
     Matrix<double> world2Camera;//Rotation + Translation
     
     /**Explicit camera parameters**/
     //Intrinsic parameters
     double fx, fy;//Focal lengths expressed in pixels
     double alpha;//Aspect ratio
     
     //Extrinsic parameters
     Array2D<double> R;//Rotation matrix
     Array2D<double> T;//Translation vector
};


#endif
