#include "Camera.h"
#include <stdio.h>
#include <stdlib.h>
#include <assert.h>

using namespace cimg_library;

Camera::Camera() {
     Array2D<double> Ttemp(3, 1);
     T = Ttemp;
     corresp = NULL;
     mask = NULL;
}

Camera::Camera(char* filename) {
	Array2D<double> Ttemp(3, 1);
     T = Ttemp;
     image = new CImg<u8>((const char*)filename);
     width = image->width;
     height = image->height;
     mask = new bool[width*height];
     for (int i = 0; i < width*height; i++)
     	mask[i] = false;
     corresp = NULL;
}

Camera::~Camera() {
	if (corresp != NULL)
     	delete corresp;
     if (mask != NULL)
     	delete[] mask;
}

void Camera::setImage(CImg<u8>* im) {
	image = im;
	width = im->width;
	height = im->height;
	mask = new bool[width*height];
	for (int i = 0; i < width*height; i++)
		mask[i] = false;
}

//Get 3D->2D point correspondences (hard coded in a file for now, but
//will be automated later)
void Camera::getCorresp(char* filename) {
     FILE* f = fopen(filename, "r");
     if (f == NULL) {
          fprintf(stderr, "ERROR: Opening file %s\n", filename);
          return;
     }
     int numrows;
     fscanf(f, "%i", &numrows);
     corresp = new Array2D<double>(numrows, 5);
     int row = 0;
     while (!feof(f) && row < numrows) {
          //World x, y, z, pixel x, y
          double temp;
          for (int i = 0; i < 5; i++) {
               fscanf(f, "%lf", &temp);
               (*corresp)[row][i] = temp;    
          }
          row++;
     }
}

//Create a projection matrix directly based on (x, y, z) -> (pixelx, pixely) 
//correspondences using least-squared / SVD techniques
void Camera::getProjMatrix() {
     //X1 Y1 Z1 1 0 0 0 0 -x1X1 -x1Y1 -x1Z1 -x1
     //0 0 0 0 X1 Y1 Z1 1 -y1X1 -y1Y1 -y1Z1 -y1
     int rows = corresp->dim1() * 2;
     Array2D<double> minmatrix(rows, 12);//Matrix on which to do least squares
     
     for (int i = 0; i < corresp->dim1(); i++) {
          //X, Y, Z are world coordinates
          //x and y are pixel coordinates
          double X = (*corresp)[i][0];
          double Y = (*corresp)[i][1];
          double Z = (*corresp)[i][2];
          double x = (*corresp)[i][3];
          double y = (*corresp)[i][4];
          double row1[12] = {X, Y, Z, 1, 0, 0, 0, 0, -x*X, -x*Y, -x*Z, -x};
          double row2[12] = {0, 0, 0, 0, X, Y, Z, 1, -y*X, -y*Y, -y*Z, -y};
          for (int j = 0; j < 12; j++) {
               minmatrix[i*2][j] = row1[j];
               minmatrix[i*2+1][j] = row2[j];
          }
     }
     JAMA::SVD<double> svd(minmatrix);
     Array1D<double> singValues;
     svd.getSingularValues(singValues);
     Array2D<double> U;
     Array2D<double> V;
     svd.getV(V);

     //The solution will be in the following column of the "V" matrix
     //(the column corresponding to the smallest singular value, i.e. 
     //the column with a least squares solution)
     int mCol = singValues.dim() - 1;
     double p[12];//The entires of the projection matrix
     for (int row = 0; row < 12; row++) {
          p[row] = V[row][mCol];
     }
     
     //Now unroll all of the entires into the projection matrix
     //[a b c d]
     //[e f g h]
     //[i j k l]
     proj.newsize(3, 4);
     for (int i = 0; i < 12; i++)
     	proj[i / 4][i % 4] = p[i];         
          
     //Now try to extract the intrinsic and extrinsic parameters
     //from this matrix
     double gamma = sqrt(p[8]*p[8]+p[9]*p[9]+p[10]*p[10]);
     for (int i = 0; i < 12; i++)
     	p[i] /= gamma;
	
	double ox = 0, oy = 0;
	fx = 0; fy = 0;
	for (int k = 0; k < 3; k++) { 
		ox += p[k] * p[8+k];
		oy += p[4+k] * p[8+k];
		fx += p[k] * p[k];
		fy += p[4+k] * p[4+k];
	}
	//printf("ox = %.3f, oy = %.3f\n", ox, oy);
	fx = sqrt(fx - ox*ox);
	fy = sqrt(fy - oy*oy);
	//printf("fx = %.3f, fy = %.3f\n", fx, fy);
	
	double Tz = p[11];
	double Tx = (p[3] - ox*Tz) / fx;
	double Ty = (p[7] - oy*Tz) / fy;
	
	//printf("(Tx, Ty, Tz) = (%.3f, %.3f, %.3f)\n\n", Tx, Ty, Tz);
	
	double r31 = p[8], r32 = p[9], r33 = p[10];
	double r11 = (p[0] - ox*r31) / fx;
	double r12 = (p[1] - ox*r32) / fx;
	double r13 = (p[2] - ox*r33) / fx;
	double r21 = (p[4] - oy*r31) / fy;
	double r22 = (p[5] - oy*r32) / fy;
	double r23 = (p[6] - oy*r33) / fy;
	
	Array2D<double> R_est(3, 3);//First estimate of the rotation matrix
     R_est[0][0] = r11;  R_est[0][1] = r12;  R_est[0][2] = r13;
     R_est[1][0] = r21;  R_est[1][1] = r22;  R_est[1][2] = r23;
     R_est[2][0] = r31;  R_est[2][1] = r32;  R_est[2][2] = r33;
     JAMA::SVD<double> svdR(R_est);
     svdR.getU(U);
     svdR.getV(V);
     TNT_Utils util;
     Array2D<double> VTranspose = util.transpose(V);
     Array2D<double> eye3 = util.eye(3);
     R = util.matmult(U, eye3);
     R = util.matmult(R, VTranspose);
	
	world2Camera.newsize(3, 4);
	for (int i = 0; i < 3; i++) {
		for (int j = 0; j < 3; j++) {
			world2Camera[i][j] = R[i][j];
		}
	}
	world2Camera[0][3] = Tx;
	world2Camera[1][3] = Ty;
	world2Camera[2][3] = Tz;
	//Now check to see if the sign needs to be flipped
	//by noting that Ty should always be positive (the camera
	//is always above the calibration target)
	if (Ty < 0) {
		//Flip the sign
		Ty = -Ty; Tx = -Tx; Tz = -Tz;
		for (int i = 0; i < 3; i++) {
			for (int j = 0; j < 4; j++) {
				world2Camera[i][j] = -world2Camera[i][j];
			}
		}
	}
}

bool Camera::inFrontOfCamera(double wX, double wY, double wZ) {
	Matrix<double> worldCoord(4, 1);
	worldCoord[0][0] = wX;
	worldCoord[1][0] = wY;
	worldCoord[2][0] = wZ;
	worldCoord[3][0] = 1.0;
	
	Matrix<double> cameracoord = world2Camera * worldCoord;
	
	printf("Camera coord = (%.3f, %.3f, %.3f)\n", cameracoord[0][0], cameracoord[0][1], cameracoord[0][2]);
	
	return (cameracoord[0][2] > 0);
}

void Camera::getExplicitParams() {
     assert(corresp->dim1() > 0);
     TNT_Utils util;

     //Step 1: Compute the SVD of the "A" matrix
     int rows = corresp->dim1();
     Array2D<double> A(rows, 8);//Matrix on which to do least squares
     
     for (int i = 0; i < corresp->dim1(); i++) {
          //X, Y, Z are world coordinates
          //x and y are pixel coordinates
          double X = (*corresp)[i][0];
          double Y = (*corresp)[i][1];
          double Z = (*corresp)[i][2];
          double x = (*corresp)[i][3];
          double y = (*corresp)[i][4];
          //xX xY xZ x -yX -yY -yZ -y
          double row[8] = {x*X, x*Y, x*Z, x, -y*X, -y*Y, -y*Z, -y};
          for (int j = 0; j < 8; j++)
               A[i][j] = row[j];
     }
     JAMA::SVD<double> svdA(A);
     Array1D<double> singValues;
     svdA.getSingularValues(singValues);
     Array2D<double> U, V;
     svdA.getV(V);

     //The solution will be in the following column of the "V" matrix
     //(the column corresponding to the smallest singular value, i.e. 
     //the column with a least squares solution)
     int mCol = singValues.dim() - 1;
     double v[8];//The best solution to the "A" matrix equation
     for (int row = 0; row < 8; row++) {
          v[row] = V[row][mCol];
     }

     //Step 2: Determine |gamma| and alpha from (6.10) and (6.11)
     double absgamma = sqrt(v[0]*v[0] + v[1]*v[1] + v[2]*v[2]);
     double alphagamma = sqrt(v[4]*v[4] + v[5]*v[5] + v[6]*v[6]);
     alpha = alphagamma / absgamma;
     
     //Step 3: Recover the first two rows of R and the first two components
     //of T from (6.9)
     double r21 = v[0] / absgamma, r22 = v[1] / absgamma, r23 = v[2] / absgamma;
     double r11 = v[4] / alphagamma, r12 = v[5] / alphagamma, r13 = v[6] / alphagamma;
     double Tx = v[7] / alphagamma, Ty = v[3] / absgamma;
     
     //Step 4: Compute the third row of R as the cross product of the
     //first two rows estimated in the previous step, and enforce the
     //orthogonality constraint on the estimate of R through SVD decomposition
     double r31 = r12*r23 - r13*r22;
     double r32 = r13*r21 - r11*r23;
     double r33 = r11*r22 - r12*r21;
     Array2D<double> R_est(3, 3);//First estimate of the rotation matrix
     R_est[0][0] = r11;  R_est[0][1] = r12;  R_est[0][2] = r13;
     R_est[1][0] = r21;  R_est[1][1] = r22;  R_est[1][2] = r23;
     R_est[2][0] = r31;  R_est[2][1] = r32;  R_est[2][2] = r33;
     JAMA::SVD<double> svdR(R_est);
     svdR.getU(U);
     svdR.getV(V);
     Array2D<double> VTranspose = util.transpose(V);
     Array2D<double> eye3 = util.eye(3);
     R = util.matmult(U, eye3);
     R = util.matmult(R, VTranspose);
     
     //Step 5: Pick a point correspondence and check inequality (6.12).  
     //If it is satisfied, reverse the sign of the first two rows of R 
     //and of the first two components of T
     double X = (*corresp)[0][0];
     double Y = (*corresp)[0][1];
     double Z = (*corresp)[0][2];
     double x = (*corresp)[0][3];
     if (x * (R[0][0]*X + R[0][1]*Y + R[0][2]*Z + Tx) > 0) {
          printf("\nswitching...\n");
          //Switch the sign of the first two rows of R
          for (int i = 0; i < 2; i++) 
               for (int j = 0; j < 3; j++)
                    R[i][j] = -R[i][j];
          //Switch the sign on the first two components of T
          Tx = -Tx;
          Ty = -Ty;
     }

     //Step 6: Set up M and b of system (6.14) and use (6.15) to estimate Tz and fx
     Array2D<double> M(rows, 2);
     Array2D<double> b(rows, 1);
     for (int i = 0; i < rows; i++) {
          double X = (*corresp)[i][0];
          double Y = (*corresp)[i][1];
          double Z = (*corresp)[i][2];
          double x = (*corresp)[i][3];
          M[i][0] = x;
          M[i][1] = R[0][0]*X + R[0][1]*Y + R[0][2]*Z + Tx;
          b[i][0] = -x * (R[2][0]*X + R[2][1]*Y + R[2][2]*Z);     
     }
     Array2D<double> res = util.leastSquares(M, b);
     double Tz = res[0][0];
     fx = res[1][0];
     fy = fx / alpha;
     T[0][0] = Tx;
     T[0][1] = Ty;
     T[0][2] = Tz;

     printf("(fx = %.3f, fy = %.3f)\n", fx, fy);
     printf("(Tx, Ty, Tz) = (%.3f, %.3f, %.3f)\n", Tx, Ty, Tz);

}

struct Coord Camera::projectPixel(double wX, double wY, double wZ, bool expl, bool draw) {
     struct Coord toReturn;
     if (expl) {
          //Use the explicit parameters
          //r31Xw + r32Yw + r33Zw + Tz
          //Equation on pg. 127 of Trucco and Verri
          double w = R[2][0]*wX + R[2][1]*wY + R[2][2]*wZ + T[2][0];
          double x = R[0][0]*wX + R[0][1]*wY + R[0][2]*wZ + T[0][0];
          double y = R[1][0]*wX + R[1][1]*wY + R[1][2]*wZ + T[1][0];
          toReturn.x = lround(-fx * x / w);
          toReturn.y = lround(-fy * y / w);
     }
     else {
          //Use the implicit projection matrix
          Matrix<double> worldCoord(4, 1);
          worldCoord[0][0] = wX;
          worldCoord[1][0] = wY;
          worldCoord[2][0] = wZ;
          worldCoord[3][0] = 1.0;
          
          Matrix<double> projection = proj * worldCoord;
          
          //Scale the result back down by the "w coordinate"
          //(since the scale of the projection matrix is arbitrary)
          for (int i = 0; i < 2; i++) 
               projection[i][0] /= projection[2][0];

          toReturn.x = projection[0][0];
          toReturn.y = projection[1][0];
     }
     //printf("\n\n(%.3lf, %.3lf)\n\n", toReturn.x, toReturn.y);
     if (draw) {
     	u8 c_gray[] = {255, 255, 255};
     	image->draw_rectangle(toReturn.x - 5, toReturn.y - 5, toReturn.x + 5, toReturn.y + 5, c_gray);
		CImgDisplay main_disp(*image,"Projection Test",0);
		while (!main_disp.is_closed) {

		// Handle display window resizing (if any)
		if (main_disp.is_resized) main_disp.resize().display(*image);

			cimg::wait(20); // Temporize event loop
		}

     }
     return toReturn;
}

struct Pixel Camera::getPixel(int x, int y) {
	struct Pixel toReturn;
	if (x < 0 || x >= width || y < 0 || y >= height) {
		//Invalid pixel requested
		toReturn.x = -1;
		toReturn.y = -1;
		return toReturn;
	}
	toReturn.x = x;
	toReturn.y = y;
	toReturn.R = (*image)(x, y, 0);
	toReturn.G = (*image)(x, y, 1);
	toReturn.B = (*image)(x, y, 2);
	return toReturn;
}

void Camera::maskPixel(int x, int y) {
	mask[y*width + x] = true;
}

bool Camera::isMasked(int x, int y) {
	return mask[y*width + x];
}
