#ifndef VOXELCLOUD_H
#define VOXELCLOUD_H

#include "Voxel.h"

typedef unsigned int uint;

class VoxelCloud {
public:
     VoxelCloud(uint rx, uint ry, uint rz, double csize);
     VoxelCloud(const char* filename);
     ~VoxelCloud();
     void write(const char* filename);
     Voxel* voxelAt(uint x, uint y, uint z);
     
     uint resx, resy, resz;
     Voxel* voxels;
     double cellsize;
};

#endif
