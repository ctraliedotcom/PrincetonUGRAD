//Purpose: Given a set of points belonging to different classes, run RANSAC
//to fit a line through points of each class, and then attempt to 
//extract known 3D positions from those lines using corner detection
//along the lines


#include "Ransac.h"
#include "TNT_Utils.h"
#include <math.h>
#include <time.h>
#include <stdlib.h>
#include <stdio.h>
#include <assert.h>
#include <limits>
#include <CImg.h>

using namespace cimg_library;

/*class Point2D {
public:
 uint x;
 uint y;
 double I2; // small eigenvalue of covariance matrix of neighborhood around point
 u8 corner_type;

 Point2D(int x, int y, double I2) :
   x(x), y(y), I2(I2) { }

 static bool sort_points(Point2DPtr, Point2DPtr);

 bool in_neighborhood(Point2D&, int);
}; */

Point2D::Point2D(){}

Line2D::Line2D() {
	numPoints = 0;
	m = 0;
	b = 0;
}


Line2D::Line2D(double slope, double intercept) {
	m = slope;
	b = intercept;
	numPoints = 0;
}

Line2D::Line2D(double x1, double x2, double y1, double y2) {
	m = (y2 - y1) / (x2 - x1);
	b = y1 - m*x1;
	numPoints = 2;
}

double Line2D::getDist(double x, double y) {
	//double p_prime = y*sin(phi) + x*cos(phi);
	//return abs(p_prime - p);
	//TODO: Return perpendicular distance (I was having problem with this)
	return abs(y - m*x - b);
}

int Line2D::getY(int x) {
	return (int)(m*x + b);
}

//Using least squares, refit a model with all of the points 
//in the consensus set, and return the error (distance of each point)
//from this new model
double Line2D::refitModel() {
	numPoints = consensus_set.size();
	Array2D<double> A(numPoints, 2);
	Array2D<double> y(numPoints, 1);
	TNT_Utils util;
	for (size_t i = 0; i < numPoints; i++) {
		A[i][0] = consensus_set[i].x;
		A[i][1] = 1;
		y[i][0] = consensus_set[i].y;
	}
	Array2D<double> solution = util.leastSquares(A, y);
	m = solution[0][0];
	b = solution[1][0];
	error = 0;
	for (size_t i = 0; i < numPoints; i++) {
		error += getDist(consensus_set[i].x, consensus_set[i].y);
	}
	return error;
}


/////////////////////////////////////////
void swap(vector<Point2D>*points, size_t i1, size_t i2) {
	assert(i1 < points->size() && i2 < points->size());
	
	Point2D temp = (*points)[i1];
	(*points)[i1] = (*points)[i2];
	(*points)[i2] = temp;
}

//Carry out RANSAC on a vector of points
//Percentage is the percent of the points that should 
//participate in a candidate for a line
Line2D getLine(vector<Point2D>* points, double t, double percentage, bool draw) {
	Line2D bestLine;
	double minError = std::numeric_limits<double>::infinity();
	int totalPoints = points->size();
	bool foundCandidate = false;
	if (totalPoints < MIN_POINTS_PER_LINE) {
		//If there are too few points to ensure a decent line, don't
		//even bother doing RANSAC
		return bestLine;
	}
	//Perform RANSAC
	int iterations = 0;
	while (iterations < TOTAL_ITERATIONS) {
		//Select two random points from the data and create a line
		//from them
		size_t i1 = rand() % totalPoints;
		Point2D P1 = (*points)[i1];
		//Move first point to the back so it's not accidentally
		//taken twice as a random sample
		swap(points, i1, totalPoints-1);
		size_t i2 = rand() % (totalPoints - 1);
		Point2D P2 = (*points)[i2];
		swap(points, i2, totalPoints-2);
		
		Line2D model(P1.x, P2.x, P1.y, P2.y);
		model.consensus_set.push_back(P1);
		model.consensus_set.push_back(P2);
		double totalError = 0.0;
		//Check all of the points not yet in the consensus set
		for (int i = 0; i < totalPoints - 2; i++) {
			double error = model.getDist((*points)[i].x, (*points)[i].y);
			if (error < t) {
				//If the point is within reasonable error, add it to the
				//consensus set
				model.consensus_set.push_back((*points)[i]);
				totalError += error;
			}
		}
		//Form a better model with all of the points now in the
		//consensus set
		totalError = model.refitModel();
		double avgError = totalError / model.consensus_set.size();
		if (avgError < minError && 
			model.consensus_set.size() >= (size_t)lround(totalPoints * percentage)) {
			foundCandidate = true;
			minError = avgError;
			bestLine = model;
			bestLine.error = avgError;
		}
		iterations++;
	}
	if (draw) {
		u8 white[] = {255};
		u8 gray[] = {128};
		int dim = 500;
		CImg<u8> image(dim, dim);
		//draw all of the points first
		for (int i = 0; i < totalPoints; i++) {
			uint x = (*points)[i].x, y = (*points)[i].y;
			image.draw_rectangle(x - 2, y - 2, x + 2, y + 2, white);
		}
		//draw the line
		int lasty = bestLine.getY(0);
		for (int x = 1; x < dim; x++) {
			int y = bestLine.getY(x);
			image.draw_line(x - 1, lasty, x, y, gray);
			lasty = y;
		}
		//draw all of the points in the consensus set
		for (size_t i = 0; i < bestLine.consensus_set.size(); i++) {
			int x = bestLine.consensus_set[i].x;
			int y = bestLine.consensus_set[i].y;
			image.draw_rectangle(x - 2, y - 2, x + 2, y + 2, gray);
		}
		image.save("bestline.png");
	}
	if (!foundCandidate)
		bestLine.numPoints = 0;
	return bestLine;
}

//Compare the lines based on how many points are in the
//consensus set; used to help figure out the three strongest
//lines found in the image (we're hoping those lines are
//on the calibration target)
//Sort in descending order of points
bool LinesComparator(Line2D l1, Line2D l2) {
	return (l1.consensus_set.size() > l2.consensus_set.size());
}

Point2D intersect(Line2D* l1, Line2D* l2) {
	//if (l1->m == l2->m)
	//	return NULL; //Parallel lines don't intersect
	double m1 = l1->m, m2 = l2->m;
	double b1 = l1->b, b2 = l2->b;
	double x = (b2 - b1) / (m1 - m2);
	double y = m1*x + b1;
	Point2D ret;
	ret.x = (uint)x;
	ret.y = (uint)y;
	return ret;
}

//T is the threshold for adding a point to the consensus set
Ransac::Ransac(vector<Point2D> points, double t) {
	//Step 1: Segment the points into different classes
	for (size_t i = 0; i < points.size(); i++) {
		classpoints[points[i].corner_type].push_back(points[i]);
	}
	//Step 2: Do RANSAC on each class
	for (int i = 0; i < 8; i++) {
		Line2D line = getLine(&classpoints[i], t, 0.5, false);
		line.pointclass = i;
		classlines.push_back(line);
	}
	//Step 3: Find the three classes with the most points and intersect
	//them to find a corner of the box.
	sort(classlines.begin(), classlines.end(), LinesComparator);
	Line2D l1 = classlines[0];
	Line2D l2 = classlines[1];
	Line2D l3 = classlines[2];
	//If there aren't three classes with enough points then reject
	//this camera
	if (l3.consensus_set.size() < MIN_POINTS_PER_LINE)
		return;
	
	
	
	//Step 4: If step 3 passes, then figure out which direction to go 
	//along each line based on the angles that the lines make with each other,
	//and do corner detection over again along the line to find the points
}

//Use RANSAC to find the best color for a cluster of pixels in color space
RansacColor::RansacColor(vector<struct Pixel>* pixels, double t) {
	stdev = std::numeric_limits<double>::infinity();
	size_t totalPixels = pixels->size();
	bool foundCandidate = false;
	
	if (totalPixels == 0)  //Prevent an arithmetic exceptionZ
		return;
	
	int iterations = 0;
	while (iterations < TOTAL_ITERATIONS) {
		//Select a random pixel from the set of colors and cluster pixels
		//close to it
		size_t index = rand() % totalPixels;
		struct Pixel color = (*pixels)[index];
		vector<int> set;//The test consensus set
		set.push_back(index);
		
		//Check all of the pixels not yet in the consensus set
		for (size_t i = 0; i < pixels->size(); i++) {
			if (i == index)
				continue;
			struct Pixel testColor = (*pixels)[i];
			//Compute distance
			double dist = pow(testColor.R - color.R, 2) + pow(testColor.G - color.G, 2);
			dist += pow(testColor.B - color.B, 2);
			dist = sqrt(dist);
			if (dist < t) {
				set.push_back(i);
			}
		}
		
		//If less than half of the pixels reside in the consensus set,
		//then it's not even worth checking this model
		if (set.size() < totalPixels / 2) {
			//printf("Less than half pixels (%i / %i): ", set.size(), totalPixels);
			iterations++;
			continue;	
		}
		
		//Now check the average and standard deviation of this model
		uint totalR = 0, totalG = 0, totalB = 0;
		for (int i = 0; i < (int)set.size(); i++) {
			totalR += (*pixels)[set[i]].R;
			totalG += (*pixels)[set[i]].G;
			totalB += (*pixels)[set[i]].B;
		}
		u8 R = (u8)((double)totalR / (double)set.size()), G = (u8)((double)totalG / (double)set.size()), B = (u8)((double)totalB / (double)set.size());
	
		//Calculate the standard deviation of the pixel color
		double this_stdev = 0;
		for (int i = 0; i < (int)set.size(); i++) {
			this_stdev += pow((*pixels)[set[i]].R - R, 2);
			this_stdev += pow((*pixels)[set[i]].G - G, 2);
			this_stdev += pow((*pixels)[set[i]].B - B, 2);
		}
		this_stdev = sqrt(this_stdev / set.size());
		if (this_stdev < stdev) {
			foundCandidate = true;
			stdev = this_stdev;
			consensus_set = set;
			bestColor.R = R;
			bestColor.G = G;
			bestColor.B = B;
		}
		iterations++;
	}
}


//Use this to test RANSAC
/*int main(int argc, char** argv) {
	srand(time(0));//TODO: Move this to the beginning of the whole program
	if (argc < 5) {
		fprintf(stderr, "Usage: Ransac <m> <b> <t> <outliers>\n");
		return 1;
	}
	double m = atof(argv[1]);
	double b = atof(argv[2]);
	double t = atof(argv[3]);
	int outliers = atoi(argv[4]);
	int dim = 500;
	vector<Point2D> points;
	//First put in a bunch of points on the chosen line
	//purterbated slightly
	int x, y;
	for (int x = 0; x < dim; x += 4) {
		y = m*x + b + rand() % 5 - rand() % 5;
		if (y > dim || y < 0)
			continue;
		Point2D P;
		P.x = x;P.y = y;
		points.push_back(P);
	}
	//Now add a bunch of random points
	for (int i = 0; i < outliers; i++) {
		x = rand() % dim;
		y = rand() % dim;
		Point2D P;
		P.x = x;P.y = y;
		points.push_back(P);
	}
	//Now add some random points right off of the line
	printf("%i points\n", points.size());
	Line2D model = getLine(&points, t, 0.5, true);
	printf("Average error = %.3lf\n", model.error);
	printf("%.3lf, %.3lf\n", model.m, model.b);
	return 0;
}*/
