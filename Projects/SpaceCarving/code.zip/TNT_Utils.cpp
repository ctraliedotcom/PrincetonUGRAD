#include "TNT_Utils.h"
#include <assert.h>

TNT::Array2D<double> TNT_Utils::eye(int dim) {
     TNT::Array2D<double> ret(dim, dim);
     for (int i = 0; i < dim; i++) {
          for (int j = 0; j < dim; j++) {
               if (i == j)
                    ret[i][j] = 1;
               else
                    ret[i][j] = 0;     
          }
     }
     return ret;
}

//Since for some reason there's no matrix multiplication for Array2D....
TNT::Array2D<double> TNT_Utils::matmult(TNT::Array2D<double> a1, TNT::Array2D<double> a2) {
	if (a1.dim2() != a2.dim1()) {
		fprintf(stderr, "ERROR: Trying to multiply a %ix%i matrix by a %ix%i matrix\n", a1.dim1(), a1.dim2(), a2.dim1(), a2.dim2());
	}
     assert(a1.dim2() == a2.dim1());
     Array2D<double> ret(a1.dim1(), a2.dim2());
     for (int i = 0; i < a1.dim1(); i++) {
          for (int j = 0; j < a2.dim2(); j++) {
               ret[i][j] = 0;
               for (int k = 0; k < a1.dim2(); k++) {
                    ret[i][j] += a1[i][k] * a2[k][j];
               }
          }
     }
     return ret;
}

TNT::Array2D<double> TNT_Utils::leastSquares(TNT::Array2D<double> A, TNT::Array2D<double> y) {
	//(AT*A)^(-1)*AT*y
	Array2D<double> AT = transpose(A);
	Array2D<double> ATA = matmult(AT, A);
	Array2D<double> ATAinv = invert(ATA);
	if (ATAinv.dim1() == 0) {
		//This is to deal with the rare case that the
		//matrix is not invertible (JAMA returns a 0x0 matrix,
		//which obviously isn't good...just make it an identity 
		//matrix and hope for the best)
		ATAinv = eye(ATA.dim1());
	}
	return matmult(matmult(ATAinv, AT), y);
}

void TNT_Utils::print(Array2D<double> mat) {
     for (int i = 0; i < mat.dim1(); i++) {
          for (int j = 0; j < mat.dim2(); j++) {
               printf("%.3f ", mat[i][j]);
          }
          printf("\n");
     }
}

/******************************************************/
//The following code is borrowed from http://wiki.cs.princeton.edu/index.php/TNT
//to do matrix inversion and transposition with the TNT library
TNT::Array2D<double> TNT_Utils::invert(const TNT::Array2D<double> &M)
{
	assert(M.dim1() == M.dim2()); // square matrices only please

	// solve for inverse with LU decomposition
	JAMA::LU<double> lu(M);

	// create identity matrix
	TNT::Array2D<double> id(M.dim1(), M.dim2(), (double)0);
	for (int i = 0; i < M.dim1(); i++) id[i][i] = 1;

        // solves A * A_inv = Identity
	return lu.solve(id);
}

TNT::Array2D<double> TNT_Utils::transpose(const TNT::Array2D<double> &M)
{
	TNT::Array2D<double> tran(M.dim2(), M.dim1() );
	for(int r=0; r<M.dim1(); ++r)
		for(int c=0; c<M.dim2(); ++c)
			tran[c][r] = M[r][c];
	return tran;
}
/******************************************************/
