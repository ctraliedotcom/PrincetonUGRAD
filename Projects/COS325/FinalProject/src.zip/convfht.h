#ifndef CONVFHT_H
#define CONVFHT_H

#include "waveio.h"

int convolve(char* file1, char* file2, char* fileout);

#endif