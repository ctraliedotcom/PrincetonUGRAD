/***********************************************************/
/*     Wave I/O soundfile access routines                  */
/*      EDIT THIS FILE ONCE FOR YOUR ARCHITECTURE          */
/*      #define one of                                     */
/*          LITTLENDIAN (intel, Windows, Mac, or Linux)    */
/*           or BIGENDIAN (some Suns, NeXT, SGI, other)    */
/*      then compile the .c files and enjoy                */
/*                                                         */
/*      LITTLENDIAN will cause the programs to consume     */
/*          and yield .wav files                           */
/*      BIGENDIAN will cause the programs to consume       */
/*          and yield .snd files                           */
/*                                                         */
/*      (c) Perry R. Cook, 2002                            */
/***********************************************************/


#ifndef WAVEIO_H
#define WAVEIO_H

#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <math.h>

/*    #define BIGENDIAN   */
/*    #define LITTLENDIAN   */

#define _EXTENSION_ .wav
#define _EXTENSION_STRING_ ".wav"

/*********     WAV BigEndian File Version ***********************/

struct soundhdr {
  char  riff[4];        /* "RIFF"                                  */
  long  flength;        /* file length in bytes                    */
  char  wave[4];        /* "WAVE"                                  */
  char  fmt[4];         /* "fmt "                                  */
  long  block_size;     /* in bytes (generally 16)                 */
  short format_tag;     /* 1=PCM, 257=Mu-Law, 258=A-Law, 259=ADPCM */
  short num_chans;      /* 1=mono, 2=stereo                        */
  long  srate;          /* Sampling rate in samples per second     */
  long  bytes_per_sec;  /* bytes per second                        */
  short bytes_per_samp; /* 2=16-bit mono, 4=16-bit stereo          */
  short bits_per_samp;  /* Number of bits per sample               */
  char  data[4];        /* "data"                                  */
  long  dlength;        /* data length in bytes (filelength - 44)  */
};

FILE *opensoundin(char *filename,struct soundhdr *hdr);

FILE *opensoundout(char *filename, struct soundhdr *hdr);
void fillheader(struct soundhdr *hdr, long srate);

void closesoundout(FILE *file,long num_samples);

void closesoundin(FILE *file);

#endif