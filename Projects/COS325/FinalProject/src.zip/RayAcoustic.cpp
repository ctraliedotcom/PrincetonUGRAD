// Source file for the scene file viewer



////////////////////////////////////////////////////////////
// INCLUDE FILES
////////////////////////////////////////////////////////////

#ifdef _WIN32
#include <windows.h>
#define M_PI 3.1415925
#endif

#include <vector>
#include "R3/R3.h"
#include "R3Scene.h"
#include "Impulse.h"
#include "raytrace.h"


////////////////////////////////////////////////////////////
// GLOBAL VARIABLES
////////////////////////////////////////////////////////////


static char *filename = NULL;
static int max_depth = 3;
static double min_intensity = 0.0001;
static unsigned int min_timestep_length = 1;//Minimum length of timestep (msecs)
static vector<R3Ray> rays;
static vector<R3Intersects> hits;


// Display variables
static R3Scene *scene = NULL;
bool controlling_listener;//True if controlling listener, false if controlling beacon


// GLUT variables 

static int GLUTwindow = 0;
static int GLUTwindow_height = 512;
static int GLUTwindow_width = 512;
static int GLUTmodifiers = 0;
bool holding_W;
bool holding_S;
bool holding_A;
bool holding_D;
bool holding_Up;
bool holding_Down;
bool holding_Left;
bool holding_Right;


////////////////////////////////////////////////////////////
// SCENE DRAWING CODE
////////////////////////////////////////////////////////////

void DrawShape(R3Shape *shape)
{
  // Check shape type
  if (shape->type == R3_BOX_SHAPE) shape->box->Draw();
  else if (shape->type == R3_SPHERE_SHAPE) shape->sphere->Draw();
  else if (shape->type == R3_CYLINDER_SHAPE) shape->cylinder->Draw();
  else if (shape->type == R3_CONE_SHAPE) shape->cone->Draw();
  else if (shape->type == R3_MESH_SHAPE) shape->mesh->Draw();
  else fprintf(stderr, "Unrecognized shape type: %d\n", shape->type);
}



void LoadMatrix(R3Matrix *matrix)
{
  // Multiply matrix by top of stack
  // Take transpose of matrix because OpenGL represents vectors with 
  // column-vectors and R3 represents them with row-vectors
  R3Matrix m = matrix->Transpose();
  glMultMatrixd((double *) &m);
}



void LoadMaterial(R3Material *material) 
{
  GLfloat c[4];

  // Check if same as current
  static R3Material *current_material = NULL;
  if (material == current_material) return;
  current_material = material;

  // Compute "opacity"
  double opacity = 1 - material->kt.Luminance();

  // Load ambient
  c[0] = material->ka[0];
  c[1] = material->ka[1];
  c[2] = material->ka[2];
  c[3] = opacity;
  glMaterialfv(GL_FRONT_AND_BACK, GL_AMBIENT, c);

  // Load diffuse
  c[0] = material->kd[0];
  c[1] = material->kd[1];
  c[2] = material->kd[2];
  c[3] = opacity;
  glMaterialfv(GL_FRONT_AND_BACK, GL_DIFFUSE, c);

  // Load specular
  c[0] = material->ks[0];
  c[1] = material->ks[1];
  c[2] = material->ks[2];
  c[3] = opacity;
  glMaterialfv(GL_FRONT_AND_BACK, GL_SPECULAR, c);

  // Load emission
  c[0] = material->emission.Red();
  c[1] = material->emission.Green();
  c[2] = material->emission.Blue();
  c[3] = opacity;
  glMaterialfv(GL_FRONT_AND_BACK, GL_EMISSION, c);

  // Load shininess
  c[0] = material->shininess;
  glMaterialf(GL_FRONT_AND_BACK, GL_SHININESS, c[0]);

  // Load texture
  if (material->texture) {
    if (material->texture_index <= 0) {
      // Create texture in OpenGL
      GLuint texture_index;
      glGenTextures(1, &texture_index);
      material->texture_index = (int) texture_index;
      glBindTexture(GL_TEXTURE_2D, material->texture_index); 
      R2Image *image = material->texture;
      int npixels = image->NPixels();
      R2Pixel *pixels = image->Pixels();
      GLfloat *buffer = new GLfloat [ 4 * npixels ];
      R2Pixel *pixelsp = pixels;
      GLfloat *bufferp = buffer;
      for (int j = 0; j < npixels; j++) { 
        *(bufferp++) = pixelsp->Red();
        *(bufferp++) = pixelsp->Green();
        *(bufferp++) = pixelsp->Blue();
        *(bufferp++) = pixelsp->Alpha();
        pixelsp++;
      }
      glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_MIN_FILTER,GL_LINEAR);
      glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_MAG_FILTER,GL_LINEAR);
      glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_WRAP_S,GL_REPEAT);
      glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_WRAP_T,GL_REPEAT);
      glTexEnvi(GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE, GL_MODULATE);
      glTexImage2D(GL_TEXTURE_2D, 0, 4, image->Width(), image->Height(), 0, GL_RGBA, GL_FLOAT, buffer);
      delete [] buffer;
    }

    // Select texture
    glBindTexture(GL_TEXTURE_2D, material->texture_index); 
    glEnable(GL_TEXTURE_2D);
  }
  else {
    glDisable(GL_TEXTURE_2D);
  }

  // Enable blending for transparent surfaces
  if (opacity < 1) {
    glDepthMask(false);
    glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);
    glEnable(GL_BLEND);
  }
  else {
    glDisable(GL_BLEND);
    glBlendFunc(GL_ONE, GL_ZERO);
    glDepthMask(true);
  }
}



void LoadCamera(R3Scene *scene)
{
  // Set projection transformation
  glMatrixMode(GL_PROJECTION);
  glLoadIdentity();
  gluPerspective(360.0*scene->camera.yfov/M_PI, (GLdouble) GLUTwindow_width /(GLdouble) GLUTwindow_height, 
                 scene->camera.neardist, scene->camera.fardist);

  // Set scene->camera transformation
  R3Vector t = -(scene->camera.towards);
  R3Vector& u = scene->camera.up;
  R3Vector& r = scene->camera.right;
  GLdouble camera_matrix[16] = { r[0], u[0], t[0], 0, r[1], u[1], t[1], 0, r[2], u[2], t[2], 0, 0, 0, 0, 1 };
  glMatrixMode(GL_MODELVIEW);
  glLoadIdentity();
  glMultMatrixd(camera_matrix);
  glTranslated(-(scene->camera.eye[0]), -(scene->camera.eye[1]), -(scene->camera.eye[2]));
}



void LoadLights(R3Scene *scene)
{
  GLfloat buffer[4];

  // Load ambient light
  static GLfloat ambient[4];
  ambient[0] = scene->ambient[0];
  ambient[1] = scene->ambient[1];
  ambient[2] = scene->ambient[2];
  ambient[3] = 1;
  glLightModelfv(GL_LIGHT_MODEL_AMBIENT, ambient);

  // Load scene lights
  for (int i = 0; i < (int) scene->lights.size(); i++) {
    R3Light *light = scene->lights[i];
    int index = GL_LIGHT0 + i;

    // Temporarily disable light
    glDisable(index);

    // Load color
    buffer[0] = light->color[0];
    buffer[1] = light->color[1];
    buffer[2] = light->color[2];
    buffer[3] = 1.0;
    glLightfv(index, GL_DIFFUSE, buffer);
    glLightfv(index, GL_SPECULAR, buffer);

    // Load attenuation with distance
    buffer[0] = light->constant_attenuation;
    buffer[1] = light->linear_attenuation;
    buffer[2] = light->quadratic_attenuation;
    glLightf(index, GL_CONSTANT_ATTENUATION, buffer[0]);
    glLightf(index, GL_LINEAR_ATTENUATION, buffer[1]);
    glLightf(index, GL_QUADRATIC_ATTENUATION, buffer[2]);

    // Load spot light behavior
    buffer[0] = 180.0 * light->angle_cutoff / M_PI;
    buffer[1] = light->angle_attenuation;
    glLightf(index, GL_SPOT_CUTOFF, buffer[0]);
    glLightf(index, GL_SPOT_EXPONENT, buffer[1]);

    // Load positions/directions
    if (light->type == R3_DIRECTIONAL_LIGHT) {
      // Load direction
      buffer[0] = -(light->direction.X());
      buffer[1] = -(light->direction.Y());
      buffer[2] = -(light->direction.Z());
      buffer[3] = 0.0;
      glLightfv(index, GL_POSITION, buffer);
    }
    else if (light->type == R3_POINT_LIGHT) {
      // Load position
      buffer[0] = light->position.X();
      buffer[1] = light->position.Y();
      buffer[2] = light->position.Z();
      buffer[3] = 1.0;
      glLightfv(index, GL_POSITION, buffer);
    }
    else if (light->type == R3_SPOT_LIGHT) {
      // Load position
      buffer[0] = light->position.X();
      buffer[1] = light->position.Y();
      buffer[2] = light->position.Z();
      buffer[3] = 1.0;
      glLightfv(index, GL_POSITION, buffer);

      // Load direction
      buffer[0] = light->direction.X();
      buffer[1] = light->direction.Y();
      buffer[2] = light->direction.Z();
      buffer[3] = 1.0;
      glLightfv(index, GL_SPOT_DIRECTION, buffer);
    }
    else {
      fprintf(stderr, "Unrecognized light type: %d\n", light->type);
      return;
    }

    // Enable light
    glEnable(index);
  }
}

//For debugging purposes; draw the rays that have been cast out in random directions
void drawRays() {
	glDisable(GL_LIGHTING);
	glColor3f(1.0, 1.0, 1.0);
	glBegin(GL_LINES);
	for (int i = 0; i < rays.size(); i++) {
		R3Point P = rays[i].Line().Point();
		R3Point P2;
		R3Vector V = rays[i].Vector();
		if (hits[i].intersects) {
			P2 = hits[i].position;
			R3Point P3 = P2 + 0.1 * hits[i].normal;
			//Draw normal
			glColor3f(1, 0, 0);
			glVertex3f(P2.X(), P2.Y(), P2.Z());
			glVertex3f(P3.X(), P3.Y(), P3.Z());
			glColor3f(1, 1, 1);
		}
		else {
			P2 = P + 10 * V;
			glColor3f(0, 0, 1);
		}
	    glVertex3f(P.X(), P.Y(), P.Z());
		glVertex3f(P2.X(), P2.Y(), P2.Z());
	}
	glEnd();
	glEnable(GL_LIGHTING);
}


void DrawNode(R3Scene *scene, R3Node *node)
{
  SceneObject* listener = (SceneObject*)scene->listener;
  SceneObject* beacon = (SceneObject*)scene->beacon;
  if (node == listener->node && controlling_listener)
	  return;
  if (node == beacon->node && !controlling_listener)
	  return;
  // Push transformation onto stack
  glPushMatrix();
  LoadMatrix(&node->transformation);

  // Load material
  if (node->material) LoadMaterial(node->material);

  // Draw shape
  if (node->shape) DrawShape(node->shape);

  // Draw children nodes
  for (int i = 0; i < (int) node->children.size(); i++) 
    DrawNode(scene, node->children[i]);

  // Restore previous transformation
  glPopMatrix();
}


void DrawScene(R3Scene *scene) 
{
  // Load camera
  LoadCamera(scene);

  // Load lights
  LoadLights(scene);

  // Draw nodes recursively
  DrawNode(scene, scene->root);

  drawRays();
}

void startRayTracing() {
	SceneObject* listener = (SceneObject*)scene->listener;
	SceneObject* beacon = (SceneObject*)scene->beacon;
	R3Point right_ear = listener->position + listener->right*0.09;
	R3Point left_ear = listener->position - listener->right*0.09;
	
	
	//Start off of right ear
	vector<R3Ray> startRays = getRandomRays(right_ear, listener->right, NUMBER_RAYS);
	Impulse rightImpulse;
	//First: Trace ray directly from ear to beacon
	R3Vector V = beacon->position - right_ear;
	double beaconDist = V.Length();
	V.Normalize();
	R3Ray directRay(right_ear, V);
	R3Intersects directhit(0, 0);
	directhit.dontclip = true;
	directhit.skipcheck = true;
	directhit.skipNode = (R3Node*)listener->node;
	directhit.rayIntersectScene(&directRay, scene);
	if (!directhit.intersects || beaconDist < directhit.t) {
		printf("There is a direct path from right ear to beacon %f\n", beaconDist);
		rightImpulse.addImpulse(beaconDist / SPEED_OF_SOUND, 1.0 / (1 + beaconDist*beaconDist));
	}
	else {
		printf("Something is in the way of the beacon %f\n", directhit.t);
	}
	
	
	for (int i = 0; i < startRays.size(); i++) {
		//printf("Finished ray %i\n", i);
		R3Intersects hit(0, 0);
		hit.dontclip = true;
		hit.skipcheck = true;
		hit.skipNode = (R3Node*)listener->node;
		hit.rayIntersectScene(&startRays[i], scene);
		double intensity = 1.0;
		if (startRays[i].Line().Vector().Dot(listener->towards) < 0)
			intensity = -1.0;
		TraceRay(&startRays[i], &hit, scene, &rightImpulse, 0, 0, max_depth, intensity, min_intensity);
	}
	printf("Finished tracing rays...\n");
	rightImpulse.scaleToLoudness();//Convert to decibel scale
	//rightImpulse.Draw("right.jpg");
	rightImpulse.Write("right.wav", "test.wav", "convR.wav");


	printf("\n----------------------------------------------\n");

	//Now do the left ear
	startRays = getRandomRays(left_ear, -listener->right, NUMBER_RAYS);
	Impulse leftImpulse;
	//First: Trace ray directly from ear to beacon
	V = beacon->position - left_ear;
	beaconDist = V.Length();
	V.Normalize();
	directRay = R3Ray(left_ear, V);
	R3Intersects directhit2(0, 0);
	directhit2.dontclip = true;
	directhit2.skipcheck = true;
	directhit2.skipNode = (R3Node*)listener->node;
	directhit2.rayIntersectScene(&directRay, scene);
	if (!directhit2.intersects || beaconDist < directhit2.t) {
		printf("There is a direct path from left ear to beacon %f\n", beaconDist);
		leftImpulse.addImpulse(beaconDist / SPEED_OF_SOUND, 1.0 / (1 + beaconDist*beaconDist));
	}
	else {
		printf("Something is in the way of the beacon %f\n", directhit.t);
	}
	
	
	for (int i = 0; i < startRays.size(); i++) {
		//printf("Finished ray %i\n", i);
		R3Intersects hit(0, 0);
		hit.dontclip = true;
		hit.skipcheck = true;
		hit.skipNode = (R3Node*)listener->node;
		hit.rayIntersectScene(&startRays[i], scene);
		double intensity = 1.0;
		if (startRays[i].Line().Vector().Dot(listener->towards) < 0)
			intensity = -1.0;
		TraceRay(&startRays[i], &hit, scene, &leftImpulse, 0, 0, max_depth, intensity, min_intensity);
	}
	printf("Finished tracing rays...\n");
	leftImpulse.scaleToLoudness();//Convert to decibel scale
	//leftImpulse.Draw("left.jpg");
	leftImpulse.Write("left.wav", "test.wav", "convL.wav");
}


////////////////////////////////////////////////////////////
// GLUT USER INTERFACE CODE
////////////////////////////////////////////////////////////

void GLUTMainLoop(void)
{
  // Run main loop -- never returns 
  glutMainLoop();
}



void GLUTDrawText(const R3Point& p, const char *s)
{
  // Draw text string s and position p
  glRasterPos3d(p[0], p[1], p[2]);
  while (*s) glutBitmapCharacter(GLUT_BITMAP_HELVETICA_12, *(s++));
}
  



void GLUTStop(void)
{
  // Destroy window 
  glutDestroyWindow(GLUTwindow);

  // Delete scene
  delete scene;

  // Exit
  exit(0);
}



void GLUTResize(int w, int h)
{
  // Resize window
  glViewport(0, 0, w, h);

  // Resize camera vertical field of view to match aspect ratio of viewport
  scene->camera.yfov = atan(tan(scene->camera.xfov) * (double) h/ (double) w); 

  // Remember window size 
  GLUTwindow_width = w;
  GLUTwindow_height = h;

  // Redraw
  glutPostRedisplay();
}



void GLUTRedraw(void)
{
  // Clear window 
  R3Rgb background = scene->background;
  glClearColor(background[0], background[1], background[2], background[3]);
  glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

  // Draw scene surfaces
  glEnable(GL_LIGHTING);
  DrawScene(scene);

  // Draw scene edges
	/*glDisable(GL_LIGHTING);
	glColor3d(1 - background[0], 1 - background[1], 1 - background[2]);
	glPolygonMode(GL_FRONT_AND_BACK, GL_LINE);
	DrawScene(scene);
	glPolygonMode(GL_FRONT_AND_BACK, GL_FILL);*/

  // Swap buffers 
  glutSwapBuffers();
}    



void GLUTSpecial(int key, int x, int y)
{
// Process keyboard button event 
  switch (key) {
  case GLUT_KEY_DOWN:
	holding_Down = true;
    break;

  case GLUT_KEY_UP:
    holding_Up = true;
    break;

  case GLUT_KEY_LEFT:
    holding_Left = true;
    break;

  case GLUT_KEY_RIGHT:
    holding_Right = true;
    break;
  }

  // Remember modifiers 
  GLUTmodifiers = glutGetModifiers();
}

void GLUTSpecialUp(int key, int x, int y)
{
// Process keyboard button event 
  switch (key) {
  case GLUT_KEY_DOWN:
	holding_Down = false;
    break;

  case GLUT_KEY_UP:
    holding_Up = false;
    break;

  case GLUT_KEY_LEFT:
    holding_Left = false;
    break;

  case GLUT_KEY_RIGHT:
    holding_Right = false;
    break;
  }

  // Remember modifiers 
  GLUTmodifiers = glutGetModifiers();
}

void GLUTKeyboard(unsigned char key, int x, int y)
{
  // Process keyboard button event 
  switch (key) {
	  case 'R':
	  case 'r':
		  {
		  SceneObject* listener = (SceneObject*)scene->listener;
		  rays = getRandomRays(listener->position + 0.09*listener->right, listener->right, 30);
		  hits.clear();
		  for (int i = 0; i < rays.size(); i++) {
			R3Intersects hit(0, 0);
			hit.dontclip = true;
			hit.skipcheck = true;
			hit.skipNode = (R3Node*)listener->node;
			hit.rayIntersectScene(&rays[i], scene);
			hits.push_back(hit);
		  }
		  glutPostRedisplay();
		  }
	  break;
	  case 'C':
	  case 'c':
		  controlling_listener = !controlling_listener;
	  break;

	  case 'W':
	  case 'w':
		  holding_W = true;
	  break;

	  case 'S':
	  case 's':
		  holding_S = true;
	  break;

	  case 'A':
	  case 'a':
		  holding_A = true;
	  break;

	  case 'D':
	  case 'd':
		  holding_D = true;
	  break;

	  case 'Q':
	  case 'q':
		GLUTStop();
		break;

		//Initiate ray tracing
	  case ' ':
		startRayTracing();
		break;

	/*		R3Camera& c = scene->camera;
		printf("camera %g %g %g  %g %g %g  %g %g %g  (%g, %g)  %g %g \n",
			   c.eye[0], c.eye[1], c.eye[2], 
			   c.towards[0], c.towards[1], c.towards[2], 
			   c.up[0], c.up[1], c.up[2], 
			   c.xfov, c.yfov, c.neardist, c.fardist); */

	  case 27: // ESCAPE
		GLUTStop();
		break;
  }

  // Remember modifiers 
  GLUTmodifiers = glutGetModifiers();
}

void GLUTKeyboardUp(unsigned char key, int x, int y)
{
  // Process keyboard button event 
  switch (key) {
	  case 'W':
	  case 'w':
		  holding_W = false;
	  break;

	  case 'S':
	  case 's':
		  holding_S = false;
	  break;

	  case 'A':
	  case 'a':
		  holding_A = false;
	  break;

	  case 'D':
	  case 'd':
		  holding_D = false;
	  break;
  }

  // Remember modifiers 
  GLUTmodifiers = glutGetModifiers();
}

//Use this callback function to do WSAD and arrowkey control
void Timestep(int value) {
	double STEP_SIZE = 0.01;
	SceneObject* obj;
	if (controlling_listener)
		obj = (SceneObject*)scene->listener;
	else
		obj = (SceneObject*)scene->beacon;

	//Let the user manipulate the object position/orientation based on arrow keys
	if (holding_W)
		obj->position += STEP_SIZE*obj->towards;
	if (holding_S)
		obj->position -= STEP_SIZE*obj->towards;
	if (holding_D)
		obj->position += STEP_SIZE*obj->right;
	if (holding_A)
		obj->position -= STEP_SIZE*obj->right;
	if (holding_Left) {
		obj->towards.Rotate(obj->up, STEP_SIZE);
		obj->right.Rotate(obj->up, STEP_SIZE);
	}
	if (holding_Right) {
		obj->towards.Rotate(obj->up, -STEP_SIZE);
		obj->right.Rotate(obj->up, -STEP_SIZE);
	}
	if (holding_Up) {
		obj->towards.Rotate(obj->right, STEP_SIZE);
		obj->up.Rotate(obj->right, STEP_SIZE);
	}
	if (holding_Down) {
		obj->towards.Rotate(obj->right, -STEP_SIZE);
		obj->up.Rotate(obj->right, -STEP_SIZE);
	}

	R3Node* node = (R3Node*)obj->node;
	node->transformation = obj->getMatrix();

	//Place the camera where the user is
	R3Camera* camera = &scene->camera;
	camera->eye = obj->position;
	camera->right = obj->right;
	camera->towards = obj->towards;
	camera->up = obj->up;
	camera->fardist = 1000;

	//Re-register timestep callback for next timestep
	glutTimerFunc(min_timestep_length, Timestep, 1);
	//Redraw updated scene
	glutPostRedisplay();
}

void GLUTInit(int *argc, char **argv)
{
  // Open window 
  glutInit(argc, argv);
  glutInitWindowPosition(100, 100);
  glutInitWindowSize(GLUTwindow_width, GLUTwindow_height);
  glutInitDisplayMode(GLUT_DOUBLE | GLUT_RGB | GLUT_DEPTH); // | GLUT_STENCIL
  GLUTwindow = glutCreateWindow("Binaural Acoustic Ray Tracer");

  // Initialize GLUT callback functions 
  glutReshapeFunc(GLUTResize);
  glutDisplayFunc(GLUTRedraw);
  glutKeyboardFunc(GLUTKeyboard);
  glutKeyboardUpFunc(GLUTKeyboardUp);
  glutSpecialFunc(GLUTSpecial);
  glutSpecialUpFunc(GLUTSpecialUp);
  glutTimerFunc(min_timestep_length, Timestep, 1);

  // Initialize graphics modes 
  glEnable(GL_NORMALIZE);
  glEnable(GL_LIGHTING);
  glEnable(GL_DEPTH_TEST);
  glLightModeli(GL_LIGHT_MODEL_LOCAL_VIEWER, GL_TRUE);
}




////////////////////////////////////////////////////////////
// PROGRAM ARGUMENT PARSING
////////////////////////////////////////////////////////////

int 
ParseArgs(int argc, char **argv)
{
  // Innocent until proven guilty
  int print_usage = 0;

  // Parse arguments
  argc--; argv++;
  while (argc > 0) {
    if ((*argv)[0] == '-') {
      if (!strcmp(*argv, "-help")) { print_usage = 1; }
      else if (!strcmp(*argv, "-max_depth")) { argc--; argv++; max_depth = atoi(*argv); }
      else if (!strcmp(*argv, "-min_intensity")) { argc--; argv++; min_intensity = atof(*argv); }
      else { fprintf(stderr, "Invalid program argument: %s", *argv); exit(1); }
      argv++; argc--;
    }
    else {
      if (!filename) filename = *argv;
      else { fprintf(stderr, "Invalid program argument: %s", *argv); exit(1); }
      argv++; argc--;
    }
  }

  // Check filename
  if (!filename || print_usage) {
    printf("Usage: RayAcoustic <filename> -max_depth <int>  -min_intensity <real>\n");
    return 0;
  }

  // Return OK status 
  return 1;
}



////////////////////////////////////////////////////////////
// SCENE READING
////////////////////////////////////////////////////////////


R3Scene *
ReadScene(const char *filename)
{
  // Allocate scene
  R3Scene *scene = new R3Scene();
  if (!scene) {
    fprintf(stderr, "Unable to allocate scene\n");
    return NULL;
  }

  // Read file
  if (!scene->Read(filename)) {
    fprintf(stderr, "Unable to read scene from %s\n", filename);
    return NULL;
  }

  // Provide default camera
  if (scene->camera.xfov == 0) {
    double scene_radius = scene->BBox().DiagonalRadius();
    R3Point scene_center = scene->BBox().Centroid();
    scene->camera.towards = R3Vector(0, 0, -1);
    scene->camera.up = R3Vector(0, 1, 0);
    scene->camera.right = R3Vector(1, 0, 0);
    scene->camera.eye = scene_center - 3 * scene_radius * scene->camera.towards;
    scene->camera.xfov = 0.5;
    scene->camera.yfov = 0.5;
    scene->camera.neardist = 0.01 * scene_radius;
    scene->camera.fardist = 100 * scene_radius;
  }

  // Provide default light
  if (scene->NLights() == 0) {
    // Create first directional light
    R3Light *light = new R3Light();
    light->type = R3_DIRECTIONAL_LIGHT;
    light->color = R3Rgb(1,1,1,1);
    light->position = R3Point(0, 0, 0);
    light->direction = R3Vector(-3,-4,-5);
    light->constant_attenuation = 0;
    light->linear_attenuation = 0;
    light->quadratic_attenuation = 0;
    light->angle_attenuation = 0;
    light->angle_cutoff = M_PI;
    scene->lights.push_back(light);

    // Create second directional light
    light = new R3Light();
    light->type = R3_DIRECTIONAL_LIGHT;
    light->color = R3Rgb(0.5, 0.5, 0.5, 1);
    light->position = R3Point(0, 0, 0);
    light->direction = R3Vector(3,2,3);
    light->constant_attenuation = 0;
    light->linear_attenuation = 0;
    light->quadratic_attenuation = 0;
    light->angle_attenuation = 0;
    light->angle_cutoff = M_PI;
    scene->lights.push_back(light);
  }

  // Return scene
  return scene;
}



////////////////////////////////////////////////////////////
// MAIN
////////////////////////////////////////////////////////////

int 
main(int argc, char **argv)
{
  // Initialize GLUT
  GLUTInit(&argc, argv);

  // Parse program arguments
  if (!ParseArgs(argc, argv)) exit(1);

  // Read scene
  scene = ReadScene(filename);
  if (!scene) exit(-1);

  if (scene->listener == NULL) {
	  fprintf(stderr, "ERROR: No listener specified in scene file\n");
	  return 1;
  }

  if (scene->beacon == NULL) {
	  fprintf(stderr, "ERROR: No beacon specified in scene file\n");
	  return 1;
  }

  controlling_listener = true;

  // Run GLUT interface
  GLUTMainLoop();

  // Return success 
  return 0;
}









