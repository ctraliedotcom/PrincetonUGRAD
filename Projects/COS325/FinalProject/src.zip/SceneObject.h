//Used to define a position/orientation for the
//listener and beacon(s)

#ifndef SCENEOBJECT_H
#define SCENEOBJECT_H

#include "R3/R3.h"

class SceneObject {
public:
	SceneObject();
	R3Point position;
	R3Vector right;
	R3Vector towards;
	R3Vector up;
	void* node;
	R3Matrix getMatrix();
};

#endif