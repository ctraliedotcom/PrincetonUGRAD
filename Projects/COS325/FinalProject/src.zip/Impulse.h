#ifndef IMPULSE_H
#define IMPULSE_H

#include <map>
#include <vector>
#include "R3/R3.h"
#include "R2/R2.h"

#define INTENSITY_SCALE 200
#define SRATE 44100
#define PEAKMAX 30000
#define MAX_LOUDNESS 100 //100 decibels


//Used as a comparator for the map
struct Compare {
	bool operator()(const double t1, const double t2) const {
		return (t1 < t2);
	}
};



//This class will store the empirically calculated impulse
//response of each scene
class Impulse {
public:
	Impulse();
	double max_time;
	double max_intensity;

	//Has a set of times (keys) with associated amplitudes
	//Use a map so that they will automatically be sorted by time
	map<double, double, Compare> impulses;	

	void addImpulse(double time, double intensity);
	void scaleToLoudness();
	void Draw(char* filename);//"Draw" the impulse response to a file
	//(helpful for debugging and visualization before resampling)
	void writeFile(char* filename, double* sampleAmps, int numSamples);
	void Write(char* impulse, char* sound, char* out);
};

#endif