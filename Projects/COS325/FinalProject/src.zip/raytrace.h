// Include file for ray tracing code

#ifndef RAYTRACE_H
#define RAYTRCE_H

const double PI = 3.1415925;
const double SPEED_OF_SOUND = 334.0;
#include <vector>
#include "Impulse.h"

static int NUMBER_RAYS = 10000;

void TraceRay(R3Ray* ray, R3Intersects* hit, R3Scene* scene, Impulse* impulse,
			  double time, int depth, int maxdepth, double intensity, double min_intensity);

vector<R3Ray> getRandomRays(R3Point P, R3Vector n, int num);

#endif