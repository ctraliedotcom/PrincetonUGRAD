#include "SceneObject.h"

SceneObject::SceneObject() {
	position = R3zero_point;
	right = R3Vector(1, 0, 0);
	towards = R3Vector(0, 0, -1);
	up = R3Vector(0, 1, 0);
}

R3Matrix SceneObject::getMatrix() {
	R3Matrix m(right[0], up[0], towards[0], position[0],
			   right[1], up[1], towards[1], position[1],
			   right[2], up[2], towards[2], position[2],
			   0, 0, 0, 1);
	return m;
}