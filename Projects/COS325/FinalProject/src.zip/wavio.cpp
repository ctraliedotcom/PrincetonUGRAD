#include "waveio.h"

FILE *opensoundin(char *filename,struct soundhdr *hdr)    {
    FILE *myfile;
    /*   check file name for .wav extension */
    if (filename[strlen(filename)-1] == 'v')  {
        myfile = fopen(filename,"rb");
        if (!myfile) {
            printf("Open Input File Error!!\n");
            myfile = 0;
        }
        else {
            fread(hdr,1,44,myfile);
        }
    }
    else {
        printf("You must specify a valid .wav file name\n");
        myfile = 0;
    }
    return myfile;
}

FILE *opensoundout(char *filename, struct soundhdr *hdr)    {
    FILE *myfile;
    /*   check file name for .wav or .snd extension */
    if (filename[strlen(filename)-1] == 'v')   {
        myfile = fopen(filename,"wb");
        if (!myfile) {
            printf("Open Output File Error!!\n");
            myfile = 0;
        }
        else     {
            fwrite(hdr,1,44,myfile);
        }
    }
    else {
        printf("You must specify a valid .wav file name\n");
        myfile = 0;
    }
    return myfile;
}

void fillheader(struct soundhdr *hdr, long srate)      {
    struct soundhdr myhdr = {"RIF",88244,"WAV","fmt",16,1,1,
                                 44100,88200,2,16,"dat",88200};
    myhdr.srate = srate;
    myhdr.bytes_per_sec = srate*2;
    myhdr.riff[3] = 'F';
    myhdr.wave[3] = 'E';
    myhdr.fmt[3] = ' ';
    myhdr.data[3] = 'a';
    *hdr = myhdr;

}

void closesoundout(FILE *file,long num_samples)      {
    long bytes;
    bytes = num_samples * 2;
    fseek(file,40,SEEK_SET); // jump to data length
    fwrite(&bytes,4,1,file);
    bytes = bytes + 44;
    fseek(file,4,SEEK_SET); // jump to total file size
    fwrite(&bytes,4,1,file);
    fclose(file);
}

void closesoundin(FILE *file)      {
    fclose(file);
} 