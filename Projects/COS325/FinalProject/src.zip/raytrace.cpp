// Source file for raytracing code


// Include files

#ifdef _WIN32
#include <windows.h>
#endif

#include <ctime>
#include "R2/R2.h"
#include "R3/R3.h"
#include "R3Scene.h"
#include "raytrace.h"
#include "SceneObject.h"
#include "Impulse.h"

//NOTE: t is the parameter for the ray P0 + tV; assuming V
//is a unit vector, t describes the distance the ray had to travel
//to get to the point where it hit something
double getTime(double t) {
	return t / SPEED_OF_SOUND;	
}

double randomDouble() {
	return ((double)rand() / (double)RAND_MAX);
}

//Send out a bunch of rays in random directions about the semicircle define by 
//point P and normal n
vector<R3Ray> getRandomRays(R3Point P, R3Vector n, int num) {
	vector<R3Ray> toReturn;
	R3Vector right(-n.Z(), 0, n.X());//A vector perpendicular to n
	right.Normalize();
	for (int i = 0; i < num; i++) {
		R3Vector V = n;//Direction vector for ray
		//choose some random spherical coordinates
		double phi = PI * randomDouble()/2;
		double XZAngle = 2*PI*randomDouble();
		V.Rotate(right, phi);
		V.Rotate(n, XZAngle);
		toReturn.push_back(R3Ray(P, V));
		//printf("%f %f %f\n", V.X(), V.Y(), V.Z());
		if (V.Dot(n) < 0)
			fprintf(stderr, "ERROR: Randomly generated ray did not lie in upper semicircle\n");
	}
	return toReturn;
}


void TraceRay(R3Ray* ray, R3Intersects* hit, R3Scene* scene, Impulse* impulse,
			  double time, int depth, int maxdepth, double intensity, double min_intensity) {
	if (!hit->intersects) {
		printf("Ray did not intersect anything: (%f %f %f)\n",
			ray->Line().Vector().X(), ray->Line().Vector().Y(), ray->Line().Vector().Z());
		return;
	}
	SceneObject* beacon = (SceneObject*)scene->beacon;
	R3Material* mat = hit->intersectNode->material;
	double dt = getTime(hit->t);//The elapsed time
	if (dt < 0)
		fprintf(stderr, "ERROR: Encountered a negative t %f\n", dt);
	double newTime = time + dt;
	//I = I0 / (1 + d^2); inverse square intensity dropoff
	//put the 1 to prevent divide by zero error
	double newIntensity = intensity / (1 + hit->t*hit->t);
	//If this ray hit the beacon (boombox) directly, don't send out
	//any more rays
	if (mat->beacon) {
		//printf("direct hit\n");
		impulse->addImpulse(newTime, newIntensity);
		return;
	}

	//Create a vector from the beacon to the hit position
	R3Vector L = beacon->position - hit->position;
	double beaconDistSquared = L.Dot(L);
	double sd = mat->sd;
	double ss = mat->ss;
	double st = mat->st;
	L.Normalize();

//Check for other objects blocking path of sound
	//Cast a ray from the position of intersection to the beacon
	R3Vector blockV = L;
	blockV.Normalize();
	R3Ray blockRay(hit->position, blockV);
	R3Intersects blockCheck(0, 0);
	blockCheck.dontclip = true;
	blockCheck.skipcheck = true;
	blockCheck.skipNode = hit->intersectNode;
	blockCheck.rayIntersectScene(&blockRay, scene);
	//Then there is a direct path from the hit position to the beacon
	if (!blockCheck.intersects || blockCheck.intersectNode == beacon->node) {
		if (L.Dot(hit->normal) >= 0) {//Make sure it's on upper half of hemisphere
			R3Vector R = hit->normal * (2*L.Dot(hit->normal)) - L;//Reflect across normal
			R3Vector V2 = ray->Line().Point() - hit->position;
			V2.Normalize();
			//Diffuse
			//toReturn += sd * L.Dot(hit->normal) * I;
			//Specular
			if (V2.Dot(R) > 0) {
				double specularIntensity = ss * pow(V2.Dot(R), 1) * newIntensity;
				specularIntensity /= (1 + beaconDistSquared);
				impulse->addImpulse(newTime + getTime(sqrt(beaconDistSquared)), specularIntensity);
			}
		}
	}
	return;
	//if (depth > 0)
	//	printf("%i ", depth);
	//Secondary rays
	R3Vector VR = ray->Line().Point() - hit->position;
	if (VR.Dot(hit->normal) < 0) //Make sure in upper half hemisphere
		return;
	R3Vector reflectDirection = hit->normal * VR.Dot(hit->normal) * 2 - VR;
	reflectDirection.Normalize();
	if (depth < maxdepth && abs(intensity) >= min_intensity) {
		R3Point P = hit->position;
		R3Vector V = hit->normal;
		vector<R3Ray> secondaryRays = getRandomRays(P, V, 10);
		for (int i = 0; i < secondaryRays.size(); i++) {
			R3Vector rV = secondaryRays[i].Line().Vector();
			double scale = rV.Dot(reflectDirection);
			R3Intersects secondaryHit(0, 0);
			secondaryHit.dontclip = true;
			secondaryHit.skipcheck = true;
			secondaryHit.skipNode = hit->intersectNode;
			secondaryHit.rayIntersectScene(&secondaryRays[i], scene);
			if (secondaryHit.intersects) {
				TraceRay(&secondaryRays[i], &secondaryHit, scene, impulse, newTime, 
					depth + 1, maxdepth, newIntensity * scale, min_intensity);
			}
		}
	}
}