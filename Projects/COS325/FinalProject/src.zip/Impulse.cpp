#include "Impulse.h"
#include "convfht.h"

Impulse::Impulse() {
	max_time = 0.001;
	max_intensity = 0.001;
}

void Impulse::addImpulse(double time, double intensity) {
	impulses[time] += intensity;
	if (time > max_time)
		max_time = time;
	if (abs(intensity) > max_intensity)
		max_intensity = abs(intensity);
}

void Impulse::scaleToLoudness() {
	map<double, double, Compare>::iterator iter = impulses.begin();
	double min_intensity = pow(10.0, -12.0);
	while (iter != impulses.end()) {
		double time = (*iter).first;
		double intensity = (*iter).second;
		//Put this on the decibel scale
		if (intensity < min_intensity)
			impulses[time] = 0;
		else
			impulses[time] = 20 * log(abs(intensity) / min_intensity);
		if (intensity < 0) {
			impulses[time] *= -1;
		}
		iter++;
	}
}

void Impulse::Draw(char* filename) {
	int width = 1000;
	int height = 200;
	R2Image image(width, height);
	double timescale = (double)width / max_time;
	double intensityscale = 0.5 * (double)height / MAX_LOUDNESS;

	printf("%i total impulses found\n", impulses.size());
	map<double, double, Compare>::iterator iter = impulses.begin();
	while (iter != impulses.end()) {
		double time = (*iter).first;
		double intensity = (*iter).second;
		//printf("%f sec: %f\n", time, intensity);
		int i = (int)(time * timescale);
		int h = (int)(intensity * intensityscale);
		if (intensity > 0) {
			for (int j = height / 2; j < height / 2 + h; j++)
				image.SetPixel(i, j, R2Pixel(1, 1, 1, 0));
		}
		else {
			for (int j = height / 2 + h; j < height / 2; j++)
				image.SetPixel(i, j, R2Pixel(1, 1, 1, 0));
		}
		iter++;
	}
	image.Write(filename);
}


//Used for help with neareast neighbor / bilinear interpolation
int search(vector<double>* a, int length, double time) {
	int index = 0;
	while ( (*a)[index] < time && index < length - 1)
		index++;
	return index;
}

void Impulse::writeFile(char* filename, double* sampleAmps, int numSamples) {
	FILE* fileOut;
	struct soundhdr hdr;
	fillheader(&hdr, SRATE);
	fileOut = opensoundout(filename, &hdr);
	for (int i = 0; i < numSamples; i++) {
		short value = (short)(PEAKMAX / MAX_LOUDNESS * sampleAmps[i]);
		fwrite(&value, 1, 2, fileOut);
	}
	closesoundout(fileOut, numSamples);
}

//Write the impulse out to a .wav file
void Impulse::Write(char* impulse, char* sound, char* out) {
	vector<double> times;//List of sorted times
	map<double, double, Compare>::iterator iter = impulses.begin();
	while (iter != impulses.end()) {
		times.push_back((*iter).first);
		iter++;
	}
	double lastTime = times[times.size() - 1];
	printf("lastTime = %f\n", lastTime);
	int numSamples = (int)((double)SRATE * lastTime) + 1;
	double* sampleTimes = (double*)calloc(numSamples, sizeof(double));
	double* sampleAmps = (double*)calloc(numSamples, sizeof(double));
	printf("numHits = %i\n", times.size());
	printf("numSamples = %i\n", numSamples);
	for (int i = 0; i < numSamples; i++) {
		double time = (double)i / (double)SRATE;
		int index = search(&times, numSamples, time);//Find index of the closest time in the list
		double closestTime = times[index];
		if (abs(closestTime - time) < 3.0 / (double(SRATE)))
			sampleAmps[i] = impulses[closestTime];
		else if (index > 0) {
			closestTime = times[index - 1];
			if (abs(closestTime - time) < 3.0 / (double(SRATE)))
				sampleAmps[i] = impulses[closestTime];
		}
	}
	writeFile(impulse, sampleAmps, numSamples);
	convolve(impulse, sound, out);
	free(sampleTimes);
	free(sampleAmps);
}