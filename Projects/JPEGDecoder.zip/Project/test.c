#include "JPGObj.h"
#include "Htree.h"
#include "bitOps.h"
#include <string.h>

/*int main(void){
	FILE* f = fopen("16by16.jpg", "rb");
	WORD decoded;
	BYTE i, b;

	for(i=0; i<5; i++){
		getByte(f);	
	}
	b = getByte(f);
	i = 4;
	decoded = getFromCategory(9, &b, &i, f);
	if( (decoded & (0x8000)) > 0)
		printf("\n%i\n", (WORD)(decoded + 502));
	else
		printf("\n%i\n", decoded);
	return 0;
}*/

int main(int argc, char** argv){
  JPGObj_T test;
  test = JPGObj_new(argv[1], 0);
  if(test != NULL){
	JPGObj_free(test);
  }
  return 0;   
}

/*int main(void){
	WORD w = 0xFFd0;
	int i;
	for(i=0; i<16; i++){
		printf("%i", getBitW(w, i));
	}
	setBitW(&w, 1, 0);
	setBitW(&w, 14, 1);		
	printf("\n");
	for(i=0; i<16; i++){
		printf("%i", getBitW(w, i));
	}
}*/

/*int main(void){
	HTree_T tree;
	Coefficients coeff[3];
	BYTE b=0, bitPos = 8;
	BYTE bits[] = {1, 1, 2, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
	BYTE hValues[] = {0x00, 0x03, 0x41, 0xF2};
	BYTE qTable[64];
	FILE* file = fopen("16by16.jpg", "rb");
	int i;
	tree = HTree_new(bits, hValues);
	for(i=0; i<12*24 + 2; i++){
		getByte(file);
	}
	for(i=0; i<64; i++){
		qTable[i] = 1;	
	}
	HTree_decode(tree, tree, qTable, coeff, 0, file, &b, &bitPos);
	printf("\n\n");
	for(i=0; i<64; i++){
		printf("%i ",(int)((short int)coeff[0].values[i]));	
	} 
	HTree_free(tree);
	return 0;		
}*/

