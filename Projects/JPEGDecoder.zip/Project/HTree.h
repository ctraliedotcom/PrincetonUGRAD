#include <stdlib.h>
#include <stdio.h>
#include <windows.h>
#include "JPGOBj.h"

#ifndef HTREE_H
#define HTREE_H

#define EOB 0x00
typedef struct HTree* HTree_T;

HTree_T HTree_new(BYTE* bits, BYTE* hValues);

/*Free the Huffman Tree from the memory heap*/
void HTree_free(HTree_T oHTree);

void HTree_decodeTest(HTree_T oHTree, BYTE* data, int length, BYTE* decoded);

void HTree_decode(HTree_T dcTable, HTree_T acTable, BYTE* qTable, 
				  Coefficients* coefficients, int index, FILE* file,
				  BYTE* b, BYTE* bitPos);
#endif
