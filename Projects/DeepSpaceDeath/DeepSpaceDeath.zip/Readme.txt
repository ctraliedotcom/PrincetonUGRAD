Sample Execution

SpaceSim test.scn -proc_gen test.bmp

This will load the ships/obstacles from test.scn and procedurally generate asteroids from test.bmp