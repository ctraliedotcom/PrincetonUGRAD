#ifndef R3COLLISION_H
#define R3COLLISION_H

#include <vector>
#include "R3/R3.h"
#include "R3Scene.h"
#include "GameObject.h"

class R3Collision {
public:
	R3Collision();
	GameObject* o1;
	GameObject* o2;
	bool collided;
	double t;
	void AABBCollide(R3Node* n1, GameObject* o1, R3Node* n2, GameObject* o2);
	void BSphereCollide(R3Node* n1, GameObject* o1, R3Node* n2, GameObject* o2);
};

void doCollisions(vector<R3Node*>* ships, vector<R3Node*>* obstacles, double dt);

#endif