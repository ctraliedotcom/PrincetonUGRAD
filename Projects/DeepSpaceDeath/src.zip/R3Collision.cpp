#include "R3Collision.h"

R3Collision::R3Collision() {
	collided = false;
}

void R3Collision::AABBCollide(R3Node* n1, GameObject* o1, R3Node* n2, GameObject* o2) {
	this->o1 = o1;
	this->o2 = o2;
	R3Box b1 = n1->bbox;
	b1.Transform(o1->getFullWorldMatrix());
	R3Box b2 = n2->bbox;
	b2.Transform(o2->getFullWorldMatrix());
	collided = b1.Intersects(b2);
}

void R3Collision::BSphereCollide(R3Node* n1, GameObject* o1, R3Node* n2, GameObject* o2) {
	this->o1 = o1;
	this->o2 = o2;
	R3Vector diff = o1->getWorldPos() - o2->getWorldPos();
	if (sqrt(diff.Dot(diff)) < o1->radius + o2->radius)
		collided = true;
}

//Figure out the new velocites of o1 and o2 based on the conservation
//of momentum
void doResponse(GameObject* o1, GameObject* o2, double dt, bool play_sound) {
	R3Vector collideAxis = o1->getWorldPos() - o2->getWorldPos();
	R3Vector V1 = o1->velocity;
	R3Vector V2 = o2->velocity;
	R3Vector V1C = V1;
	R3Vector V2C = V2;
	//Turn this into a 1D momentum problem by projecting the velocity
	//along the collision axis
	V1C.Project(collideAxis);
	V2C.Project(collideAxis);
	//The perpendicular components will remain unchanged
	R3Vector V1P = V1 - V1C;
	R3Vector V2P = V2 - V2C;

	//Calculate a random coefficient of restitution
	double CR = 0.5 + 0.5 * ((double)rand() / (double)RAND_MAX);
	double m1 = o1->mass;
	double m2 = o2->mass;
	//Now calculate the new vectors along the collision axis
	R3Vector V1Cf = ((CR + 1) * m2) * V2C + (m1 - CR*m2) * V1C;
	V1Cf /= (m1 + m2);
	R3Vector V2Cf = ((CR + 1) * m1) * V1C + (m2 - CR*m1) * V2C;
	V2Cf /= (m1 + m2);
	//Now set the velocities to their new value
	o1->velocity = V1Cf + V1P;
	o2->velocity = V2Cf + V2P;

	//Now approximate the force based on the time it took to change the impulse
	//Change in momentum = mass * change in velocity
	double dp = m1*(V1 - o1->velocity).Length(); 
	double force = dp / dt;
	force /= 4;
	//printf("force: %f\n", force);
	//TODO: Dividing the force by 4 seems to make it a reasonable range (experimentally)
	o1->doDamage(force);
	o2->doDamage(force);
	if (play_sound)
		sndPlaySound("Sounds/crash.wav", SND_ASYNC);
}

void doCollisions(vector<R3Node*>* ships, vector<R3Node*>* obstacles, double dt) {
	//Right now, take all pairs of objects and check them against each other
	bool play_sound = false;
	for (int i = 0; i < (*ships).size(); i++) {
		R3Collision* test = new R3Collision();
		Ship* thisShip = (Ship*)(*ships)[i]->shape->ship;
		R3Point oldPos = thisShip->position;
		thisShip->move(dt);//As a first approximation, just move one of the objects
		//and keep the other ones still

		//Check the ship against all other ships
		for (int j = i + 1; j < (*ships).size() && !test->collided; j++) {
			Ship* otherShip = (Ship*)(*ships)[j]->shape->ship;
			test->AABBCollide((*ships)[i], thisShip, (*ships)[j], otherShip);
			if (test->collided) {
				//If one of the ships is the player ship, play a crash sound
				if (!thisShip->is_ai || !otherShip->is_ai)
					play_sound = true;
				thisShip->position = oldPos;//Move ship back to where it was
				doResponse(thisShip, otherShip, dt, play_sound);
			}
		}
		//Check the ship against all obstacles
		for (int j = 0; j < (*obstacles).size() && !test->collided; j++) {
			Obstacle* obstacle = (Obstacle*)(*obstacles)[j]->shape->obstacle;
			if (obstacle->asteroid)
				test->BSphereCollide((*ships)[i], thisShip, (*obstacles)[j], obstacle);
			else
				test->AABBCollide((*ships)[i], thisShip, (*obstacles)[j], obstacle);
			if (test->collided) {
				if (!thisShip->is_ai)
					play_sound = true;
				thisShip->position = oldPos;
				doResponse(thisShip, obstacle, dt, play_sound);
			}
		}
		delete test;
	}
	//Check the obstacles against all other obstacles
	for (int i = 0; i < (*obstacles).size(); i++) {
		R3Collision* test = new R3Collision();
		Obstacle* thisObstacle = (Obstacle*)(*obstacles)[i]->shape->obstacle;
		R3Point oldPos = thisObstacle->position;
		thisObstacle->move(dt);
		for (int j = i + 1; j < (*obstacles).size() && !test->collided; j++) {
			Obstacle* otherObstacle = (Obstacle*)(*obstacles)[j]->shape->obstacle;
			if (thisObstacle->asteroid || otherObstacle->asteroid)
				test->BSphereCollide((*obstacles)[i], thisObstacle, (*obstacles)[j], otherObstacle);
			else
				test->AABBCollide((*obstacles)[i], thisObstacle, (*obstacles)[j], otherObstacle);
			if (test->collided) {
				thisObstacle->position = oldPos;//Move ship back to where it was
				doResponse(thisObstacle, otherObstacle, dt, false);
			}
		}
		delete test;
	}
}