#include "R3/R3.h"
#include "GameObject.h"
#include <ctime>

GameObject::GameObject () {
	resetAll();
}

GameObject::~GameObject() {
	//Free up the extra copy of the material we made
	delete node->material;
	delete explosion;
}

void GameObject::resetAll() {
	right = R3Vector(1, 0, 0);
	up = R3Vector(0, 1, 0);
	towards = R3Vector(0, 0, 1);
	position = R3Point(0, 0, 0);
	velocity = R3Vector(0, 0, 0);
	acceleration = R3Vector(0, 0, 0);
	transformations = R3identity_matrix;
	health = FULL_HEALTH;
	explosion = NULL;
}

void GameObject::TimeStep ( double dt, vector<R3Node*>* ships, vector<R3Node*>* obstacles )
{
	fprintf ( stderr, "GameObject::TimeStep ( %f )\n", dt );
}
          
void GameObject::Render () {
	fprintf ( stderr, "GameObject::Render ()\n" );
}

void GameObject::doDamage ( double damage )
{
	fprintf ( stderr, "GameObject::doDamage ( %f )\n", damage );
}

void GameObject::move(double dt) {
	velocity = velocity + acceleration*dt;
	position = position + velocity*dt;
	acceleration *= 0;
}

void Ship::move(double dt) {
	velocity = velocity + acceleration*dt;
	position = position + velocity*dt;
	acceleration *= 0;
	//If the velocity isn't lined up with the direction the
	//ship is facing (in the case of impact, for example),
	//decay the component that's causing the difference
	R3Vector residual = velocity - towards * (velocity.Dot(towards));
	velocity -= residual * 0.2;
	if (is_ai && velocity.Length() > MAX_VELOCITY) //If velocity got above the max threshold, decay it
		velocity *= 0.9;
	//printf("%f, %f, %f\n", residual.X(), residual.Y(), residual.Z());
}

R3Point GameObject::getWorldPos() {
	return transformations * position;
}

R3Matrix GameObject::getRotationMatrix() {
	return R3Matrix(right[0], up[0], towards[0], 0,
					right[1], up[1], towards[1], 0,
					right[2], up[2], towards[2], 0,
						0,		0,		0,		 1);
}

//This matrix helps with explosions
R3Matrix GameObject::getFullTranslationMatrix() {
	R3Matrix m(1, 0, 0, position[0],
			   0, 1, 0, position[1],
			   0, 0, 1, position[2],
			   0, 0, 0, 1);
	return transformations * m;
}

R3Matrix GameObject::getFullMatrix() {
	return R3Matrix(right[0], up[0], towards[0], position[0],
					right[1], up[1], towards[1], position[1],
					right[2], up[2], towards[2], position[2],
						0,		0,		0,		 1);
}

//Return the matrix that encodes all of the information to get from the
//scene graph transformations to the actual position/orientation of 
//the ship
R3Matrix GameObject::getFullWorldMatrix() {
	return transformations * getFullMatrix();
}

//Ship Subclass Functions       
Ship::Ship () {
  mass = 1;
  is_ai = true;
  max_centripetal_accel = 6;
  max_accel = 6;
  max_roll_rate = 1;
  shield_strength = FULL_SHIELD_STRENGTH;
  shield_recharge_rate = DEFAULT_SHIELD_RECHARGE_RATE;
  can_see_player = false;
  laser_cannon = new Laser ( this );
}

Ship::~Ship ()
{
	delete this->laser_cannon;
}

void Ship::TimeStep ( double dt, vector<R3Node*>* ships, vector<R3Node*>* obstacles )
{
	// maintain the ship's systems
	this->rechargeShields ( dt );
	( (Laser *)this->laser_cannon )->TimeStep ( dt, ships, obstacles );
}

void Ship::Think ( double dt, vector<R3Node*>* ships, vector<R3Node*>* obstacles, Ship* playerShip )
{
	this->determineIfCanSeePlayer ( ships, obstacles, playerShip );

	if ( this->health < 25.0 )
	{
		this->posture = POSTURE_KAMIKAZE;
		this->KamikazeThink ( dt, ships, obstacles, playerShip );
	}
	else
	{
		if ( this->shield_strength < 20.0 )
		{
			this->posture = POSTURE_DEFENSIVE;
			this->DefensiveThink ( dt, ships, obstacles, playerShip );
		}
		else
		{
			this->posture = POSTURE_OFFENSIVE;
			this->OffensiveThink ( dt, ships, obstacles, playerShip );
		}
	}
}

void Ship::KamikazeThink ( double dt, vector<R3Node*>* ships, vector<R3Node*>* obstacles, Ship* playerShip )
{
	int i;
	R3Vector target ( 0.0, 0.0, 0.0 );

	// avoid other ships that aren't the player
	for ( i = 0; i < (*ships).size (); i++ )
	{
		Ship *other_ai = (Ship *)( (*ships) [ i ]->shape->ship );

		if ( other_ai == this || other_ai == playerShip )
			continue;

		R3Vector other_ai_toward_this = this->getWorldPos () - other_ai->getWorldPos ();

		// do collision avoidance: if beyond 3 bounding box radii away from other ship, don't count its contribution
		if ( other_ai_toward_this.Length () < 5.0 * other_ai->node->bbox.DiagonalRadius () )
		{
			double weight = pow ( 2.0, -1.0 * other_ai_toward_this.Length () * other_ai_toward_this.Length () );
			
			R3Vector other_ai_toward_this_normalized = other_ai_toward_this;
			
			other_ai_toward_this_normalized.Normalize ();

			target += weight * other_ai_toward_this_normalized;
		}
	}

	// avoid obstacles
	for ( i = 0; i < (*obstacles).size (); i++ )
	{
		Obstacle *o = (Obstacle *)( (*obstacles) [ i ]->shape->obstacle );

		R3Vector obstacle_toward_this = this->getWorldPos () - o->getWorldPos ();

		// do collision avoidance
		if ( obstacle_toward_this.Length () < 5.0 * o->node->bbox.DiagonalRadius () )
		{
			double weight = pow ( 2.0, -1.0 * obstacle_toward_this.Length () * obstacle_toward_this.Length () );

			R3Vector obstacle_toward_this_normalized = obstacle_toward_this;

			obstacle_toward_this_normalized.Normalize ();

			target += weight * obstacle_toward_this_normalized;
		}
	}

	// move toward player's ship
	R3Vector toward_player_ship = playerShip->getWorldPos () - this->getWorldPos ();

	//double weight = pow ( 2.0, -1.0 * toward_player_ship.Length () * toward_player_ship.Length () );

	toward_player_ship.Normalize ();

	target += toward_player_ship;

	target.Normalize ();

	this->ChangeOrientation ( target, dt );

	if ( this->velocity.Length () < MAX_VELOCITY )
		this->accelForward ( this->max_accel );

	// fire at player, if can
	double max_firing_distance = 10.0;
	R3Vector toward_player = playerShip->getWorldPos () - this->getWorldPos ();

	if ( this->can_see_player && toward_player.Length () <= max_firing_distance )
	{
		double TEN_DEGREES_IN_RADIANS = 0.174532925;

		// if looking more or less at the player, fire!
		if ( acos ( toward_player.Dot ( this->towards ) / ( toward_player.Length () * this->towards.Length () ) ) < TEN_DEGREES_IN_RADIANS )
			( (Laser *)this->laser_cannon )->Fire ();			
	}
	else
	{
		( (Laser *)this->laser_cannon )->HoldFire ();
	}
}

void Ship::DefensiveThink ( double dt, vector<R3Node*>* ships, vector<R3Node*>* obstacles, Ship* playerShip )
{
	// algorithm is to move toward the:
	// 1) obstacle, or
	// 2) AI ship that's not in defensive posture
	// whichever's closest.  Goal is to move to a point beyond the obstacle/ship that's opposite the player:
	//
	//	playerShip					obstacle	(goal)
	//											  ^
	//											  |
	//											injured_ai
	bool haven_found = false;
	double min_distance;
	int i;
	GameObject *haven;	// nearest safe haven
	R3Box *haven_bbox;
	R3Vector target ( 0.0, 0.0, 0.0 );

	// where's the nearest offensive AI?
	for ( i = 0; i < (*ships).size (); i++ )
	{
		Ship *other_ai = (Ship *)( (*ships) [ i ]->shape->ship );

		if ( other_ai == this )
			continue;

		R3Vector other_ai_toward_this = this->getWorldPos () - other_ai->getWorldPos ();

		// do collision avoidance: if beyond 3 bounding box radii away from other ship, don't count its contribution
		if ( other_ai_toward_this.Length () < 5.0 * other_ai->node->bbox.DiagonalRadius () )
		{
			double weight = pow ( 2.0, -1.0 * other_ai_toward_this.Length () * other_ai_toward_this.Length () );
			
			R3Vector other_ai_toward_this_normalized = other_ai_toward_this;
			
			other_ai_toward_this_normalized.Normalize ();

			target += weight * other_ai_toward_this_normalized;
		}

		if ( other_ai == playerShip || other_ai->posture != POSTURE_OFFENSIVE )
			continue;
		// else, other_ai is an AI in offensive posture -> safe haven

		if ( !haven_found )
		{
			min_distance = other_ai_toward_this.Length ();
			haven = other_ai;
			haven_bbox = &( other_ai->node->bbox );
			haven_found = true;
		}
		else
		{
			if ( other_ai_toward_this.Length () < min_distance )
			{
				min_distance = other_ai_toward_this.Length ();
				haven = other_ai;
				haven_bbox = &( other_ai->node->bbox );
			}
		}
	}

	// where's the nearest obstacle?
	for ( i = 0; i < (*obstacles).size (); i++ )
	{
		Obstacle *o = (Obstacle *)( (*obstacles) [ i ]->shape->obstacle );

		R3Vector obstacle_toward_this = this->getWorldPos () - o->getWorldPos ();

		// do collision avoidance
		if ( obstacle_toward_this.Length () < 5.0 * o->node->bbox.DiagonalRadius () )
		{
			double weight = pow ( 2.0, -1.0 * obstacle_toward_this.Length () * obstacle_toward_this.Length () );

			R3Vector obstacle_toward_this_normalized = obstacle_toward_this;

			obstacle_toward_this_normalized.Normalize ();

			target += weight * obstacle_toward_this_normalized;
		}

		if ( !haven_found )
		{
			min_distance = obstacle_toward_this.Length ();
			haven = o;
			haven_bbox = &( o->node->bbox );
			haven_found = true;
		}
		else
		{
			if ( obstacle_toward_this.Length () < min_distance )
			{
				min_distance = obstacle_toward_this.Length ();
				haven = o;
				haven_bbox = &( o->node->bbox );
			}
		}
	}

	if ( haven_found )
	{
		// find the point on the other side of haven from the player's ship
		R3Vector player_toward_haven = haven->getWorldPos () - playerShip->getWorldPos ();

		player_toward_haven.Normalize ();

		R3Point destination = haven->getWorldPos () + player_toward_haven * ( 5.0 * haven_bbox->DiagonalRadius () );

		// move toward that point
		R3Vector toward_destination = destination - this->getWorldPos ();

		//double weight = pow ( 2.0, -1.0 * toward_destination.Length () * toward_destination.Length () );
		double weight = 0.01;
		if (player_toward_haven.Length() > 5.0 * haven_bbox->DiagonalRadius())
			weight = 1;
		else if (velocity.Dot(towards) > 0) //We want him to slow down, but not go backwards
			accelForward(-max_accel);
		toward_destination.Normalize ();

		target += weight * toward_destination;
	}

	// move toward the haven
	target.Normalize ();

	this->ChangeOrientation ( target, dt );

	if ( this->velocity.Length () < MAX_VELOCITY )
		this->accelForward ( this->max_accel );

	// fire at player, if can
	double max_firing_distance = 10.0;
	R3Vector toward_player = playerShip->getWorldPos () - this->getWorldPos ();

	if ( this->can_see_player && toward_player.Length () <= max_firing_distance )
	{
		double TEN_DEGREES_IN_RADIANS = 0.174532925;

		// if looking more or less at the player, fire!
		if ( acos ( toward_player.Dot ( this->towards ) / ( toward_player.Length () * this->towards.Length () ) ) < TEN_DEGREES_IN_RADIANS )
			( (Laser *)this->laser_cannon )->Fire ();			
	}
	else
	{
		( (Laser *)this->laser_cannon )->HoldFire ();
	}
}

void Ship::OffensiveThink(double dt, vector<R3Node*>* ships, 
			vector<R3Node*>* obstacles, Ship* playerShip) {
	R3Vector target ( 0.0, 0.0, 0.0 );
	R3Point my_world_pos = this->getWorldPos ();
	double max_firing_distance = 25.0;
	double max_positioning_error = 5.0;	// prevent oscillation in ai ship movements
	int i;

	// avoid other ships that aren't myself
	for ( i = 0; i < (*ships).size (); i++ )
	{
		Ship *other_ai = (Ship *)( (*ships) [ i ]->shape->ship );

		if ( other_ai == this || other_ai == playerShip )
			continue;	// don't count self, or player (yet)

		// compute this ship's contribution to my velocity vector
		R3Point other_world_pos = other_ai->getWorldPos ();

		R3Vector distance  = my_world_pos - other_world_pos;

		// if beyond 3 bounding box radii away from other ship, don't count its contribution
		if ( distance.Length () > 5.0 * (*ships) [ i ]->bbox.DiagonalRadius () )
			continue;

		double weight = pow ( 2.0, -1.0 * distance.Length () * distance.Length () );

		distance.Normalize ();
		
		target += weight * distance;
	}

	// avoid obstacles
	for ( i = 0; i < (*obstacles).size (); i++ )
	{
		Obstacle *o = (Obstacle *)( (*obstacles) [ i ]->shape->obstacle );

		// compute this obstacle's contribution to my velocity vector
		R3Point other_world_pos = o->getWorldPos ();

		R3Vector distance = my_world_pos - other_world_pos;

		// if beyond 3 bounding box radii away from obstacle, don't count its contribution
		if ( distance.Length () > 5.0 * (*obstacles) [ i ]->bbox.DiagonalRadius () )
			continue;

		double weight = pow ( 2.0, -1.0 * distance.Length () * distance.Length () );

		distance.Normalize ();
		
		target += weight * distance;
	}

// TODO: this is AI system debug code: red if the AI can see the player, gray otherwise
//if (this->can_see_player)
//this->node->material->ks.SetRed ( 1.0 );
//else
//this->node->material->ks.SetRed ( 0.0 );

	if ( this->can_see_player )
	{
		// move toward player's ship
		R3Point other_world_pos = playerShip->getWorldPos ();

		// construct a vector TO the player's ship
		R3Vector distance = other_world_pos - my_world_pos;

		if ( distance.Length () > max_firing_distance || distance.Length () < ( max_firing_distance - max_positioning_error ) )
		{
			// move away from the player if ai within max_firing_distance - max_position_error units
			if ( distance.Length () < ( max_firing_distance - max_positioning_error ) )
				distance.Flip ();
			// else, outside max_firing_distance units -> move toward player

			double weight = pow ( 2.0, -1.0 * distance.Length () * distance.Length () );

			distance.Normalize ();
			
			target += weight * distance;
		}
	}
	else	// cannot see player -> move toward another AI who can
	{
		bool found_an_ai = false;
		double distance_to_closest_ai;
		Ship *closest_ai;

		for ( i = 0; i < (*ships).size (); i++ )
		{
			Ship *other_ai = (Ship *)( (*ships) [ i ]->shape->ship );

			if ( other_ai == this || other_ai == playerShip )
				continue;

			if ( !other_ai->can_see_player )
				continue;

			R3Vector toward_closest_ai = other_ai->getWorldPos () - this->getWorldPos ();

			if ( !found_an_ai )
			{
				distance_to_closest_ai = toward_closest_ai.Length ();
				closest_ai = other_ai;
				found_an_ai = true;
			}
			else
			{
				if ( toward_closest_ai.Length () < distance_to_closest_ai )	// found an AI who can see player that's closer than all others found
				{
					distance_to_closest_ai = toward_closest_ai.Length ();
					closest_ai = other_ai;
				}
			}
		}

		if ( found_an_ai )
		{
			R3Vector toward_closest_ai = closest_ai->getWorldPos () - this->getWorldPos ();

			double weight = pow ( 2.0, -1.0 * toward_closest_ai.Length () * toward_closest_ai.Length () );

			toward_closest_ai.Normalize ();

			target += weight * toward_closest_ai;
		}
		// else not moving toward player or any AI -> just avoiding other ships & obstacles
	}

	target.Normalize ();

	R3Vector toward_player = playerShip->getWorldPos () - this->getWorldPos ();

	if ( target != R3zero_vector )
	{
		this->ChangeOrientation ( target, dt );

		if ( this->velocity.Length () < MAX_VELOCITY )
			this->accelForward ( this->max_accel );
	}
	else
	{
		//slow down and look at the player
		if (velocity.Dot(towards) > 0)
			accelForward(-max_accel);
		this->acceleration = R3zero_vector;

		if ( this->can_see_player )
			this->ChangeOrientation ( toward_player, dt );
	}

	if ( this->can_see_player && toward_player.Length () <= max_firing_distance )
	{
		double TEN_DEGREES_IN_RADIANS = 0.174532925;

		// if looking more or less at the player, fire!
		if ( acos ( toward_player.Dot ( this->towards ) / ( toward_player.Length () * this->towards.Length () ) ) < TEN_DEGREES_IN_RADIANS )
			( (Laser *)this->laser_cannon )->Fire ();
		else
			( (Laser *)this->laser_cannon )->HoldFire ();
	}
	else
	{
		( (Laser *)this->laser_cannon )->HoldFire ();
	}
}

void Ship::determineIfCanSeePlayer ( vector<R3Node*>* ships, vector<R3Node*>* obstacles, Ship* playerShip )
{
	int i;
	double player_intersect_t;
	R3Intersects intersection;

	// where does the ray intersect the player's ship's bounding box?
	for ( i = 0; i < (*ships).size (); i++ )
	{
		if ( (Ship *)( (*ships) [ i ]->shape->ship ) == playerShip )
			break;
	}

	if ( i == (*ships).size () )
	{
		fprintf ( stderr, "Ship::determineIfCanSeePlayer (): Warning! Couldn't find player's ship in ships vector.\n" );
		this->can_see_player = false;
		return;
	}

	R3Ray toward_player_ship ( this->getWorldPos (), playerShip->getWorldPos () - this->getWorldPos ());

	// construct a bounding box that takes into account player's position in world coords
	//R3Box player_ship_bbox ( playerShip->transformations * ( (*ships) [ i ]->bbox.Min () + playerShip->position ),
	//						 playerShip->transformations * ( (*ships) [ i ]->bbox.Max () + playerShip->position ) );

	intersection.rayIntersectSphere(&toward_player_ship, 
		&R3Sphere(playerShip->getWorldPos(), playerShip->radius));

	if ( !intersection.intersects || intersection.t < 0.0 )	// then something seriously wrong
	{
		fprintf ( stderr, "Ship::determineIfCanSeePlayer (): Warning! Ray pointed toward player's ship doesn't intersect player's ship or intersects it at a negative t!\n" );
		this->can_see_player = false;
		return;
	}

	player_intersect_t = intersection.t;

	// are there any intersections between this AI ship & other AI ships?
	for ( i = 0; i < (*ships).size (); i++ )
	{
		Ship *other_ship = (Ship *)( (*ships) [ i ]->shape->ship );

		if ( other_ship == this || other_ship == playerShip )
			continue;

		//R3Box other_ship_bbox = (*ships)[i]->bbox;
		//other_ship_bbox.Transform(other_ship->getFullWorldMatrix());

		intersection.resetAll();

		//intersection.rayIntersectBox ( &toward_player_ship, &other_ship_bbox );
		intersection.rayIntersectSphere(&toward_player_ship, 
			&R3Sphere(other_ship->getWorldPos(), other_ship->radius));

		if ( !intersection.intersects )
			continue;

		if ( intersection.t > 0.0 && intersection.t < player_intersect_t )	// other ship blocks this AI ship's view of the player
		{
			this->can_see_player = false;
			return;
		}
	}

	// are there any intersections between this AI ship & obstacles?
	for ( i = 0; i < (*obstacles).size (); i++ )
	{
		Obstacle *o = (Obstacle *)( (*obstacles) [ i ]->shape->obstacle );

		//R3Box obstacle_bbox = (*obstacles)[i]->bbox;
		//obstacle_bbox.Transform(o->getFullWorldMatrix());

		intersection.resetAll ();

		//intersection.rayIntersectBox ( &toward_player_ship, &obstacle_bbox );
		intersection.rayIntersectSphere(&toward_player_ship,
			&R3Sphere(o->getWorldPos(), o->radius));

		if ( !intersection.intersects )
			continue;

		if ( intersection.t > 0.0 && intersection.t < player_intersect_t )	// obstacle blocks this AI ship's view of the player
		{
			this->can_see_player = false;
			return;
		}
	}

	// if no other AI ships or obstacles block this AI ship's view of the player, then
	this->can_see_player = true;
}

void Ship::doDamage ( double damage )
{
	// introduce some randomness so damage -> 90% to 110% damage
	damage += ( ( (double)rand () / (double)RAND_MAX ) - 0.5 ) * 0.2 * damage;

	// all damage goes to available shields, then any overflow takes away health
	double damage_to_health = damage - this->shield_strength;

	if ( damage_to_health > 0.0 )
	{
		this->shield_strength = 0.0;
		this->health -= damage_to_health;

		if ( this->health < 0.0 )
			this->health = 0.0;
	}
	else
	{
		this->shield_strength -= damage;
	}
}

void Ship::rechargeShields ( double dt )
{
	this->shield_strength += this->shield_recharge_rate * dt;

	if ( this->shield_strength > FULL_SHIELD_STRENGTH )
		this->shield_strength = FULL_SHIELD_STRENGTH;
}

void Ship::Render () {
	R3Matrix m = getFullMatrix().Transpose();
	glPushMatrix();
	glMultMatrixd((double*)&m);
	//Here's where the drawing can start in the ship's 
	//local coordinate system
	glPushMatrix();
	R3Matrix rot(1, 0, 0, 0,
				 0, 0, -1, 0,
				 0, 1, 0, 0,
				 0, 0, 0, 1);
	rot = rot.Transpose();
	glMultMatrixd((double*)&rot);
	R3Cone cone(R3Point(0, 0, 0), 0.5, 3);
	cone.Draw();
	//end drawing
	glPopMatrix();
	R3Sphere sphere(R3Point(0, 0, 0), 0.5);
	sphere.Draw();
	R3Cylinder cylinder(R3Point(0, 0, 0), 0.2, 2);
	cylinder.Draw();
	glPopMatrix();
}

void Ship::accelForward(double rate) {
	if (rate < max_accel)
		acceleration += rate*towards;
	else
		acceleration += max_accel*towards;
}

//Positive value is counterclockwise
void Ship::ChangeRoll(double rate, double dt) {
	double dTheta = rate * dt;
	if (rate > max_roll_rate)
		dTheta = max_roll_rate * dt;
	else if (rate < -max_roll_rate)
		dTheta = -max_roll_rate * dt;
	right.Rotate(towards, dTheta);
	up.Rotate(towards, dTheta);
}

double Ship::getdTheta(double rate, double dt) {
	double vSquared = velocity.Dot(velocity);
	double dTheta;
	//If the ship is stationary, can change direction
	//as quickly as we want, as long as it's not 
	//faster than the max roll rate
	dTheta = rate * dt;
	if (vSquared == 0) {
		if (rate > max_roll_rate)
			dTheta = max_roll_rate * dt;
		else if (rate < -max_roll_rate)
			dTheta = -max_roll_rate * dt;
	}
	//Otherwise, it's necessary to make sure it doesn't
	//pass the maximum centripetal acceleration threshold
	else {
		double ac = velocity.Length() * abs(rate);
		if (ac > max_centripetal_accel) {
			//printf("maxing out\n");
			dTheta = (max_centripetal_accel / velocity.Length()) * dt;
			if (rate < 0)
				dTheta *= -1;
		}
	}
	return dTheta;
}

//Positive value is "up"
void Ship::ChangePitch(double rate, double dt) {
	double dTheta = getdTheta(rate, dt);
	towards.Rotate(right, dTheta);
	up.Rotate(right, dTheta);
	velocity.Rotate(right, dTheta);
}

//Positive value is "left"
void Ship::ChangeYaw(double rate, double dt) {
	double dTheta = getdTheta(rate, dt);
	towards.Rotate(up, dTheta);
	right.Rotate(up, dTheta);
	velocity.Rotate(up, dTheta);
}

void Ship::ChangeOrientation(R3Vector target, double dt) {
	//Put the target vector in the ship's local coordinate frame
	R3Vector v = getRotationMatrix().Inverse() * target;
	//Pitch in the appropriate direction at the appropriate rate
	//(based on how big the difference is along the "Y" axis)
	ChangePitch(v.Y() * max_centripetal_accel, dt);
	v = getRotationMatrix().Inverse() * target;
	v.SetY(0);
	v.Normalize();
	double theta = acos(v.Dot(R3Vector(0, 0, 1)));
	double rate = theta / PI;
	if (v.X() > 0)
		rate *= -1;
	ChangeYaw(rate * max_centripetal_accel, dt);
}

///////////////////////////////////////////////////////////////
Obstacle::Obstacle() {
	check_mesh = true;//Use this later to do finer collision detection
	asteroid = false;
}

void Obstacle::Render() {
	R3Matrix m(right[0], right[1], right[2], 0,
		up[0], up[1], up[2], 0,
		towards[0], towards[1], towards[2], 0,
		position[0], position[1], position[2], 1);
	glPushMatrix();
		glMultMatrixd((double*)&m);
		if (!asteroid)
			mesh->Draw();
		else {
			R3Sphere sphere(R3Point(0, 0, 0), radius);
			sphere.Draw();
		}
	glPopMatrix();
}

void Obstacle::TimeStep(double dt, vector<R3Node*>* ships, vector<R3Node*>* obstacles) {
	
}

void Obstacle::doDamage ( double damage )
{
	// introduce some randomness so damage -> 90% to 110% damage
	damage += ( ( (double)rand () / (double)RAND_MAX ) - 0.5 ) * 0.2 * damage;

	this->health -= damage;

	if ( this->health < 0.0 )
		this->health = 0.0;
}

///////////////////////////////////////////////////////////////

Weapon::Weapon ()
{
	this->is_discharging = false;
}

Weapon::Weapon ( Ship *mounted_on )
{
	this->origin = mounted_on;
	this->is_discharging = false;
}

void Weapon::Fire ()
{
	this->is_discharging = true;
}

void Weapon::HoldFire ()
{
	this->is_discharging = false;
}

void Weapon::TimeStep ( double dt, vector<R3Node*>* ships, vector<R3Node*>* obstacles )
{
	fprintf ( stderr, "Weapon::TimeStep ( %f )\n", dt );
}

void Weapon::Render ()
{
	fprintf ( stderr, "Weapon::Render ()\n" );
}

Laser::Laser ( Ship *mounted_on )
{
	this->mounted_on = mounted_on;
	this->origin = mounted_on;
	this->cur_strength = this->max_strength = 100.0;
	this->discharge_rate = 100.0;
	this->recharge_rate = 35;
}

bool already_playing = false;
clock_t start_laser;

void Laser::TimeStep ( double dt, vector<R3Node*>* ships, vector<R3Node*>* obstacles )
{
//fprintf ( stderr, "Ship #%d's laser has cur_strength = %f\n", this->origin->id, this->cur_strength );

	this->target_acquired = false;

	if ( this->is_discharging )
	{
		//TODO: 
		double time = (double(clock())-double(start_laser))/CLOCKS_PER_SEC;
		if (!already_playing) {
			sndPlaySound("Sounds/laser.wav", SND_ASYNC);
			already_playing = true;
			start_laser = clock();
		}
		else if (time > 0.25 && this->cur_strength > 0)
			already_playing = false;
		double damage_done = this->discharge_rate * dt;

		if ( this->cur_strength < damage_done )
		{
			damage_done = this->cur_strength;
			this->is_discharging = false;
		}

		this->cur_strength -= damage_done;

		// did the laser hit anything?
		int i;
		bool intersection_found = false;
		double min_t;
		GameObject *target;
		R3Ray laser_beam ( this->origin->getWorldPos (), this->origin->towards );

		// is laser pointing at another ship?
		for ( i = 0; i < (*ships).size (); i++ )
		{
			Ship *other_ship = (Ship *)( (*ships) [ i ]->shape->ship );

			if ( other_ship == this->origin )	// skip the ship to which the laser is mounted
				continue;

			R3Box other_ship_bbox ( other_ship->transformations * ( (*ships) [ i ]->bbox.Min () + other_ship->position ),
									other_ship->transformations * ( (*ships) [ i ]->bbox.Max () + other_ship->position ) );

			R3Intersects intersection;

			intersection.rayIntersectBox ( &laser_beam, &other_ship_bbox );

			if ( intersection.intersects && intersection.t > 0.0 )
			{
				if ( !intersection_found )
				{
					min_t = intersection.t;
					target = other_ship;
					intersection_found = true;
				}
				else
				{
					if ( intersection.t < min_t )
					{
						min_t = intersection.t;
						target = other_ship;
					}
				}
			}
		}

		// is laser pointing at an obstacle?
		for ( i = 0; i < (*obstacles).size (); i++ )
		{
			Obstacle *o = (Obstacle *)( (*obstacles) [ i ]->shape->obstacle );

			R3Box obstacle_bbox ( o->transformations * ( (*obstacles) [ i ]->bbox.Min () + o->position ),
								  o->transformations * ( (*obstacles) [ i ]->bbox.Max () + o->position ) );

			R3Intersects intersection;

			intersection.rayIntersectBox ( &laser_beam, &obstacle_bbox );

			if ( intersection.intersects && intersection.t > 0.0 )
			{
				if ( !intersection_found )
				{
					min_t = intersection.t;
					target = o;
					intersection_found = true;
				}
				else
				{
					if ( intersection.t < min_t )
					{
						min_t = intersection.t;
						target = o;
					}
				}
			}
		}

		// finally, transfer energy discharged by the laser during this timestep to the target as damage
		if ( intersection_found )
		{
			this->target_acquired = true;
			this->target_position = target->getWorldPos ();
			target->doDamage ( damage_done );
		}
	}
	else	// laser is recharging
	{
		this->cur_strength += this->recharge_rate * dt;

		if ( this->cur_strength > this->max_strength )
			this->cur_strength = this->max_strength;
	}
}

void Laser::Render () {
	if (!this->is_discharging || this->cur_strength == 0)
		return;

	double distance = 0.0;
	glPushMatrix();
	glMultMatrixd((double*)&(mounted_on->getFullWorldMatrix().Transpose()));
	if (this->target_acquired) {
		// then laser hits something -> draw from point of origin to the target's position
		distance = (this->origin->getWorldPos() - this->target_position).Length();
	}
	else {
		// then laser doesn't hit anything -> draw from point of origin until out of camera fov
		distance = 100;
	}

		double r = 0.5;
		glBegin(GL_LINES);
		for (double theta = PI / 6; theta < 2*PI; theta += 2*PI / 3) {
			double x = r*cos(theta);
			double y = r*sin(theta);
			glVertex3f(x, y, 0);
			glVertex3f(0, 0, distance / 5);
		}
		glVertex3f(0, 0, distance / 5);
		glVertex3f(0, 0, distance);
		glEnd();
		/*glPushMatrix();
		R3Matrix rot(1, 0, 0, 0,
					 0, 0, -1, 0,
					 0, 1, 0, 0,
					 0, 0, 0, 1);
		rot = rot.Transpose();
		glMultMatrixd((double*)&rot);
		R3Cylinder toDraw(R3Point(0, 0.1 + 3 * distance / 5, 0), 0.1, 4 *distance / 5 - 0.1);
		toDraw.Draw();
		glPopMatrix();
		R3Sphere sphere(R3Point(0, 0, distance), 0.3);
		if (this->target_acquired) {
			glDisable(GL_LIGHTING);
			glColor3f(1, 0, 0);
			sphere.Draw();
			glEnable(GL_LIGHTING);
			glColor3f(1, 1, 1);
		}*/
	glPopMatrix();
}