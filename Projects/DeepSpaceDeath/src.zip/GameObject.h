#ifndef GAME_OBJECT_H
#define GAME_OBJECT_H

#include "Explosion.h"

#define PI 3.1415925
#define FULL_HEALTH 100.0
#define FULL_SHIELD_STRENGTH 100.0
#define DEFAULT_SHIELD_RECHARGE_RATE 1.0
#define MAX_VELOCITY 10

typedef enum
{
	POSTURE_DEFENSIVE,
	POSTURE_OFFENSIVE,
	POSTURE_KAMIKAZE
} AIPosture;

class GameObject
{
	public:
		int id;
		R3Node* node;
		R3Vector towards, right, up;
		R3Point position;
		R3Vector velocity, acceleration;
		R3Matrix transformations;//Product of all transformation
		//matrices to get to this node
		double mass;
		double health;	// 0-100 pts
		bool check_mesh;//If bounding box check is insufficient
		double radius;//Radius of a bounding sphere
		void* explosion;
		GameObject();
		~GameObject();
		void resetAll();
		virtual void TimeStep ( double dt, vector<R3Node*>* ships, vector<R3Node*>* obstacles );
		virtual void Render();
		virtual void move(double dt);
		virtual void doDamage ( double damage );
		R3Point getWorldPos();//Return the ship's position
		//centered at the world origin
		R3Matrix getRotationMatrix();
		R3Matrix getFullTranslationMatrix();
		R3Matrix getFullMatrix();
		R3Matrix getFullWorldMatrix();
};

// define a Ship subclass that derives from GameObject
class Ship : public GameObject
{
	public:
		bool is_ai;
		bool can_see_player;
		int number;
		AIPosture posture;
		//Maneuverability parameters
		double max_accel;//units / sec^2
		double max_centripetal_accel;//units / sec^2
		double max_roll_rate;//units radians / sec
		double shield_strength;	// 0-100 pts
		double shield_recharge_rate;	// x pts per dt
		void *laser_cannon;
		Ship();
		~Ship ();
		virtual void Think(double dt, vector<R3Node*>* ships, 
			vector<R3Node*>* obstacles, Ship* playerShip);
		void KamikazeThink ( double dt, vector<R3Node*>* ships, vector<R3Node*>* obstacles, Ship* playerShip );
		void DefensiveThink ( double dt, vector<R3Node*>* ships, vector<R3Node*>* obstacles, Ship* playerShip );
		void OffensiveThink ( double dt, vector<R3Node*>* ships, vector<R3Node*>* obstacles, Ship* playerShip );
		void determineIfCanSeePlayer ( vector<R3Node*>* ships, vector<R3Node*>* obstacles, Ship* playerShip );
		virtual void TimeStep ( double dt, vector<R3Node*>* ships, vector<R3Node*>* obstacles );
		virtual void Render();
		virtual void move(double dt);
		virtual void doDamage ( double damage );
		void rechargeShields ( double dt );
		void accelForward(double rate);
		/*rate is the rate of change of angle in 
		*radians per second in the given direction*/
		void ChangeRoll(double rate, double dt);
		void ChangePitch(double rate, double dt);
		void ChangeYaw(double rate, double dt);
		//Helper function for ChangePitch and ChangeYaw
		double getdTheta(double rate, double dt);

		//Change the orientation of the ship to be facing towards
		//the direction "change" (the "up" and "right" vectors
		//do not matter)
		//NOTE: This function expects target to be normalized
		void ChangeOrientation(R3Vector target, double dt);
};

class Obstacle : public GameObject {
	public:
		Obstacle();
		double angular_velocity;
		bool asteroid;
		R3Mesh* mesh;//A pointer to the mesh to draw for this obstacle
		virtual void TimeStep(double dt, vector<R3Node*>* ships, vector<R3Node*>* obstacles);//This is analogous to Ship's Think() method
		virtual void Render();
		virtual void doDamage ( double damage );
};

class Weapon
{
	public:
		bool is_discharging;
		double max_strength;
		double cur_strength;
		double discharge_rate;
		double recharge_rate;
		Ship *origin;
		Weapon ();
		Weapon ( Ship *mounted_on );
		virtual void Fire ();
		virtual void HoldFire ();
		virtual void TimeStep ( double dt, vector<R3Node*>* ships, vector<R3Node*>* obstacles );
		virtual void Render ();
};

class Laser : public Weapon
{
	public:
		bool target_acquired;
		Ship* mounted_on;
		R3Point target_position;
		Laser ( Ship *mounted_on );
		virtual void TimeStep ( double dt, vector<R3Node*>* ships, vector<R3Node*>* obstacles );
		virtual void Render ();
};


#endif