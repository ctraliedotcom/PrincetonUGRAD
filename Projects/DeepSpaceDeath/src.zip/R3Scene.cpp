// Source file for the R3 scene graph class 



// Include files 

#include "R3/R3.h"
#include "R3Scene.h"
#include "GameObject.h"


R3Scene::
R3Scene(void)
  : bbox(R3null_box),
    background(0,0,0,1),
    ambient(0,0,0,1)
{
  // Setup default camera
  camera.eye = R3zero_point;
  camera.towards = R3negz_vector;
  camera.up = R3posy_vector;
  camera.right = R3posx_vector;
  camera.xfov = 0.0;
  camera.yfov = 0.0;
  camera.neardist = 0.01;
  camera.fardist = 100.0;

  // Create root node
  root = new R3Node();
  root->parent = NULL;
  root->transformation = R3identity_matrix;
  root->material = NULL;
  root->shape = NULL;
  root->bbox = R3null_box;
}

//Clean up memory that's been allocated
R3Scene::~R3Scene(void) {
	//Clean up ships
	for (int i = 0; i < ships.size(); i++) {
		Ship* ship = (Ship*)ships[i]->shape->ship;
		delete ship;
	}
	for (int i = 0; i < obstacles.size(); i++) {
		Obstacle* obstacle = (Obstacle*)obstacles[i]->shape->obstacle;
		delete obstacle;
	}
	map<const char*, R3Mesh*, eqstr>::iterator iter = meshes.begin();
	while (iter != meshes.end()) {
		R3Mesh* mesh = (R3Mesh*)(*iter).second;
		delete mesh;
		iter++;
	}
}


//This doesn't work for some reason
/*void R3Scene::loadMeshes() {
	DIR* meshDir = NULL;
	meshDir = opendir("Meshes");
	if (meshDir == NULL) {
		fprintf(stderr, "ERROR: Failed to list directory of meshes\n");
		return;
	}
	struct dirent* pent = NULL;
	while (pent = readdir(meshDir)) {
		if (pent == NULL) {
			fprintf(stderr, "ERROR: Problem reading mesh directory entity\n");
			return;
		}
		char* filename = pent->dname;
		R3Mesh* mesh = new R3Mesh();
		mesh->Read(filename);
		meshes[filename] = mesh;
	}
	closedir(meshDir);
}*/

int R3Scene::
Read(const char *filename, R3Node *node)
{
  // Open file
  FILE *fp;
  if (!(fp = fopen(filename, "r"))) {
    fprintf(stderr, "Unable to open file %s", filename);
    return 0;
  }

  int id = 0;
  int ship_id = 1;

  // Create array of materials
  vector<R3Material *> materials;

  // Create default material
  R3Material *default_material = new R3Material();
  default_material->ka = R3Rgb(0.2, 0.2, 0.2, 1);
  default_material->kd = R3Rgb(0.5, 0.5, 0.5, 1);
  default_material->ks = R3Rgb(0.5, 0.5, 0.5, 1);
  default_material->kt = R3Rgb(0.0, 0.0, 0.0, 1);
  default_material->emission = R3Rgb(0, 0, 0, 1);
  default_material->shininess = 10;
  default_material->indexofrefraction = 1;
  default_material->texture = NULL;
  default_material->id = 0;

  // Create stack of group information
  const int max_depth = 1024;
  R3Node *group_nodes[max_depth] = { NULL };
  R3Material *group_materials[max_depth] = { NULL };
  group_nodes[0] = (node) ? node : root;
  group_materials[0] = default_material;
  int depth = 0;

  // Read body
  char cmd[128];
  int command_number = 1;
  while (fscanf(fp, "%s", cmd) == 1) {
    if (cmd[0] == '#') {
      // Comment -- read everything until end of line
      do { cmd[0] = fgetc(fp); } while ((cmd[0] >= 0) && (cmd[0] != '\n'));
    }
    else if (!strcmp(cmd, "tri")) {
      // Read data
      int m;
      R3Point p1, p2, p3;
      if (fscanf(fp, "%d%lf%lf%lf%lf%lf%lf%lf%lf%lf", &m, 
        &p1[0], &p1[1], &p1[2], &p2[0], &p2[1], &p2[2], &p3[0], &p3[1], &p3[2]) != 10) {
        fprintf(stderr, "Unable to read triangle at command %d in file %s\n", command_number, filename);
        return 0;
      }

      // Get material
      R3Material *material = group_materials[depth];
      if (m >= 0) {
        if (m < (int) materials.size()) {
          material = materials[m];
        }
        else {
          fprintf(stderr, "Invalid material id at tri command %d in file %s\n", command_number, filename);
          return 0;
        }
      }

      // Create mesh
      R3Mesh *mesh = new R3Mesh();
      R3MeshVertex *v1 = mesh->CreateVertex(p1, R3zero_vector, R2zero_point);
      R3MeshVertex *v2 = mesh->CreateVertex(p2, R3zero_vector, R2zero_point);
      R3MeshVertex *v3 = mesh->CreateVertex(p3, R3zero_vector, R2zero_point);
      mesh->CreateFace(v1, v2, v3);

      // Create shape
      R3Shape *shape = new R3Shape();
      shape->type = R3_MESH_SHAPE;
      shape->box = NULL;
      shape->sphere = NULL;
      shape->cylinder = NULL;
      shape->cone = NULL;
      shape->mesh = mesh;

      // Create shape node
      R3Node *node = new R3Node();
      node->transformation = R3identity_matrix;
      node->material = material;
      node->shape = shape;
      node->bbox = R3null_box;
      node->bbox.Union(v1->position);
      node->bbox.Union(v2->position);
      node->bbox.Union(v3->position);

      // Insert node
      group_nodes[depth]->bbox.Union(node->bbox);
      group_nodes[depth]->children.push_back(node);
      node->parent = group_nodes[depth];
    }
    else if (!strcmp(cmd, "box")) {
      // Read data
      int m;
      R3Point p1, p2;
      if (fscanf(fp, "%d%lf%lf%lf%lf%lf%lf", &m, &p1[0], &p1[1], &p1[2], &p2[0], &p2[1], &p2[2]) != 7) {
        fprintf(stderr, "Unable to read box at command %d in file %s\n", command_number, filename);
        return 0;
      }

      // Get material
      R3Material *material = group_materials[depth];
      if (m >= 0) {
        if (m < (int) materials.size()) {
          material = materials[m];
        }
        else {
          fprintf(stderr, "Invalid material id at box command %d in file %s\n", command_number, filename);
          return 0;
        }
      }

      // Create box
      R3Box *box = new R3Box(p1, p2);

      // Create shape
      R3Shape *shape = new R3Shape();
      shape->type = R3_BOX_SHAPE;
      shape->box = box;
      shape->sphere = NULL;
      shape->cylinder = NULL;
      shape->cone = NULL;
      shape->mesh = NULL;

      // Create shape node
      R3Node *node = new R3Node();
      node->transformation = R3identity_matrix;
      node->material = material;
      node->shape = shape;
      node->bbox = *box;

      // Insert node
      group_nodes[depth]->bbox.Union(node->bbox);
      group_nodes[depth]->children.push_back(node);
      node->parent = group_nodes[depth];
    }
    else if (!strcmp(cmd, "sphere")) {
      // Read data
      int m;
      R3Point c;
      double r;
      if (fscanf(fp, "%d%lf%lf%lf%lf", &m, &c[0], &c[1], &c[2], &r) != 5) {
        fprintf(stderr, "Unable to read sphere at command %d in file %s\n", command_number, filename);
        return 0;
      }

      // Get material
      R3Material *material = group_materials[depth];
      if (m >= 0) {
        if (m < (int) materials.size()) {
          material = materials[m];
        }
        else {
          fprintf(stderr, "Invalid material id at sphere command %d in file %s\n", command_number, filename);
          return 0;
        }
      }

      // Create sphere
      R3Sphere *sphere = new R3Sphere(c, r);

      // Create shape
      R3Shape *shape = new R3Shape();
      shape->type = R3_SPHERE_SHAPE;
      shape->box = NULL;
      shape->sphere = sphere;
      shape->cylinder = NULL;
      shape->cone = NULL;
      shape->mesh = NULL;

      // Create shape node
      R3Node *node = new R3Node();
      node->transformation = R3identity_matrix;
      node->material = material;
      node->shape = shape;
      node->bbox = sphere->BBox();

      // Insert node
      group_nodes[depth]->bbox.Union(node->bbox);
      group_nodes[depth]->children.push_back(node);
      node->parent = group_nodes[depth];
    }
    else if (!strcmp(cmd, "cylinder")) {
      // Read data
      int m;
      R3Point c;
      double r, h;
      if (fscanf(fp, "%d%lf%lf%lf%lf%lf", &m, &c[0], &c[1], &c[2], &r, &h) != 6) {
        fprintf(stderr, "Unable to read cylinder at command %d in file %s\n", command_number, filename);
        return 0;
      }

      // Get material
      R3Material *material = group_materials[depth];
      if (m >= 0) {
        if (m < (int) materials.size()) {
          material = materials[m];
        }
        else {
          fprintf(stderr, "Invalid material id at cyl command %d in file %s\n", command_number, filename);
          return 0;
        }
      }

      // Create cylinder
      R3Cylinder *cylinder = new R3Cylinder(c, r, h);

      // Create shape
      R3Shape *shape = new R3Shape();
      shape->type = R3_CYLINDER_SHAPE;
      shape->box = NULL;
      shape->sphere = NULL;
      shape->cylinder = cylinder;
      shape->cone = NULL;
      shape->mesh = NULL;

      // Create shape node
      R3Node *node = new R3Node();
      node->transformation = R3identity_matrix;
      node->material = material;
      node->shape = shape;
      node->bbox = cylinder->BBox();

      // Insert node
      group_nodes[depth]->bbox.Union(node->bbox);
      group_nodes[depth]->children.push_back(node);
      node->parent = group_nodes[depth];
    }
    else if (!strcmp(cmd, "mesh")) {
      // Read data
      int m;
      char meshname[256];
      if (fscanf(fp, "%d%s", &m, meshname) != 2) {
        fprintf(stderr, "Unable to parse mesh command %d in file %s\n", command_number, filename);
        return 0;
      }

      // Get material
      R3Material *material = group_materials[depth];
      if (m >= 0) {
        if (m < (int) materials.size()) {
          material = materials[m];
        }
        else {
          fprintf(stderr, "Invalid material id at cone command %d in file %s\n", command_number, filename);
          return 0;
        }
      }

      // Create mesh
      R3Mesh *mesh = new R3Mesh();
      if (!mesh) {
        fprintf(stderr, "Unable to allocate mesh\n");
        return 0;
      }

      // Read mesh file
      if (!mesh->Read(meshname)) {
        fprintf(stderr, "Unable to read mesh: %s\n", meshname);
        return 0;
      }

      // Create shape
      R3Shape *shape = new R3Shape();
      shape->type = R3_MESH_SHAPE;
      shape->box = NULL;
      shape->sphere = NULL;
      shape->cylinder = NULL;
      shape->cone = NULL;
      shape->mesh = mesh;

      // Create shape node
      R3Node *node = new R3Node();
      node->transformation = R3identity_matrix;
      node->material = material;
      node->shape = shape;
      node->bbox = mesh->bbox;

      // Insert node
      group_nodes[depth]->bbox.Union(node->bbox);
      group_nodes[depth]->children.push_back(node);
      node->parent = group_nodes[depth];
    }
    else if (!strcmp(cmd, "cone")) {
      // Read data
      int m;
      R3Point c;
      double r, h;
      if (fscanf(fp, "%d%lf%lf%lf%lf%lf", &m, &c[0], &c[1], &c[2], &r, &h) != 6) {
        fprintf(stderr, "Unable to read cone at command %d in file %s\n", command_number, filename);
        return 0;
      }

      // Get material
      R3Material *material = group_materials[depth];
      if (m >= 0) {
        if (m < (int) materials.size()) {
          material = materials[m];
        }
        else {
          fprintf(stderr, "Invalid material id at cone command %d in file %s\n", command_number, filename);
          return 0;
        }
      }

      // Create cone
      R3Cone *cone = new R3Cone(c, r, h);

      // Create shape
      R3Shape *shape = new R3Shape();
      shape->type = R3_CONE_SHAPE;
      shape->box = NULL;
      shape->sphere = NULL;
      shape->cylinder = NULL;
      shape->cone = cone;
      shape->mesh = NULL;

      // Create shape node
      R3Node *node = new R3Node();
      node->transformation = R3identity_matrix;
      node->material = material;
      node->shape = shape;
      node->bbox = cone->BBox();

      // Insert node
      group_nodes[depth]->bbox.Union(node->bbox);
      group_nodes[depth]->children.push_back(node);
      node->parent = group_nodes[depth];
    }
	else if (!strcmp(cmd, "ship")) {
      // Read data
      int m;
	  R3Vector towards, right, up;
      double r, h;
      if (fscanf(fp, "%d%lf%lf%lf%lf%lf%lf%lf%lf%lf", &m, 
		  &right[0], &right[1], &right[2],
		  &up[0], &up[1], &up[2],
		  &towards[0], &towards[1], &towards[2]) != 10) {
        fprintf(stderr, "Unable to read ship at command %d in file %s\n", command_number, filename);
        return 0;
      }

      // Get material
      R3Material *material = group_materials[depth];
      if (m >= 0) {
        if (m < (int) materials.size()) {
          material = materials[m];
        }
        else {
          fprintf(stderr, "Invalid material id at ship command %d in file %s\n", command_number, filename);
          return 0;
        }
      }

      // Create ship object
      Ship* ship = new Ship();
	  ship->id = id++;
	  ship->towards = towards;
	  ship->right = right;
	  ship->up = up;

      // Create shape
      R3Shape *shape = new R3Shape();
      shape->type = R3_SHIP;
      shape->box = NULL;
      shape->sphere = NULL;
      shape->cylinder = NULL;
      shape->cone = NULL;
      shape->mesh = NULL;
	  shape->ship = ship;
	  shape->obstacle = NULL;
	  ship->number = ship_id;
	  ship_id++;

      // Create shape node
      R3Node *node = new R3Node();
      node->transformation = R3identity_matrix;
      node->material = material;
      node->shape = shape;
      //node->bbox = cone->BBox();
	  node->bbox = R3unit_box;
	  node->bbox.Transform(R3Matrix(0.5, 0, 0, 0, 0, 0.5, 0, 0, 0, 0, 0.5, 0, 0, 0, 0, 1));
      //TODO: Add proper bounding box for ship

      // Insert node
      group_nodes[depth]->bbox.Union(node->bbox);
      group_nodes[depth]->children.push_back(node);
      node->parent = group_nodes[depth];
	  ship->node = node;
	  ships.push_back(node);
	}

	else if (!strcmp(cmd, "obstacle")) {
      // Read data
      int m;
	  R3Vector towards, right, up;
      double mass, vx, vy, vz;
	  char meshname[256];
      if (fscanf(fp, "%d%lf%lf%lf%lf%s", 
		  &m, &mass, &vx, &vy, &vz, meshname) != 6) {
        fprintf(stderr, "Unable to read object at command %d in file %s\n", command_number, filename);
        return 0;
      }

      // Get material
      R3Material *material = group_materials[depth];
      if (m >= 0) {
        if (m < (int) materials.size()) {
          material = materials[m];
        }
        else {
          fprintf(stderr, "Invalid material id at obstacle command %d in file %s\n", command_number, filename);
          return 0;
        }
      }
      // Create obstacle object
      Obstacle* obstacle = new Obstacle();
	  obstacle->id = id++;
	  obstacle->mass = mass;
	  obstacle->velocity = R3Vector(vx, vy, vz);
	  R3Mesh* mesh;
	  if (meshes.find(meshname) == meshes.end()) {//If the mesh for this
		  //obstacle has not been loaded yet
		  mesh = new R3Mesh();
		  mesh->Read(meshname);
		  meshes[meshname] = mesh;
	  }
	  else {
		  mesh = (*meshes.find(meshname)).second;
	  }
	  obstacle->mesh = mesh;
      // Create shape
      R3Shape *shape = new R3Shape();
      shape->type = R3_OBSTACLE;
      shape->box = NULL;
      shape->sphere = NULL;
      shape->cylinder = NULL;
      shape->cone = NULL;
      shape->mesh = NULL;
	  shape->ship = NULL;
	  shape->obstacle = obstacle;

      // Create shape node
      R3Node *node = new R3Node();
      node->transformation = R3identity_matrix;
      node->material = material;
      node->shape = shape;
	  node->bbox = obstacle->mesh->bbox;

      // Insert node
      group_nodes[depth]->bbox.Union(node->bbox);
      group_nodes[depth]->children.push_back(node);
      node->parent = group_nodes[depth];
	  obstacle->node = node;
	  obstacles.push_back(node);
	}

    else if (!strcmp(cmd, "begin")) {
      // Read data
      int m;
      double matrix[16];
      if (fscanf(fp, "%d%lf%lf%lf%lf%lf%lf%lf%lf%lf%lf%lf%lf%lf%lf%lf%lf", &m, 
        &matrix[0], &matrix[1], &matrix[2], &matrix[3], 
        &matrix[4], &matrix[5], &matrix[6], &matrix[7], 
        &matrix[8], &matrix[9], &matrix[10], &matrix[11], 
        &matrix[12], &matrix[13], &matrix[14], &matrix[15]) != 17) {
        fprintf(stderr, "Unable to read group at command %d in file %s\n", command_number, filename);
        return 0;
      }

      // Get material
      R3Material *material = group_materials[depth];
      if (m >= 0) {
        if (m < (int) materials.size()) {
          material = materials[m];
        }
        else {
          fprintf(stderr, "Invalid material id at cone command %d in file %s\n", command_number, filename);
          return 0;
        }
      }

      // Create new group node
      R3Node *node = new R3Node();
      node->transformation = R3Matrix(matrix);
      node->material = NULL;
      node->shape = NULL;
      node->bbox = R3null_box;

      // Push node onto stack
      depth++;
      group_nodes[depth] = node;
      group_materials[depth] = material;
    }
    else if (!strcmp(cmd, "end")) {
      // Pop node from stack
      R3Node *node = group_nodes[depth];
      depth--;

      // Transform bounding box
      node->bbox.Transform(node->transformation);

      // Insert node
      group_nodes[depth]->bbox.Union(node->bbox);
      group_nodes[depth]->children.push_back(node);
      node->parent = group_nodes[depth];
    }
    else if (!strcmp(cmd, "material")) {
      // Read data
      R3Rgb ka, kd, ks, kt, e;
      double n, ir;
      char texture_name[256];
      if (fscanf(fp, "%lf%lf%lf%lf%lf%lf%lf%lf%lf%lf%lf%lf%lf%lf%lf%lf%lf%s", 
          &ka[0], &ka[1], &ka[2], &kd[0], &kd[1], &kd[2], &ks[0], &ks[1], &ks[2], &kt[0], &kt[1], &kt[2], 
          &e[0], &e[1], &e[2], &n, &ir, texture_name) != 18) {
        fprintf(stderr, "Unable to read material at command %d in file %s\n", command_number, filename);
        return 0;
      }

      // Create material
      R3Material *material = new R3Material();
      material->ka = ka;
      material->kd = kd;
      material->ks = ks;
      material->kt = kt;
      material->emission = e;
      material->shininess = n;
      material->indexofrefraction = ir;
      material->texture = NULL;
	  material->texture_index = 0;//I added this because for some reason, the 
	  //it would not always initialize to zero, which is important later in SpaceSim.cpp

      // Read texture
      if (strcmp(texture_name, "0")) {
        material->texture = new R2Image();
        if (!material->texture->Read(texture_name)) {
          fprintf(stderr, "Unable to read texture from %s at command %d in file %s\n", texture_name, command_number, filename);
          return 0;
        }
      }
      // Insert material
      materials.push_back(material);
    }
    else if (!strcmp(cmd, "dir_light")) {
      // Read data
      R3Rgb c;
      R3Vector d;
      if (fscanf(fp, "%lf%lf%lf%lf%lf%lf", 
        &c[0], &c[1], &c[2], &d[0], &d[1], &d[2]) != 6) {
        fprintf(stderr, "Unable to read directional light at command %d in file %s\n", command_number, filename);
        return 0;
      }

      // Normalize direction
      d.Normalize();

      // Create light
      R3Light *light = new R3Light();
      light->type = R3_DIRECTIONAL_LIGHT;
      light->color = c;
      light->position = R3Point(0, 0, 0);
      light->direction = d;
      light->constant_attenuation = 0;
      light->linear_attenuation = 0;
      light->quadratic_attenuation = 0;
      light->angle_attenuation = 0;
      light->angle_cutoff = M_PI;

      // Insert light
      lights.push_back(light);
    }
    else if (!strcmp(cmd, "point_light")) {
      // Read data
      R3Rgb c;
      R3Point p;
      double ca, la, qa;
      if (fscanf(fp, "%lf%lf%lf%lf%lf%lf%lf%lf%lf", &c[0], &c[1], &c[2], &p[0], &p[1], &p[2], &ca, &la, &qa) != 9) {
        fprintf(stderr, "Unable to read point light at command %d in file %s\n", command_number, filename);
        return 0;
      }

      // Create light
      R3Light *light = new R3Light();
      light->type = R3_POINT_LIGHT;
      light->color = c;
      light->position = p;
      light->direction = R3Vector(0, 0, 0);
      light->constant_attenuation = ca;
      light->linear_attenuation = la;
      light->quadratic_attenuation = qa;
      light->angle_attenuation = 0;
      light->angle_cutoff = M_PI;

      // Insert light
      lights.push_back(light);
    }
    else if (!strcmp(cmd, "spot_light")) {
      // Read data
      R3Rgb c;
      R3Point p;
      R3Vector d;
      double ca, la, qa, sc, sd;
      if (fscanf(fp, "%lf%lf%lf%lf%lf%lf%lf%lf%lf%lf%lf%lf%lf%lf", 
        &c[0], &c[1], &c[2], &p[0], &p[1], &p[2], &d[0], &d[1], &d[2], &ca, &la, &qa, &sc, &sd) != 14) {
        fprintf(stderr, "Unable to read point light at command %d in file %s\n", command_number, filename);
        return 0;
      }

      // Normalize direction
      d.Normalize();

      // Create light
      R3Light *light = new R3Light();
      light->type = R3_SPOT_LIGHT;
      light->color = c;
      light->position = p;
      light->direction = d;
      light->constant_attenuation = ca;
      light->linear_attenuation = la;
      light->quadratic_attenuation = qa;
      light->angle_attenuation = sd;
      light->angle_cutoff = sc;

      // Insert light
      lights.push_back(light);
    }
    else if (!strcmp(cmd, "camera")) {
      // Read data
      double px, py, pz, dx, dy, dz, ux, uy, uz, xfov, neardist, fardist;
      if (fscanf(fp, "%lf%lf%lf%lf%lf%lf%lf%lf%lf%lf%lf%lf", &px, &py, &pz, &dx, &dy, &dz, &ux, &uy, &uz, &xfov, &neardist, &fardist) != 12) {
        fprintf(stderr, "Unable to read camera at command %d in file %s\n", command_number, filename);
        return 0;
      }

      // Assign camera
      camera.eye = R3Point(px, py, pz);
      camera.towards = R3Vector(dx, dy, dz);
      camera.towards.Normalize();
      camera.up = R3Vector(ux, uy, uz);
      camera.up.Normalize();
      camera.right = camera.towards % camera.up;
      camera.right.Normalize();
      camera.up = camera.right % camera.towards;
      camera.up.Normalize();
      camera.xfov = xfov;
      camera.yfov = xfov;
      camera.neardist = neardist;
      camera.fardist = fardist;
    }
    else if (!strcmp(cmd, "include")) {
      // Read data
      char scenename[256];
      if (fscanf(fp, "%s", scenename) != 1) {
        fprintf(stderr, "Unable to read include command %d in file %s\n", command_number, filename);
        return 0;
      }

      // Read scene from included file
      if (!Read(scenename, group_nodes[depth])) {
        fprintf(stderr, "Unable to read included scene: %s\n", scenename);
        return 0;
      }
    }
    else if (!strcmp(cmd, "background")) {
      // Read data
      double r, g, b;
      if (fscanf(fp, "%lf%lf%lf", &r, &g, &b) != 3) {
        fprintf(stderr, "Unable to read background at command %d in file %s\n", command_number, filename);
        return 0;
      }

      // Assign background color
      background = R3Rgb(r, g, b, 1);
    }
    else if (!strcmp(cmd, "ambient")) {
      // Read data
      double r, g, b;
      if (fscanf(fp, "%lf%lf%lf", &r, &g, &b) != 3) {
        fprintf(stderr, "Unable to read ambient at command %d in file %s\n", command_number, filename);
        return 0;
      }

      // Assign ambient color
      ambient = R3Rgb(r, g, b, 1);
    }
    else {
      fprintf(stderr, "Unrecognized command %d in file %s: %s\n", command_number, filename, cmd);
      return 0;
    }
	
    // Increment command number
    command_number++;
  }

  // Update bounding box
  bbox = root->bbox;

  // Close file
  fclose(fp);

  // Return success
  return 1;
}


// Read in the image file given by filename, then uniformly sample the image,
// placing an asteroid (sphere) in the scene at every position where the pixel
// luminance of the sample is greater than a threshold
void R3Scene::ProcGen ( char *filename )
{
	if ( filename == NULL )
		return;

fprintf ( stderr, "procedurally generating asteroid field from file: %s\n", filename );

	R2Image source;

	if ( !source.Read ( filename ) )
	{
		fprintf ( stderr, "R3Scene::ProcGen (): Warning! Unable to read the image from which to generate the asteroid field!\n" );
		return;
	}

	int num_asteroids_created = 0;
	double luminance_threshold = 0.5;
	double start_x = -1.0 * (double)source.Width () / 2.0;
	double start_y = -1.0 * (double)source.Height () / 2.0;
	int step_size = 8;

	// sample every eighth pixel (assuming a 64x64 pixel image)
	for ( int i = 0; i < source.Width (); i += step_size )
	{
		for ( int j = 0; j < source.Height (); j += step_size )
		{
			double luminance = source.Pixel ( i, j ).Luminance ();
			if ( luminance < luminance_threshold )
				continue;

			double radius = (luminance - luminance_threshold) / luminance_threshold;
			radius *= (double)step_size / 3.0;
			radius += 0.5;

//fprintf ( stderr, "Pixel ( %d, %d ) is higher than the required threshold.\n", i, source.Height () - 1 - j );
			// Create obstacle object
			Obstacle* obstacle = new Obstacle();
			obstacle->id = 100 + num_asteroids_created;
			obstacle->mass = radius*radius*radius;
			obstacle->velocity = R3Vector ( 0.0, 0.0, 0.0 );
			
			/*R3Mesh* mesh = new R3Mesh();
			mesh->Read( "Meshes/sphere.off" );

			obstacle->mesh = mesh;*/

			obstacle->asteroid = true;
			obstacle->radius = radius;

			// Create shape
			R3Shape *shape = new R3Shape();
			shape->type = R3_OBSTACLE;
			shape->box = NULL;
			shape->sphere = NULL;
			shape->cylinder = NULL;
			shape->cone = NULL;
			shape->mesh = NULL;
			shape->ship = NULL;
			shape->obstacle = obstacle;

			// Create shape node
			R3Node *node = new R3Node();
			obstacle->node = node;

			// transform the asteroid to a location corresponding to the pixel's location in the image
			double matrix [ 16 ];
			matrix [ 0 ] = 1.0;	matrix [ 1 ] = 0.0;	matrix [ 2 ] = 0.0;	matrix [ 3 ] = start_x + (double) i;
			matrix [ 4 ] = 0.0;	matrix [ 5 ] = 1.0;	matrix [ 6 ] = 0.0;	matrix [ 7 ] = start_y + (double) ( source.Height () - 1 - j );
			matrix [ 8 ] = 0.0;	matrix [ 9 ] = 0.0;	matrix [ 10 ] =1.0;	matrix [ 11 ] =(double)rand () / (double)RAND_MAX;
			matrix [ 12 ] =0.0;	matrix [ 13 ] =0.0;	matrix [ 14 ] =0.0;	matrix [ 15 ] =1.0;

			node->transformation = R3Matrix ( matrix );
 
			// Create default material
			R3Material *default_material = new R3Material();
			default_material->ka = R3Rgb(0.2, 0.2, 0.2, 1);
			default_material->kd = R3Rgb(0.52, 0.35, 0.09, 1);
			default_material->ks = R3Rgb(0.1, 0.1, 0.1, 1);
			default_material->kt = R3Rgb(0.0, 0.0, 0.0, 1);
			default_material->emission = R3Rgb(0, 0, 0, 1);
			default_material->shininess = 11;
			default_material->indexofrefraction = 1;
			default_material->texture = NULL;
			default_material->id = 100 + num_asteroids_created;

			node->material = default_material;
			node->shape = shape;
			//node->bbox = obstacle->mesh->bbox;
			node->bbox = R3unit_box;
			node->bbox.Transform(R3Matrix(radius, 0, 0, 0,
										  0,	radius, 0, 0,
										  0, 0,		radius, 0,
										  0, 0, 0, 1));
			node->parent = this->root;

			// Insert node
			this->root->children.push_back ( node );
			this->obstacles.push_back ( node );

			num_asteroids_created++;
		}
	}
}


R3Material* copyMaterial(R3Material* source) {
	R3Material* toReturn = new R3Material();
	toReturn->ka = source->ka;
	toReturn->kd = source->kd;
	toReturn->ks = source->ks;
	toReturn->kt = source->kt;
	toReturn->emission = source->emission;
	toReturn->shininess = source->shininess;
	toReturn->indexofrefraction = source->indexofrefraction;
	toReturn->texture = source->texture;
	toReturn->texture_index = source->texture_index;
	toReturn->id = source->id;
	return toReturn;
}

//A recursive function that stores the product of matrices that represent
//all the transforms to get to a particular node.  Store these matrices
//in ship and obstacle nodes when they are found in the tree
void accumTransforms(R3Node* node, R3Matrix transform) {
	if (node == NULL)
		return;
	for (int i = 0; i < node->children.size(); i++) {
		accumTransforms(node->children[i], transform * node->transformation);
	}
	if (node->shape != NULL) {
		if (node->shape->type == R3_SHIP) {
			Ship* ship = (Ship*)node->shape->ship;
			ship->transformations = transform * node->transformation;
			//Make a unique copy of the material object for this node
			node->material = copyMaterial(node->material);
			ship->radius = node->bbox.DiagonalRadius();
		}
		else if (node->shape->type == R3_OBSTACLE) {
			Obstacle* obstacle = (Obstacle*)node->shape->obstacle;
			obstacle->transformations = transform * node->transformation;
			if (obstacle->asteroid == false) {
				node->material = copyMaterial(node->material);
				obstacle->radius = node->bbox.DiagonalRadius();
			}
		}
	}
}

GLuint loadTexture(char* filename) {
	GLuint texture_index = -1;
	glGenTextures(1, &texture_index);
	glBindTexture(GL_TEXTURE_2D, texture_index); 
	R2Image image(filename);
	int npixels = image.NPixels();
	R2Pixel *pixels = image.Pixels();
	GLfloat *buffer = new GLfloat [4 * npixels];
	R2Pixel *pixelsp = pixels;
	GLfloat *bufferp = buffer;
	for (int j = 0; j < npixels; j++) { 
		*(bufferp++) = pixelsp->Red();
		*(bufferp++) = pixelsp->Green();
		*(bufferp++) = pixelsp->Blue();
		*(bufferp++) = pixelsp->Alpha();
		pixelsp++;
	}
	glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_MIN_FILTER,GL_LINEAR);
	glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_MAG_FILTER,GL_LINEAR);
	glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_WRAP_S,GL_REPEAT);
	glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_WRAP_T,GL_REPEAT);
	glTexEnvi(GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE, GL_MODULATE);
	glTexImage2D(GL_TEXTURE_2D, 0, 4, image.Width(), image.Height(), 0, GL_RGBA, GL_FLOAT, buffer);
	delete [] buffer;
	return texture_index;
}


GLuint loadTexture(char* filename, char* alphaFile) {
	GLuint texture_index = -1;
	glGenTextures(1, &texture_index);
	glBindTexture(GL_TEXTURE_2D, texture_index); 
	R2Image image(filename);
	R2Image alphaImage(alphaFile);
	if (image.Width() != alphaImage.Width() || image.Height() != alphaImage.Height()) {
		fprintf(stderr, "ERROR: %ix%i Alpha channel image is not same dimension as %ix%i original image.",
		alphaImage.Width(), alphaImage.Height(), image.Width(), image.Height());
		fprintf(stderr, "\nSkipping alpha channel\n");
		return loadTexture(filename);
	}
	int npixels = image.NPixels();
	R2Pixel *pixels = image.Pixels();
	GLfloat *buffer = new GLfloat [4 * npixels];
	R2Pixel *pixelsp = pixels;
	R2Pixel *alphasp = alphaImage.Pixels();
	GLfloat *bufferp = buffer;
	for (int j = 0; j < npixels; j++) { 
		if (alphasp->Luminance() == 0) {
			*(bufferp++) = 0;*(bufferp++) = 0;*(bufferp++) = 0;*(bufferp++) = 0;
		}
		else {
			*(bufferp++) = pixelsp->Red();
			*(bufferp++) = pixelsp->Green();
			*(bufferp++) = pixelsp->Blue();
			*(bufferp++) = pixelsp->Alpha();
		}
		pixelsp++;
		alphasp++;
	}
	glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_MIN_FILTER,GL_LINEAR);
	glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_MAG_FILTER,GL_LINEAR);
	glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_WRAP_S,GL_REPEAT);
	glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_WRAP_T,GL_REPEAT);
	glTexEnvi(GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE, GL_MODULATE);
	glTexImage2D(GL_TEXTURE_2D, 0, 4, image.Width(), image.Height(), 0, GL_RGBA, GL_FLOAT, buffer);
	delete [] buffer;
	return texture_index;
}