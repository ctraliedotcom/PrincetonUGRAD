#ifndef EXPLOSION_H
#define EXPLOSION_H

#include "R3/R3.h"
#include "R3Scene.h"
#include "GameObject.h"

#define EXPLOSION_TIME 2.5
#define FRAME_WAIT 2

class Explosion {
public:
	Explosion(void* g, void* c);
	~Explosion();
	void draw();
	void updateTime(double dt);
	void updateImage();

	void* gameObject;
	void* camera;
	R2Image* image;
	R2Pixel color;
	double t;
	GLuint texture_index;
	int width, height;
	int frames;
};

#endif