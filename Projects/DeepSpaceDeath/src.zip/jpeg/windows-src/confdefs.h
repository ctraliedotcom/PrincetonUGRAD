
#define HAVE_PROTOTYPES 
#define HAVE_STDDEF_H 
#define HAVE_STDLIB_H 
#define HAVE_UNSIGNED_CHAR 
#define HAVE_UNSIGNED_SHORT 
#define INLINE __inline__
