// Source file for the scene file viewer



////////////////////////////////////////////////////////////
// INCLUDE FILES
////////////////////////////////////////////////////////////

#ifdef _WIN32
#include <windows.h>
#define M_PI 3.1415925
#endif

#include <vector>
#include <ctime>
#include "R3/R3.h"
#include "R3Scene.h"
#include "GameObject.h"
#include "R3Collision.h"
#include "Explosion.h"




////////////////////////////////////////////////////////////
// GLOBAL VARIABLES
////////////////////////////////////////////////////////////

// Program arguments

static char *filename = NULL;
static char *proc_gen_filename = NULL;	// image file from which to procedurally-generate asteroid field
static int max_depth = 3;
static double min_luminance = 0.01;
static unsigned int min_timestep_length = 10;//Minimum length of timestep (msecs)



// Display variables

static R3Scene *scene = NULL;
static GLuint cockpit_texture_index;
static R3Material laser_material;

// GLUT variables 
static int GLUTwindow = 0;
static int GLUTwindow_initXPos = 100;
static int GLUTwindow_initYPos = 100;
static int GLUTwindow_height = 900;
static int GLUTwindow_width = 900;
static int GLUTbutton[3] = { 0, 0, 0 };
static int GLUTmodifiers = 0;

//Mouse/Keyboard control variables
int dx, dy;
int dlf, dud; 

//Joystick variables
//http://msdn.microsoft.com/en-us/library/ms709354(VS.85).aspx
JOYINFOEX joyinfo;
bool using_joystick;
bool using_overhead_view;
bool using_ship_view;

//Timing variables
clock_t start, finish;
double dt;

//Other game variables
int player_ship_index;
Ship* playerShip;
int targeted_index;
Ship* targetedShip;

////////////////////////////////////////////////////////////
// SCENE DRAWING CODE
////////////////////////////////////////////////////////////

void DrawShape(R3Shape *shape)
{
  // Check shape type
  if (shape->type == R3_BOX_SHAPE) shape->box->Draw();
  else if (shape->type == R3_SPHERE_SHAPE) shape->sphere->Draw();
  else if (shape->type == R3_CYLINDER_SHAPE) shape->cylinder->Draw();
  else if (shape->type == R3_CONE_SHAPE) shape->cone->Draw();
  else if (shape->type == R3_MESH_SHAPE) shape->mesh->Draw();
  else if (shape->type == R3_SHIP) { 
		Ship* ship = (Ship*)shape->ship;
		if (ship->is_ai || using_overhead_view || using_ship_view)
			ship->Render();
		if (ship == targetedShip) {
			//Draw a box around the targeted ship
			R3Matrix m = targetedShip->getFullMatrix().Transpose();
			glPushMatrix();
			glMultMatrixd((double*)&m);
				R3Box box = R3unit_box;
				box.Outline();
			glPopMatrix();
		}
  }
  else if (shape->type == R3_OBSTACLE) {
		Obstacle* obstacle = (Obstacle*)shape->obstacle;
		obstacle->Render();
  }
  else fprintf(stderr, "Unrecognized shape type: %d\n", shape->type);
}



void LoadMatrix(R3Matrix *matrix)
{
  // Multiply matrix by top of stack
  // Take transpose of matrix because OpenGL represents vectors with 
  // column-vectors and R3 represents them with row-vectors
  R3Matrix m = matrix->Transpose();
  glMultMatrixd((double *) &m);
}



void LoadMaterial(R3Material *material) 
{
  GLfloat c[4];

  // Check if same as current
  static R3Material *current_material = NULL;
  if (material == current_material) return;
  current_material = material;

  //printf("%f, %f, %f\n", current_material->ks.Red(), 
//	  current_material->ks.Green(), current_material->ks.Blue());

  // Compute "opacity"
  double opacity = 1 - material->kt.Luminance();

  // Load ambient
  c[0] = material->ka[0];
  c[1] = material->ka[1];
  c[2] = material->ka[2];
  c[3] = opacity;
  glMaterialfv(GL_FRONT_AND_BACK, GL_AMBIENT, c);

  // Load diffuse
  c[0] = material->kd[0];
  c[1] = material->kd[1];
  c[2] = material->kd[2];
  c[3] = opacity;
  glMaterialfv(GL_FRONT_AND_BACK, GL_DIFFUSE, c);

  // Load specular
  c[0] = material->ks[0];
  c[1] = material->ks[1];
  c[2] = material->ks[2];
  c[3] = opacity;
  glMaterialfv(GL_FRONT_AND_BACK, GL_SPECULAR, c);

  // Load emission
  c[0] = material->emission.Red();
  c[1] = material->emission.Green();
  c[2] = material->emission.Blue();
  c[3] = opacity;
  glMaterialfv(GL_FRONT_AND_BACK, GL_EMISSION, c);

  // Load shininess
  c[0] = material->shininess;
  glMaterialf(GL_FRONT_AND_BACK, GL_SHININESS, c[0]);

  // Load texture
  if (material->texture) {
    if (material->texture_index <= 0) {
      // Create texture in OpenGL
      GLuint texture_index;
      glGenTextures(1, &texture_index);
      material->texture_index = (int) texture_index;
      glBindTexture(GL_TEXTURE_2D, material->texture_index); 
      R2Image *image = material->texture;
      int npixels = image->NPixels();
      R2Pixel *pixels = image->Pixels();
      GLfloat *buffer = new GLfloat [ 4 * npixels ];
      R2Pixel *pixelsp = pixels;
      GLfloat *bufferp = buffer;
      for (int j = 0; j < npixels; j++) { 
        *(bufferp++) = pixelsp->Red();
        *(bufferp++) = pixelsp->Green();
        *(bufferp++) = pixelsp->Blue();
        *(bufferp++) = pixelsp->Alpha();
        pixelsp++;
      }
      glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_MIN_FILTER,GL_LINEAR);
      glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_MAG_FILTER,GL_LINEAR);
      glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_WRAP_S,GL_REPEAT);
      glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_WRAP_T,GL_REPEAT);
      glTexEnvi(GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE, GL_MODULATE);
      glTexImage2D(GL_TEXTURE_2D, 0, 4, image->Width(), image->Height(), 0, GL_RGBA, GL_FLOAT, buffer);
      delete [] buffer;
    }

    // Select texture
    glBindTexture(GL_TEXTURE_2D, material->texture_index); 
    glEnable(GL_TEXTURE_2D);
  }
  else {
    glDisable(GL_TEXTURE_2D);
  }

  // Enable blending for transparent surfaces
  if (opacity < 1) {
    glDepthMask(false);
    glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);
    glEnable(GL_BLEND);
  }
  else {
    glDisable(GL_BLEND);
    glBlendFunc(GL_ONE, GL_ZERO);
    glDepthMask(true);
  }
}



void LoadCamera(R3Scene *scene)
{
  // Set projection transformation
  glMatrixMode(GL_PROJECTION);
  glLoadIdentity();
  gluPerspective(360.0*scene->camera.yfov/M_PI, (GLdouble) GLUTwindow_width /(GLdouble) GLUTwindow_height, 
                 scene->camera.neardist, 1000);

  // Set scene->camera transformation
  R3Vector t = -(scene->camera.towards);
  R3Vector& u = scene->camera.up;
  R3Vector& r = scene->camera.right;
  GLdouble camera_matrix[16] = { r[0], u[0], t[0], 0, r[1], u[1], t[1], 0, r[2], u[2], t[2], 0, 0, 0, 0, 1 };
  glMatrixMode(GL_MODELVIEW);
  glLoadIdentity();
  glMultMatrixd(camera_matrix);
  glTranslated(-(scene->camera.eye[0]), -(scene->camera.eye[1]), -(scene->camera.eye[2]));
}



void LoadLights(R3Scene *scene)
{
  GLfloat buffer[4];

  // Load ambient light
  static GLfloat ambient[4];
  ambient[0] = scene->ambient[0];
  ambient[1] = scene->ambient[1];
  ambient[2] = scene->ambient[2];
  ambient[3] = 1;
  glLightModelfv(GL_LIGHT_MODEL_AMBIENT, ambient);

  // Load scene lights
  for (int i = 0; i < (int) scene->lights.size(); i++) {
    R3Light *light = scene->lights[i];
    int index = GL_LIGHT0 + i;

    // Temporarily disable light
    glDisable(index);

    // Load color
    buffer[0] = light->color[0];
    buffer[1] = light->color[1];
    buffer[2] = light->color[2];
    buffer[3] = 1.0;
    glLightfv(index, GL_DIFFUSE, buffer);
    glLightfv(index, GL_SPECULAR, buffer);

    // Load attenuation with distance
    buffer[0] = light->constant_attenuation;
    buffer[1] = light->linear_attenuation;
    buffer[2] = light->quadratic_attenuation;
    glLightf(index, GL_CONSTANT_ATTENUATION, buffer[0]);
    glLightf(index, GL_LINEAR_ATTENUATION, buffer[1]);
    glLightf(index, GL_QUADRATIC_ATTENUATION, buffer[2]);

    // Load spot light behavior
    buffer[0] = 180.0 * light->angle_cutoff / M_PI;
    buffer[1] = light->angle_attenuation;
    glLightf(index, GL_SPOT_CUTOFF, buffer[0]);
    glLightf(index, GL_SPOT_EXPONENT, buffer[1]);

    // Load positions/directions
    if (light->type == R3_DIRECTIONAL_LIGHT) {
      // Load direction
      buffer[0] = -(light->direction.X());
      buffer[1] = -(light->direction.Y());
      buffer[2] = -(light->direction.Z());
      buffer[3] = 0.0;
      glLightfv(index, GL_POSITION, buffer);
    }
    else if (light->type == R3_POINT_LIGHT) {
      // Load position
      buffer[0] = light->position.X();
      buffer[1] = light->position.Y();
      buffer[2] = light->position.Z();
      buffer[3] = 1.0;
      glLightfv(index, GL_POSITION, buffer);
    }
    else if (light->type == R3_SPOT_LIGHT) {
      // Load position
      buffer[0] = light->position.X();
      buffer[1] = light->position.Y();
      buffer[2] = light->position.Z();
      buffer[3] = 1.0;
      glLightfv(index, GL_POSITION, buffer);

      // Load direction
      buffer[0] = light->direction.X();
      buffer[1] = light->direction.Y();
      buffer[2] = light->direction.Z();
      buffer[3] = 1.0;
      glLightfv(index, GL_SPOT_DIRECTION, buffer);
    }
    else {
      fprintf(stderr, "Unrecognized light type: %d\n", light->type);
      return;
    }

    // Enable light
    glEnable(index);
  }
}

void DrawRadar() {
	double r = sqrt((double)(GLUTwindow_width*GLUTwindow_width + 
		GLUTwindow_height*GLUTwindow_height));
	r /= 15;
	glColor3f(0.5, 0.5, 0.5);
	glBegin(GL_TRIANGLE_FAN);
	for (double a = 0; a <= 2*PI; a += 0.1) {
		glVertex2f(GLUTwindow_width/4.0 + sin(a)*r, GLUTwindow_height/15.0 + cos(a)*r);
	}
	glEnd();
	glBegin(GL_TRIANGLE_FAN);
	for (double a = 0; a <= 2*PI; a += 0.1) {
		glVertex2f(GLUTwindow_width*3/4.0 + sin(a)*r, GLUTwindow_height/15.0 + cos(a)*r);
	}
	glEnd();
	//Draw the enemy ships on the radar (red dots)
	for (int i = 0; i < scene->ships.size(); i++) {
		glColor3f(1.0, 0, 0);
		Ship* ship = (Ship*)scene->ships[i]->shape->ship;
		if (ship != playerShip) {
			if (ship == targetedShip)
				glColor3f(1.0, 1.0, 1.0);
			R3Vector v = ship->getWorldPos() - playerShip->getWorldPos();
			glPointSize(5);
			double xoffset = GLUTwindow_width / 4;
			double yoffset = GLUTwindow_height / 15;
			if (v.Dot(playerShip->towards) < 0)	xoffset *= 3; //Behind player ship
			R3Vector v2D = v;
			v2D.Normalize();
			v2D *= r;
			R3Vector v2D_X = v2D;
			R3Vector v2D_Y = v2D;
			v2D_X.Project(playerShip->right);
			v2D_Y.Project(playerShip->up);
			double x = v2D_X.Length();
			double y = v2D_Y.Length();
			if (v2D_X.Dot(playerShip->right) < 0) x *= -1;
			if (v2D_Y.Dot(playerShip->up) < 0) y *= -1;
			glBegin(GL_POINTS);
				glVertex2d(xoffset + x, yoffset + y);
			glEnd();
		}
	}
	//Now draw the obstacle points on the radar (blue dots)
	glColor3f(0, 0, 1.0);
	for (int i = 0; i < scene->obstacles.size(); i++) {
		Obstacle* obstacle = (Obstacle*)scene->obstacles[i]->shape->obstacle;
		R3Vector v = obstacle->getWorldPos() - playerShip->getWorldPos();
		glPointSize(5);
		double xoffset = GLUTwindow_width / 4;
		double yoffset = GLUTwindow_height / 15;
		if (v.Dot(playerShip->towards) < 0)	xoffset *= 3; //Behind player ship
		R3Vector v2D = v;
		v2D.Normalize();
		v2D *= r;
		R3Vector v2D_X = v2D;
		R3Vector v2D_Y = v2D;
		v2D_X.Project(playerShip->right);
		v2D_Y.Project(playerShip->up);
		double x = v2D_X.Length();
		double y = v2D_Y.Length();
		if (v2D_X.Dot(playerShip->right) < 0) x *= -1;
		if (v2D_Y.Dot(playerShip->up) < 0) y *= -1;
		glBegin(GL_POINTS);
			glVertex2d(xoffset + x, yoffset + y);
		glEnd();
	}
	glColor3f(1.0, 1.0, 1.0);
}

//Draw the health, shields, and laser power as bars in the cockpit
void DrawControls() {
	//Health
	glColor3f(1, 1, 1);
	int xoffset = GLUTwindow_width / 6;
	int height = GLUTwindow_height / 60;
	int yoffset = GLUTwindow_height / 12;
	glBegin(GL_QUADS);
		glVertex2i(xoffset, yoffset);
		glVertex2i(xoffset, yoffset + height);
		glVertex2i(0, yoffset + height);
		glVertex2i(0, yoffset);
	glEnd();
	glColor3f(1, 0, 0);
	int xoffset2 = (int)((double)xoffset * playerShip->health / 100.0);
	glBegin(GL_QUADS);
		glVertex2i(xoffset2, yoffset);
		glVertex2i(xoffset2, yoffset + height);
		glVertex2i(0, yoffset + height);
		glVertex2i(0, yoffset);
	glEnd();

	//Shields
	yoffset = yoffset - 2*height;
	glColor3f(1, 1, 1);
	glBegin(GL_QUADS);
		glVertex2i(xoffset, yoffset);
		glVertex2i(xoffset, yoffset + height);
		glVertex2i(0, yoffset + height);
		glVertex2i(0, yoffset);
	glEnd();
	glColor3f(0, 0, 1);
	xoffset2 = (int)((double)xoffset * playerShip->shield_strength / 100.0);
	glBegin(GL_QUADS);
		glVertex2i(xoffset2, yoffset);
		glVertex2i(xoffset2, yoffset + height);
		glVertex2i(0, yoffset + height);
		glVertex2i(0, yoffset);
	glEnd();

	//Laser Power
	yoffset = yoffset - 2*height;
	glColor3f(1, 1, 1);
	glBegin(GL_QUADS);
		glVertex2i(xoffset, yoffset);
		glVertex2i(xoffset, yoffset + height);
		glVertex2i(0, yoffset + height);
		glVertex2i(0, yoffset);
	glEnd();
	glColor3f(0, 1, 0);
	Laser* laser = (Laser*)playerShip->laser_cannon;
	xoffset2 = (int)((double)xoffset * laser->cur_strength / 100.0);
	glBegin(GL_QUADS);
		glVertex2i(xoffset2, yoffset);
		glVertex2i(xoffset2, yoffset + height);
		glVertex2i(0, yoffset + height);
		glVertex2i(0, yoffset);
	glEnd();

	glColor3f(1.0, 1.0, 1.0);
}

void drawString2D(char* s, int x, int y, void* FONT) {
	glRasterPos2f(x, y);
	char* p = s;
	while (*p) {
		glutBitmapCharacter(FONT, *p);
		p++;
	}
	glColor3f(1, 1, 1);
}

void DrawTargetingComputer() {
	int xoffset = GLUTwindow_width * 4 / 10;
	int width = GLUTwindow_width * 2 / 10;
	int yoffset = GLUTwindow_height / 18;
	int height = GLUTwindow_height / 9;
	glColor3f(0.5, 0, 0);
	glBegin(GL_QUADS);
		glVertex2i(xoffset + width, yoffset);
		glVertex2i(xoffset + width, yoffset + height);
		glVertex2i(xoffset, yoffset + height);
		glVertex2i(xoffset, yoffset);
	glEnd();
	glColor3f(0.5, 0.5, 0.5);
	glBegin(GL_QUADS);
		glVertex2i(xoffset + width - 5, yoffset + 5);
		glVertex2i(xoffset + width - 5, yoffset + height - 5);
		glVertex2i(xoffset + 5, yoffset + height - 5);
		glVertex2i(xoffset + 5, yoffset + 5);
	glEnd();
	glColor3f(0, 1, 0);
	if (targetedShip == NULL) {
		drawString2D("Press 'T' to target", 
			xoffset + 10, yoffset + height / 2, GLUT_BITMAP_HELVETICA_18);
	}
	else {
		glColor3f(1, 1, 1);
		char str[100];
		sprintf(str, "Ship %i", targetedShip->number);
		drawString2D(str, xoffset + 10, yoffset + height - 20, GLUT_BITMAP_HELVETICA_12);
		sprintf(str, "Health: %.1f", targetedShip->health);
		drawString2D(str, xoffset + 10, yoffset + 5*height/6 - 20, GLUT_BITMAP_HELVETICA_12);
		sprintf(str, "Shields: %.1f", targetedShip->shield_strength);
		drawString2D(str, xoffset + 10, yoffset + 4*height/6 - 20, GLUT_BITMAP_HELVETICA_12);
		sprintf(str, "Speed: %.1f", targetedShip->velocity.Length());
		drawString2D(str, xoffset + 10, yoffset + 3*height/6 - 20, GLUT_BITMAP_HELVETICA_12);
		sprintf(str, "Distance: %.1f", 
			(targetedShip->getWorldPos() - playerShip->getWorldPos()).Length());
		drawString2D(str, xoffset + 10, yoffset + 2*height/6 - 20, GLUT_BITMAP_HELVETICA_12);
	}
	glColor3f(1, 1, 1);
}

void DrawCockpit() {
	glDisable(GL_DEPTH_TEST);
	glDisable(GL_LIGHTING);
	glMatrixMode(GL_PROJECTION);
	glLoadIdentity();
	gluOrtho2D(0, GLUTwindow_width, 0, GLUTwindow_height);
	glMatrixMode(GL_MODELVIEW);
	glLoadIdentity();
     glBindTexture(GL_TEXTURE_2D,cockpit_texture_index);
	 glEnable(GL_TEXTURE_2D);
	 glEnable(GL_BLEND);//This is needed to make the cockpit see-through
	 glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);
	 //If the player's health is low, shade the cockpit more and more red
	 if (playerShip->health < 100)
		 glColor3f(1, playerShip->health / 100.0, playerShip->health / 100.0);
     glBegin(GL_QUADS);
	 	glTexCoord2f(0.0f,1.0f); glVertex2i(GLUTwindow_width, 0);
		glTexCoord2f(1.0f,1.0f); glVertex2i(GLUTwindow_width, GLUTwindow_height);
		glTexCoord2f(1.0f,0.0f); glVertex2i(0, GLUTwindow_height);
		glTexCoord2f(0.0f,0.0f); glVertex2i(0, 0);
     glEnd();
	 glColor3f(1.0, 1.0, 1.0);
	 DrawRadar();
	 DrawControls();
	 DrawTargetingComputer();
	 //Draw Speed
	 char str[100];
	 sprintf(str, "Speed: %.2f", playerShip->velocity.Length());
	 glColor3f(0, 0, 0);
	 drawString2D(str, GLUTwindow_width * 6 / 7, 10, GLUT_BITMAP_HELVETICA_18);
	 //Draw the framerate
	 glColor3f(1, 0, 0);
	 sprintf(str, "%i FPS", (int)(1.0 / dt));
	 drawString2D(str, GLUTwindow_width * 9 / 10, GLUTwindow_height * 19 / 20, 
		 GLUT_BITMAP_HELVETICA_18);
	 //Draw the ship name
	 glColor3f(1, 1, 1);
	 sprintf(str, "Ship %i", playerShip->number);
	 drawString2D(str, 10, GLUTwindow_height * 19 / 20, GLUT_BITMAP_HELVETICA_18);
	glEnable(GL_DEPTH_TEST);
	glEnable(GL_LIGHTING);
}

void DrawNode(R3Node* node, R3Matrix transform) {
  glPushMatrix();
  LoadMatrix(&transform);
  // Load material
  if (node->material) LoadMaterial(node->material);
  // Draw shape
  if (node->shape) DrawShape(node->shape);
  // Restore previous transformation
  glPopMatrix();
}

void DrawScene(R3Scene *scene) 
{
  // Load camera
  LoadCamera(scene);

  // Load lights
  LoadLights(scene);
  
  for (int i = 0; i < scene->ships.size(); i++) {
	scene->ships [ i ]->material->ks.SetRed ( 1.0 - ( (Ship *)( scene->ships [ i ]->shape->ship ) )->health / 100.0 );
	Ship* ship = (Ship*)scene->ships[i]->shape->ship;
	if (ship->explosion != NULL) {//The ship is exploding, need to draw explosion
		Explosion* e = (Explosion*)ship->explosion;
		e->draw();
		R3Material* m = scene->ships[i]->material;
		m->ka = e->color;m->kd = e->color;m->ks = e->color;
	}
	DrawNode(scene->ships[i], ship->transformations);
  }

  for (int i = 0; i < scene->obstacles.size(); i++) {
    Obstacle* obstacle = (Obstacle*)scene->obstacles[i]->shape->obstacle;
	if (obstacle->explosion != NULL) { //The object is exploding, need to draw explosion
		Explosion *e = (Explosion*)obstacle->explosion;
		e->draw();
		R3Material* m = scene->obstacles[i]->material;
		m->ka = e->color;m->kd = e->color;m->ks = e->color;
	}
	DrawNode(scene->obstacles[i], obstacle->transformations);
  }

  //Draw all active lasers
  for (int i = 0; i < scene->ships.size(); i++) {
	Ship* ship = (Ship*)scene->ships[i]->shape->ship;
	LoadMaterial(&laser_material);
	Laser* laser = (Laser*)ship->laser_cannon;
	laser->Render();
  }
}



////////////////////////////////////////////////////////////
// GLUT USER INTERFACE CODE
////////////////////////////////////////////////////////////

void GLUTMainLoop(void)
{
  // Run main loop -- never returns 
  glutMainLoop();
}



void GLUTDrawText(const R3Point& p, const char *s)
{
  // Draw text string s and position p
  glRasterPos3d(p[0], p[1], p[2]);
  while (*s) glutBitmapCharacter(GLUT_BITMAP_HELVETICA_12, *(s++));
}
  



void GLUTStop(void)
{
  // Destroy window 
  glutDestroyWindow(GLUTwindow);

  // Delete scene
  delete scene;

  // Exit
  exit(0);
}



void GLUTResize(int w, int h)
{
  // Resize window
  glViewport(0, 0, w, h);

  // Resize camera vertical field of view to match aspect ratio of viewport
  scene->camera.yfov = atan(tan(scene->camera.xfov) * (double) h/ (double) w); 

  // Remember window size 
  GLUTwindow_width = w;
  GLUTwindow_height = h;

  // Redraw
  glutPostRedisplay();
}



void GLUTRedraw(void)
{
  // Clear window 
  R3Rgb background = scene->background;
  glClearColor(background[0], background[1], background[2], background[3]);
  glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

  // Draw scene surfaces
  glEnable(GL_LIGHTING);
  DrawScene(scene);

  // Draw scene edges
	/*glDisable(GL_LIGHTING);
	glColor3d(1 - background[0], 1 - background[1], 1 - background[2]);
	glPolygonMode(GL_FRONT_AND_BACK, GL_LINE);
	DrawScene(scene);
	glPolygonMode(GL_FRONT_AND_BACK, GL_FILL);*/

  if (!using_overhead_view && !using_ship_view)
	DrawCockpit();
  // Swap buffers 
  glutSwapBuffers();
}


void GLUTMouse(int button, int state, int x, int y)
{
  // Invert y coordinate
  y = GLUTwindow_height - y;
  
  // Process mouse button event
  if (state == GLUT_DOWN) {
    if (button == GLUT_LEFT_BUTTON) {
    }
    else if (button == GLUT_MIDDLE_BUTTON) {
    }
    else if (button == GLUT_RIGHT_BUTTON) {
    }
  }

  // Remember button state 
  int b = (button == GLUT_LEFT_BUTTON) ? 0 : ((button == GLUT_MIDDLE_BUTTON) ? 1 : 2);
  GLUTbutton[b] = (state == GLUT_DOWN) ? 1 : 0;

  // Remember modifiers 
  GLUTmodifiers = glutGetModifiers();
}



void GLUTSpecial(int key, int x, int y)
{
  // Process keyboard button event 
  switch (key) {
  case GLUT_KEY_DOWN:
	dud = -1;
    break;

  case GLUT_KEY_UP:
	dud = 1;
    break;

  case GLUT_KEY_LEFT:
	dlf = -1;
    break;

  case GLUT_KEY_RIGHT:
	dlf = 1;
    break;
  }

  // Remember modifiers 
  GLUTmodifiers = glutGetModifiers();
}

void GLUTSpecialUp(int key, int x, int y)
{
  // Process keyboard button event 
  switch (key) {
  case GLUT_KEY_DOWN:
	dud = 0;
    break;

  case GLUT_KEY_UP:
	dud = 0;
    break;

  case GLUT_KEY_LEFT:
	dlf = 0;
    break;

  case GLUT_KEY_RIGHT:
	dlf = 0;
    break;
  }

  // Remember modifiers 
  GLUTmodifiers = glutGetModifiers();
}

//Cycle through the ships in the scene
void changePlayerShip() {
	playerShip->is_ai = true;
	player_ship_index++;
	if (player_ship_index >= scene->ships.size()) {
		player_ship_index = 0;
	}
	playerShip = (Ship*)scene->ships[player_ship_index]->shape->ship;
	playerShip->is_ai = false;
	targetedShip = NULL;
	targeted_index = 0;
}

//Cycle through the ships in the scene
void changeTargetedShip() {
	if (scene->ships.size() <= 1) {
		targeted_index = 0;
		targetedShip = NULL;
		return;
	}
	targeted_index++;
	if (targeted_index == player_ship_index)
		targeted_index++;
	if (targeted_index >= scene->ships.size()) {
		targeted_index = 0;
	}
	targetedShip = (Ship*)scene->ships[targeted_index]->shape->ship;
}

void killShip(int index, Ship* ship) {
	if (index >= scene->ships.size() || index < 0) {
		fprintf(stderr, "ERROR: Trying to remove a ship that doesn't exist\n");
		return;
	}
	if (index == targeted_index)
		targetedShip = NULL;
	//Swap this ship with the ship at the end of the list
	delete ship;
	delete scene->ships[index];
	scene->ships[index] = scene->ships[scene->ships.size() - 1];
	scene->ships.pop_back();
	if (index == player_ship_index) { //If the player was just removed
		//Switch the player into one of the ships that's still alive
		if (scene->ships.size() < 1)
			exit(0);
		player_ship_index = 0;
		playerShip = (Ship*)scene->ships[0]->shape->ship;
		targetedShip = NULL;
		playerShip->is_ai = false;
	}
}

void killObstacle(int index, Obstacle* obstacle) {
	if (index >= scene->obstacles.size() || index < 0) {
		fprintf(stderr, "ERROR: Trying to remove a obstacle that doesn't exist\n");
		return;
	}
	//Swap this obstacle with the obstacle at the end of the list
	delete obstacle;
	delete scene->obstacles[index];
	scene->obstacles[index] = scene->obstacles[scene->obstacles.size() - 1];
	scene->obstacles.pop_back();
}

void GLUTKeyboard(unsigned char key, int x, int y)
{
  // Process keyboard button event 
  switch (key) {
	  case 'M':
	  case 'm':
		    sndPlaySound("Sounds/music.wav", SND_ASYNC);
		break;
	  case 'C':
	  case 'c':
		changePlayerShip();
		break;

	  case 'T':
	  case 't':
		  changeTargetedShip();
		break;

	  case 'Q':
	  case 'q':
		GLUTStop();
		break;

	  case 'J':
	  case 'j':
		  using_joystick = !using_joystick;
	  break;

	  case 'O':
	  case 'o':
		  {
		  using_ship_view = false;
		  using_overhead_view = !using_overhead_view;
		  break;
		  }

	  case 'S':
	  case 's':
		  {
			using_overhead_view = false;
			using_ship_view = !using_ship_view;
			break;
		  }

// TODO: this is health system debug code
	  case 'H':
	  case 'h':
		  playerShip->doDamage ( ( (double)rand () / RAND_MAX ) * FULL_HEALTH * 2.0 );
		  break;

	  case ' ': {
		R3Camera& c = scene->camera;
		printf("camera %g %g %g  %g %g %g  %g %g %g  (%g, %g)  %g %g \n",
			   c.eye[0], c.eye[1], c.eye[2], 
			   c.towards[0], c.towards[1], c.towards[2], 
			   c.up[0], c.up[1], c.up[2], 
			   c.xfov, c.yfov, c.neardist, c.fardist); 
		break; }

	  case 27: // ESCAPE
		GLUTStop();
		break;
  }

  // Remember modifiers 
  GLUTmodifiers = glutGetModifiers();

  // Redraw
  glutPostRedisplay();
}


void updateCamera() {
	Ship* ship;
	if ( !using_overhead_view && !using_ship_view)
	{
		/*Lock the camera to the ship's point of view
		*The code below will work fine as long as no rotations/scales
		*were done in the scene file*/
		R3Camera* camera = &scene->camera;
		camera->up = playerShip->up;
		camera->right = playerShip->right;
		camera->towards = playerShip->towards;
		camera->eye = playerShip->transformations * playerShip->position;
	}
	else if (using_overhead_view)
	{
		// set camera to middle of uppermost plane of scene's bounding box
		scene->camera.eye.SetX ( scene->bbox.XMin () + ( scene->bbox.XMax () - scene->bbox.XMin () ) / 2.0 );
		scene->camera.eye.SetZ ( scene->bbox.ZMin () + ( scene->bbox.ZMax () - scene->bbox.ZMin () ) / 2.0 );
		double hx = scene->bbox.XLength() / tan(scene->camera.xfov);
		double hz = scene->bbox.ZLength() / tan(scene->camera.yfov);
		double height = hx;
		if (hz > hx) height = hz;
		if (scene->bbox.YLength() > height) height = scene->bbox.YLength();
		scene->camera.eye.SetY(scene->bbox.YMin() + height);

		scene->camera.up = R3Vector ( 0.0, 0.0, -1.0 );	// along negative Z axis
		scene->camera.right = R3Vector ( 1.0, 0.0, 0.0 );	// along positive X axis
		scene->camera.towards = R3Vector ( 0.0, -1.0, 0.0 );	// along negative Y axis
	}
	//Center the camera above all of the ships in the scne
	else if (using_ship_view) {
		R3Box bbox(0, 0, 0, 1, 1, 1);
		for (int i = 0; i < scene->ships.size(); i++) {
			ship = (Ship*)scene->ships[i]->shape->ship;
			bbox.Union(ship->getWorldPos());
		}
		scene->camera.eye.SetX(bbox.XMin() + bbox.XMax() - bbox.XMin()/2.0);
		scene->camera.eye.SetZ(bbox.ZMin() + bbox.ZMax() - bbox.ZMin()/2.0);
		double hx = bbox.XLength() / tan(scene->camera.xfov);
		double hz = bbox.ZLength() / tan(scene->camera.yfov);
		double height = hx;
		if (hz > hx) height = hz;
		if (bbox.YLength() > height) height = bbox.YLength();
		scene->camera.eye.SetY(bbox.YMin() + height);
		scene->camera.up = R3Vector ( 0.0, 0.0, -1.0 );
		scene->camera.right = R3Vector ( 1.0, 0.0, 0.0 );
		scene->camera.towards = R3Vector ( 0.0, -1.0, 0.0 );
	}
}


//http://www.opengl.org/documentation/specs/glut/spec3/node64.html#SECTION000819000000000000000
void Timestep(int value) {
	if (scene->ships.size() < 1)//If there are no more ships in the scene, quit the program
		exit(0);
	finish = clock();
	dt = (double(finish)-double(start))/CLOCKS_PER_SEC;
	start = finish;
	Ship* ship;
	Obstacle* obstacle;
	double pitch, yaw, roll, accel;

	for (int i = 0; i < scene->ships.size(); i++) {
		ship = (Ship*)scene->ships[i]->shape->ship;
		if (ship->health == 0) {
			//Its health is zero, but it's not dead, so it must be exploding
			if (ship->explosion == NULL) {
				ship->explosion = new Explosion(ship, &scene->camera);
				sndPlaySound("Sounds/explosion.wav", SND_ASYNC);
				//I tried adding a light at the focal point of each explosion
				//but it didn't seem to make much of a difference
				/*R3Light* light = new R3Light();
				light->color = R2white_pixel;
				light->type = R3_POINT_LIGHT;
				light->constant_attenuation = 1.0;
				scene->lights.push_back(light);*/
			}
			//printf("doing explosion: %f\n", ((Explosion*)ship->explosion)->t);
			((Explosion*)ship->explosion)->updateTime(dt);
			if (((Explosion*)(ship->explosion))->t > EXPLOSION_TIME)
				killShip(i, ship);
			continue;
		}
		ship->TimeStep ( dt, &scene->ships, &scene->obstacles );
		if (ship->is_ai)
			ship->Think(dt, &scene->ships, &scene->obstacles, playerShip);
		else
			player_ship_index = i;//Reinforce the player ship's index
		if (ship == targetedShip) 
			targeted_index = i;
	}
	for (int i = 0; i < scene->obstacles.size(); i++) {
		obstacle = (Obstacle*)scene->obstacles[i]->shape->obstacle;
		if (obstacle->health == 0) {
			//Its health is zero, but it's not dead, so it must be exploding
			if (obstacle->explosion == NULL) {
				sndPlaySound("Sounds/explosion.wav", SND_ASYNC);
				obstacle->explosion = new Explosion(obstacle, &scene->camera);
			}
			((Explosion*)obstacle->explosion)->updateTime(dt);
			if (((Explosion*)(obstacle->explosion))->t > EXPLOSION_TIME)
				killObstacle(i, obstacle);
			continue;
		}
		obstacle->TimeStep(dt, &scene->ships, &scene->obstacles);
	}
	
	Laser* playerLaser = (Laser*)playerShip->laser_cannon;
	if (playerShip->health == 0) {}//Disable control if player's health is zero
	else if (using_joystick) {
		joyGetPosEx(JOYSTICKID1, &joyinfo);
		double offset = 32768;
		pitch = 6*((double)joyinfo.dwYpos - offset) / offset;
		yaw = -6*((double)joyinfo.dwXpos - offset) / offset;
		roll = 6*((double)joyinfo.dwRpos - offset) / offset;
		accel =  -playerShip->max_accel*((double)joyinfo.dwZpos - offset) / offset;
		if (joyinfo.dwButtons & 0x1)
			playerLaser->Fire();
		else
			playerLaser->HoldFire();
		if (joyinfo.dwButtons & 0x2)
			;//TODO: Secondary Fire
		//printf("%i, %i, %i, %i\n", joyinfo.dwXpos, joyinfo.dwYpos, joyinfo.dwZpos, joyinfo.dwRpos);
	}
	else {
		POINT point;
		GetCursorPos(&point);
		dx = point.x - (GLUTwindow_initXPos + GLUTwindow_width / 2);
		dy = point.y - (GLUTwindow_initYPos + GLUTwindow_height / 2);
		pitch = -6.0 * dy;
		yaw = -6.0 * dx;
		roll = 6.0 * dlf;
		accel = 4.0 * dud;
		SetCursorPos(GLUTwindow_initXPos + GLUTwindow_width / 2,
					GLUTwindow_initYPos + GLUTwindow_height / 2);
		if (GLUTbutton[GLUT_LEFT_BUTTON])
			playerLaser->Fire();
		else
			playerLaser->HoldFire();

	}
	//printf("%f, %f, %f, %f\n", roll, pitch, yaw, accel);
	playerShip->accelForward(accel);
	playerShip->ChangePitch(pitch, dt);
	playerShip->ChangeYaw(yaw, dt);
	playerShip->ChangeRoll(roll, dt);
	
	doCollisions(&scene->ships, &scene->obstacles, dt);

	updateCamera();

	//Re-register timestep callback for next timestep
	glutTimerFunc(min_timestep_length, Timestep, 1);
	//Redraw updated scene
	glutPostRedisplay();
}



void GLUTInit(int *argc, char **argv)
{
  // Open window 
  glutInit(argc, argv);
  glutInitWindowPosition(GLUTwindow_initXPos, GLUTwindow_initYPos);
  glutInitWindowSize(GLUTwindow_width, GLUTwindow_height);
  glutInitDisplayMode(GLUT_DOUBLE | GLUT_RGB | GLUT_DEPTH); // | GLUT_STENCIL
  GLUTwindow = glutCreateWindow("J&C's Ultimate Open Space Flight Sim");

  // Initialize GLUT callback functions 
  glutReshapeFunc(GLUTResize);
  glutDisplayFunc(GLUTRedraw);
  glutKeyboardFunc(GLUTKeyboard);
  glutSpecialFunc(GLUTSpecial);
  glutSpecialUpFunc(GLUTSpecialUp);
  glutMouseFunc(GLUTMouse);
  //Start the timesteps
  glutTimerFunc(min_timestep_length, Timestep, 1);

  // Initialize graphics modes 
  glEnable(GL_NORMALIZE);
  glEnable(GL_LIGHTING);
  glEnable(GL_DEPTH_TEST);
  glLightModeli(GL_LIGHT_MODEL_LOCAL_VIEWER, GL_TRUE);
  
  start = clock();
}




////////////////////////////////////////////////////////////
// PROGRAM ARGUMENT PARSING
////////////////////////////////////////////////////////////

int 
ParseArgs(int argc, char **argv)
{
  // Innocent until proven guilty
  int print_usage = 0;

  using_overhead_view = false;
  using_ship_view = false;

  // Parse arguments
  argc--; argv++;
  while (argc > 0) {
    if ((*argv)[0] == '-') {
      if (!strcmp(*argv, "-help")) { print_usage = 1; }
      else if (!strcmp(*argv, "-max_depth")) { argc--; argv++; max_depth = atoi(*argv); }
      else if (!strcmp(*argv, "-min_luminance")) { argc--; argv++; min_luminance = atof(*argv); }
	  else if (!strcmp(*argv, "-joystick")) { argc--; argv++; using_joystick = true; }
	  else if (!strcmp(*argv, "-overhead")) { argc--; argv++; using_overhead_view = true; }
	  else if (!strcmp(*argv, "-shipview")) { argc--; argv++; using_ship_view = true; }
	  else if (!strcmp(*argv, "-proc_gen")) { argc -= 2; argv++; proc_gen_filename = *argv; argv++; }
	  else { fprintf(stderr, "Invalid program argument: %s", *argv); exit(1); }
      argv++; argc--;
    }
    else {
      if (!filename) filename = *argv;
      else { fprintf(stderr, "Invalid program argument: %s", *argv); exit(1); }
      argv++; argc--;
    }
  }

  // Check filename
  if (!filename || print_usage) {
    printf("Usage: SpaceSim <filename>\n");
    return 0;
  }

  // Return OK status 
  return 1;
}



////////////////////////////////////////////////////////////
// SCENE READING
////////////////////////////////////////////////////////////


R3Scene *
ReadScene(const char *filename)
{
  // Allocate scene
  R3Scene *scene = new R3Scene();
  if (!scene) {
    fprintf(stderr, "Unable to allocate scene\n");
    return NULL;
  }

  // Read file
  if (!scene->Read(filename)) {
    fprintf(stderr, "Unable to read scene from %s\n", filename);
    return NULL;
  }

  // Procedurally-generate asteroid field
  scene->ProcGen ( proc_gen_filename );

  // Provide default camera
  if (scene->camera.xfov == 0) {
    double scene_radius = scene->BBox().DiagonalRadius();
    R3Point scene_center = scene->BBox().Centroid();
    scene->camera.towards = R3Vector(0, 0, -1);
    scene->camera.up = R3Vector(0, 1, 0);
    scene->camera.right = R3Vector(1, 0, 0);
    scene->camera.eye = scene_center - 3 * scene_radius * scene->camera.towards;
    scene->camera.xfov = 0.5;
    scene->camera.yfov = 0.5;
    scene->camera.neardist = 0.01 * scene_radius;
    scene->camera.fardist = 100 * scene_radius;
  }

  // Provide default light
  if (scene->NLights() == 0) {
    // Create first directional light
    R3Light *light = new R3Light();
    light->type = R3_DIRECTIONAL_LIGHT;
    light->color = R3Rgb(1,1,1,1);
    light->position = R3Point(0, 0, 0);
    light->direction = R3Vector(-3,-4,-5);
    light->constant_attenuation = 0;
    light->linear_attenuation = 0;
    light->quadratic_attenuation = 0;
    light->angle_attenuation = 0;
    light->angle_cutoff = M_PI;
    scene->lights.push_back(light);

    // Create second directional light
    light = new R3Light();
    light->type = R3_DIRECTIONAL_LIGHT;
    light->color = R3Rgb(0.5, 0.5, 0.5, 1);
    light->position = R3Point(0, 0, 0);
    light->direction = R3Vector(3,2,3);
    light->constant_attenuation = 0;
    light->linear_attenuation = 0;
    light->quadratic_attenuation = 0;
    light->angle_attenuation = 0;
    light->angle_cutoff = M_PI;
    scene->lights.push_back(light);
  }

  // Return scene
  return scene;
}



////////////////////////////////////////////////////////////
// MAIN
////////////////////////////////////////////////////////////

int 
main(int argc, char **argv)
{
  // Initialize GLUT
  GLUTInit(&argc, argv);

  cockpit_texture_index = loadTexture("Images/cockpit.jpg", "Images/cockpit_alpha.bmp");


  // Parse program arguments
  if (!ParseArgs(argc, argv)) exit(1);

  // Read scene
  scene = ReadScene(filename);
  if (!scene) exit(-1);
  if (scene->ships.size() == 0) {
	  fprintf(stderr, "ERROR: Need at least one ship in the scene for the player\n");
	  return 1;
  }
  //Store the product of transformation matrices in ship/obstacle objects
  accumTransforms(scene->root, R3identity_matrix);
  joyinfo.dwSize = sizeof(joyinfo);
  joyinfo.dwFlags = JOY_RETURNALL;
  player_ship_index = 0;
  playerShip = (Ship*)scene->ships[0]->shape->ship;
  playerShip->is_ai = false;

  //Set up laser material
  laser_material.ks = R2Pixel(0, 0.5, 0, 0.5);
  laser_material.kd = R2Pixel(0, 0.5, 0, 0.5);
  laser_material.shininess = 20;
  laser_material.texture_index = -1;
  laser_material.emission = R2Pixel(0, 1, 0, 0);

  // Run GLUT interface
  GLUTMainLoop();

  // Return success 
  return 0;
}









