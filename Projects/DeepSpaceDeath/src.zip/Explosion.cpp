#include "Explosion.h"

Explosion::Explosion(void* g, void* c) {
	gameObject = g;
	camera = c;
	t = 0;
	glGenTextures(1, &texture_index);
	glBindTexture(GL_TEXTURE_2D, texture_index); 
	glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_MIN_FILTER,GL_LINEAR);
	glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_MAG_FILTER,GL_LINEAR);
	glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_WRAP_S,GL_REPEAT);
	glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_WRAP_T,GL_REPEAT);
	glTexEnvi(GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE, GL_MODULATE);
	width = 256;
	height = 256;
	image = new R2Image(width, height);
	frames = 0;
}

Explosion::~Explosion() {
	glDeleteTextures(1, &texture_index);
}

void Explosion::draw() {
	glDisable(GL_LIGHTING);
	glEnable(GL_TEXTURE_2D);
    glBindTexture(GL_TEXTURE_2D, texture_index); 
	glEnable(GL_BLEND);//This is needed to make the cockpit see-through
	glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);
	GameObject* g = (GameObject*)gameObject;
	R3Matrix m = g->getFullTranslationMatrix();
	//Make sure the explosion is facing the player
	R3Camera* c = (R3Camera*)camera;
	R3Matrix rot(c->right[0], c->up[0], c->towards[0], 0,
				c->right[1], c->up[1], c->towards[1], 0,
				c->right[2], c->up[2], c->up[2], 0,
				0, 0, 0, 1);
	m = m * rot;
	double dim = g->node->bbox.DiagonalLength() * 3;
	glPushMatrix();
		glMultMatrixd((double*)&m.Transpose());
		glBegin(GL_QUADS);
	 		glTexCoord2f(0.0f,1.0f); glVertex3f(dim / 2, -dim / 2, 0);
			glTexCoord2f(1.0f,1.0f); glVertex3f(dim / 2, dim / 2, 0);
			glTexCoord2f(1.0f,0.0f); glVertex3f(-dim / 2, dim / 2, 0);
			glTexCoord2f(0.0f,0.0f); glVertex3f(-dim / 2, -dim / 2, 0);
		glEnd();
	glPopMatrix();
	glEnable(GL_LIGHTING);
}

void Explosion::updateTime(double dt) {
	t += dt;
	color = image->Explosion(t);
	frames++;
	if (frames % FRAME_WAIT == 0)
		updateImage();
}

//Copy new image to opengl's texture buffer
void Explosion::updateImage() {
	glBindTexture(GL_TEXTURE_2D, texture_index); 
	int npixels = image->NPixels();
	R2Pixel *pixels = image->Pixels();
	GLfloat *buffer = new GLfloat [4 * npixels];
	R2Pixel *pixelsp = pixels;
	GLfloat *bufferp = buffer;
	for (int j = 0; j < npixels; j++) { 
		*(bufferp++) = pixelsp->Red();
		*(bufferp++) = pixelsp->Green();
		*(bufferp++) = pixelsp->Blue();
		if (pixelsp->Luminance() == 0)
			*(bufferp++) = 0;
		else
			*(bufferp++) = pixelsp->Alpha();
		pixelsp++;
	}
	glTexImage2D(GL_TEXTURE_2D, 0, 4, width, height, 0, GL_RGBA, GL_FLOAT, buffer);
}