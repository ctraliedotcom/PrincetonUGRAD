#include "../R3Scene.h"

class R3Intersects {
public:
	R3Intersects(void);
	R3Intersects(double n, double f);
	void resetAll();
	void rayIntersectSphere(R3Ray* ray, R3Sphere* sphere);
	void rayIntersectBox(R3Ray* ray, R3Box* box);
	void rayIntersectTriMesh(R3Ray* ray, R3Mesh* mesh);
	void rayIntersectCylinder(R3Ray* ray, R3Cylinder* cylinder);
	void rayIntersectCone(R3Ray* ray, R3Cone* cone);
	void rayIntersectNode(R3Ray* ray, R3Node* node, R3Scene* scene, R3Matrix transforms);
	void rayIntersectScene(R3Ray* ray, R3Scene* scene);

	double neardist, fardist;
	bool intersects;
	R3Point position;
	R3Vector normal;
	double t;
	R3Node* intersectNode;
	R3Shape* hitShape;
	R3Matrix transform;
	R3MeshFace* intersectFace;//Used to find face that the tri mesh intersected
	bool dontclip;//True if ignoring neardist and fardist (e.g. shadowcheck, secondary rays)
	bool skipcheck;
	R3Node* skipNode;//Used to help with shadow / reflection (the ray shouldn't hit the object
	//it's leaving)
};