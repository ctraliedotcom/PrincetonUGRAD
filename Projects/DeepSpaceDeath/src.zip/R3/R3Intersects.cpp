#include "R3.h"

void R3Intersects::resetAll() {
	intersects = false;
	position = R3null_point;
	normal = R3null_vector;
	t = 0.0;
	neardist = 0.0;
	fardist = 0.0;
}

R3Intersects::R3Intersects() {
	resetAll();
}

R3Intersects::R3Intersects(double n, double f) {
	resetAll();
	neardist = n;
	fardist = f;
}

void R3Intersects::rayIntersectSphere(R3Ray* ray, R3Sphere* sphere) {
	R3Vector L = sphere->Center() - ray->Line().Point();
	double tca = L.Dot(ray->Line().Vector());
	double r = sphere->Radius();
	if (tca < 0)
		return;
	double dSquared = L.Dot(L) - tca*tca;
	if (dSquared > r*r)
		return;
	double thc = sqrt(r*r - dSquared);
	double t1 = tca - thc;
	double t2 = tca + thc;
	bool flipnormal = false;
	if (t1 > 0)
		t = t1;
	else if (t2 > 0) {
		flipnormal = true;
		t = t2;
	}
	if (t <= 0)
		return;
	intersects = true;
	position = ray->Line().Point() + t*ray->Line().Vector();
	normal = position - sphere->Center();
	normal.Normalize();
	if (flipnormal)
		normal = (-1) * normal;
}

//Return the t-value of plane intersection
double rayIntersectPlane(R3Ray* ray, R3Plane* plane) {
	double rayDotPlane = ray->Vector().Dot(plane->Normal());
	//Make sure that the ray would hit the plane on the + side
	if (rayDotPlane >= 0)
		return 0;
	R3Vector P0 = ray->Line().Point().Vector();
	double toReturn = -(P0.Dot(plane->Normal()) + plane->D());
	toReturn /= rayDotPlane;
	return toReturn;
}

//Helper function for rayIntersectTriangle and rayIntersectQuad
bool abovePlane(R3Point P, R3Point P0, R3Point T1, R3Point T2) {
	R3Vector V1 = T1 - P;
	R3Vector V2 = T2 - P;
	R3Vector N1 = V2 % V1;
	R3Vector Pchange = P - P0;
	if (Pchange.Dot(N1) < 0)
		return false;
	return true;
}

//Return the t-value of triangle intersection
//(Assume P1, P2, and P3 are in counter-clockwise order)
double rayIntersectTriangle(R3Ray* ray, R3Point P1, R3Point P2, R3Point P3) {
	R3Plane trianglePlane(P1, P2, P3);
	R3Point P0 = ray->Line().Point();
	double t1 = rayIntersectPlane(ray, &trianglePlane);
	if (t1 <= 0.0)
		return 0;
	R3Point P = P0 + t1*ray->Line().Vector();
	//Check to make sure point is inside of triangle
	if (!abovePlane(P, P0, P1, P2))
		return 0;
	if (!abovePlane(P, P0, P2, P3))
		return 0;
	if (!abovePlane(P, P0, P3, P1))
		return 0;
	return t1;
}

//Return the t-value of square intersection
//(Assume P1, P2, P3, and P4 are in counter-clockwise order)
double rayIntersectSquare(R3Ray* ray, R3Point P1, R3Point P2, R3Point P3, R3Point P4) {
	R3Plane squarePlane(P1, P2, P3);
	R3Point P0 = ray->Line().Point();
	double t1 = rayIntersectPlane(ray, &squarePlane);
	if (t1 <= 0.0)
		return 0;
	R3Point P = P0 + t1*ray->Line().Vector();
	//Check to make sure point is inside of triangle
	if (!abovePlane(P, P0, P1, P2))
		return 0;
	if (!abovePlane(P, P0, P2, P3))
		return 0;
	if (!abovePlane(P, P0, P3, P4))
		return 0;
	if (!abovePlane(P, P0, P4, P1))
		return 0;
	return t1;
}

bool insideBox(R3Ray* ray, R3Box* box) {
	R3Point P = ray->Line().Point();
	if (P.X() < box->XMin() || P.X() > box->XMax())
		return false;
	if (P.Y() < box->YMin() || P.Y() > box->YMax())
		return false;
	if (P.Z() < box->ZMin() || P.Z() > box->ZMax())
		return false;
	return true;
}

void R3Intersects::rayIntersectBox(R3Ray* ray, R3Box* box) {
	double xmin = box->XMin(), xmax = box->XMax();
	double ymin = box->YMin(), ymax = box->YMax();
	double zmin = box->ZMin(), zmax = box->ZMax();
	R3Point P1(xmin, ymin, zmin);
	R3Point P2(xmax, ymin, zmin);
	R3Point P3(xmax, ymin, zmax);
	R3Point P4(xmin, ymin, zmax);
	R3Point P5(xmin, ymax, zmin);
	R3Point P6(xmax, ymax, zmin);
	R3Point P7(xmax, ymax, zmax);
	R3Point P8(xmin, ymax, zmax);
	double tmin = 0;
	bool inside = insideBox(ray, box);
	if (inside)
		t = rayIntersectSquare(ray, P4, P3, P2, P1);
	else
		t = rayIntersectSquare(ray, P1, P2, P3, P4);
	if (t > 0 && (t < tmin || tmin == 0)) {
		tmin = t;
		normal = (P2 - P1) % (P3 - P2);
	}
	if (inside)
		t = rayIntersectSquare(ray, P3, P7, P6, P2);
	else
		t = rayIntersectSquare(ray, P2, P6, P7, P3);
	if (t > 0 && (t < tmin || tmin == 0)) {
		tmin = t;
		normal = (P6 - P2) % (P7 - P6);
	}
	if (inside)
		t = rayIntersectSquare(ray, P8, P7, P3, P4);
	else
		t = rayIntersectSquare(ray, P4, P3, P7, P8);
	if (t > 0 && (t < tmin || tmin == 0)) {
		tmin = t;
		normal = (P3 - P4) % (P7 - P3);
	}
	if (inside)
		t = rayIntersectSquare(ray, P7, P8, P5, P6);
	else
		t = rayIntersectSquare(ray, P6, P5, P8, P7);
	if (t > 0 && (t < tmin || tmin == 0)) {
		tmin = t;
		normal = (P5 - P6) % (P8 - P5);
	}
	if (inside)
		t = rayIntersectSquare(ray, P8, P4, P1, P5);
	else
		t = rayIntersectSquare(ray, P5, P1, P4, P8);
	if (t > 0 && (t < tmin || tmin == 0)) {
		tmin = t;
		normal = (P1 - P5) % (P4 - P1);
	}
	if (inside)
		t = rayIntersectSquare(ray, P6, P5, P1, P2);
	else
		t = rayIntersectSquare(ray, P2, P1, P5, P6);
	if (t > 0 && (t < tmin || tmin == 0)) {
		tmin = t;
		normal = (P1 - P2) % (P5 - P1);
	}
	t = tmin;
	if (t <= 0)
		return;
	intersects = true;
	position = ray->Line().Point() + t*ray->Line().Vector();
	normal.Normalize();
	if (inside)
		normal = normal * (-1);
}

void R3Intersects::rayIntersectCylinder(R3Ray* ray, R3Cylinder* cylinder) {
	R3Ray tempRay = *ray;
	double r = cylinder->Radius();
	R3Vector H(0, cylinder->Height() / 2.0, 0);
	//First check to see if the ray would intersect the top or bottom of the cylinder
	if (ray->Line().Point().Y() > (cylinder->Center() + H).Y()) {
		//It could intersect along the top in this case
		R3Vector n(0, 1, 0);
		R3Plane plane(cylinder->Center() + H, n);
		double tc = rayIntersectPlane(ray, &plane);
		if (tc > 0) {
			R3Point PC = ray->Line().Point() + tc * ray->Line().Vector();
			R3Vector dPC = PC - cylinder->Center();
			if (dPC.X()*dPC.X() + dPC.Z()*dPC.Z() < r*r) {//Then it's within the circle
				intersects = true;
				t = tc;
				normal = n;
				position = PC;
				return;
			}
		}
	}
	else if (ray->Line().Point().Y() < (cylinder->Center() - H).Y()) {
		//It could intersect along the bottom in this case
		R3Vector n(0, -1, 0);
		R3Plane plane(cylinder->Center() - H, n);
		double tc = rayIntersectPlane(ray, &plane);
		if (tc > 0) {
			R3Point PC = ray->Line().Point() + tc * ray->Line().Vector();
			R3Vector dPC = PC - cylinder->Center();
			if (dPC.X()*dPC.X() + dPC.Z()*dPC.Z() < r*r) {//Then it's within the circle
				intersects = true;
				t = tc;
				normal = n;
				position = PC;
				return;
			}
		}
	}
	//Now check for collisions along the curved part of the cylinder
	R3Vector V = tempRay.Line().Vector();
	R3Vector L = cylinder->Center() - ray->Line().Point();
	V.SetY(0);
	L.SetY(0);
	double VLength = V.Length();
	double tca = L.Dot(V) / VLength;
	if (tca < 0)
		return;
	double dSquared = L.Dot(L) - tca*tca;
	if (dSquared > r*r)
		return;
	double thc = sqrt(r*r - dSquared);
	//Need to rescale t going back to 3D from 2D
	t = (tca - thc) * VLength / V.Dot(ray->Line().Vector());
	bool flipnormal = false;
	if (t < 0) {
		t = (tca + thc) * VLength / V.Dot(ray->Line().Vector());
		flipnormal = true;
	}
	position = ray->Line().Point() + t*ray->Line().Vector();
	if (position.Y() > (cylinder->Center() + H).Y() ||
		position.Y() < (cylinder->Center() - H).Y()) {
		position = R3null_point;
		t = 0;
		return;
	}
	intersects = true;
	normal = position - cylinder->Center();
	normal.SetY(0);
	normal.Normalize();
	if (flipnormal)
		normal = (-1) * normal;
}

void R3Intersects::rayIntersectCone(R3Ray* ray, R3Cone* cone) {
	R3Ray tempRay = *ray;
	double r = cone->Radius();
	double h = cone->Height();
	R3Vector H(0, cone->Height() / 2.0, 0);
	//First check to see if the ray would intersect bottom of the cone
	if (ray->Line().Point().Y() < (cone->Center() - H).Y()) {
		R3Vector n(0, -1, 0);
		R3Plane plane(cone->Center() - H, n);
		double tc = rayIntersectPlane(ray, &plane);
		if (tc > 0) {
			R3Point PC = ray->Line().Point() + tc * ray->Line().Vector();
			R3Vector dPC = PC - cone->Center();
			if (dPC.X()*dPC.X() + dPC.Z()*dPC.Z() < r*r) {//Then it's within the circle
				intersects = true;
				t = tc;
				normal = n;
				position = PC;
				return;
			}
		}
	}
	R3Vector V = ray->Line().Vector();
	R3Point P = ray->Line().Point();
	//Solve the quadratic equation for a cone
	double k = r / h;
	double yk = P.Y() - (cone->Center().Y() + cone->Height()/2);
	double a = V.X()*V.X() + V.Z()*V.Z() - k*k*V.Y()*V.Y();
	double b = 2*(V.X()*P.X() + V.Z()*P.Z() - k*k*yk*V.Y());
	double c = P.X()*P.X() + P.Z()*P.Z() - k*k*yk*yk;
	double discrim = b*b - 4*a*c;
	if (discrim < 0)
		return;
	bool flipnormal = false;
	t = (-b - sqrt(discrim)) / (2*a);
	if (t <= 0) {
		t = (-b + sqrt(discrim)) / (2*a);
		flipnormal = true;
	}
	if (t <= 0) {
		t = 0;
		return;
	}
	R3Point temp = P + t*V;
	if (temp.Y() > (cone->Center() + H).Y() ||
		temp.Y() < (cone->Center() - H).Y()) {
		t = 0;
		return;
	}
	intersects = true;
	position = temp;
	normal = position - cone->Center();
	double magXZSquared = normal.X()*normal.X() + normal.Z()*normal.Z();
	normal.SetY(sqrt(magXZSquared) * r/h);
	normal.Normalize();
	if (flipnormal)
		normal = (-1) * normal;
}


void R3Intersects::rayIntersectTriMesh(R3Ray* ray, R3Mesh* mesh) {
	double tmin = t;
	//Loop through all of the faces (inefficient)
	for (int i = 0; i < mesh->NFaces(); i++) {
		R3MeshFace* face = mesh->faces[i];
		R3Vector n = face->plane.Normal();
		t = rayIntersectTriangle(ray, face->vertices[0]->position, 
			face->vertices[1]->position, face->vertices[2]->position);
		if (t <= 0) { //Check other side of triangle
			t = rayIntersectTriangle(ray, face->vertices[2]->position, 
				face->vertices[1]->position, face->vertices[0]->position);	
			n = (-1) * n;
		}
		if (t > 0 && (t < tmin || tmin == 0)) {
			tmin = t;
			normal = n;
			intersectFace = face;
		}
	}
	intersects = false;
	if (tmin > 0) {
		t = tmin;
		intersects = true;
		position = ray->Line().Point() + t*ray->Line().Vector();
		normal.Normalize();
	}
}

//Move the normal, position, and t value back into the original coordinate frame
void recomputeValues(R3Intersects* temp, R3Matrix transforms, R3Ray* ray) {
	//Pick another point at an offset of the normal from the position intersection
	//and transform this point and the intersection point.  This will help
	//place the normal when the values are transformed back
	R3Point PN2 = temp->position + temp->normal;
	PN2 = transforms * PN2;
	temp->position = transforms*temp->position;
	temp->normal = PN2 - temp->position;
	temp->normal.Normalize();
	R3Vector V = ray->Line().Point() - temp->position;
	temp->t = V.Length();
}

//The recursive helper function for rayIntersectScene
//transforms is the product of all matrices that have been applied so far
void R3Intersects::rayIntersectNode(R3Ray* ray, R3Node* node, R3Scene* scene,
									R3Matrix transforms) {
	if (skipcheck && node == skipNode) {
		return;
	}
	R3Matrix nextTransforms = transforms * node->transformation;//Multiply on the right
	R3Matrix inverse = nextTransforms.Inverse();
	R3Ray transformedRay = *ray;
	transformedRay.Transform(inverse);
	
	//Bounding box check (do for all but boxes)
	if (!(node->shape != NULL && node->shape->type == R3_BOX_SHAPE)) {
		R3Ray bboxRay = *ray;
		bboxRay.Transform(transforms.Inverse());
		R3Box bbox = node->bbox;
		R3Intersects bboxtest(0, 0);
		bboxtest.rayIntersectBox(&bboxRay, &bbox);
		if (bboxtest.intersects == false || (bboxtest.t > t && t > 0))
			return;
	}

	for (int i = 0; i < node->children.size(); i++) {
		rayIntersectNode(ray, node->children[i], scene, nextTransforms);//Recursive step
	}
	R3Shape* shape = node->shape;
	if (shape == NULL) {
		return;
	}
	//Create a temporary intersects variable, and check to see if its t value
	//is less than the t value encountered so far
	R3Intersects temp(neardist, fardist);
	if (shape->type == R3_BOX_SHAPE) {
		temp.rayIntersectBox(&transformedRay, shape->box);
	}
	else if (shape->type == R3_SPHERE_SHAPE) {
		temp.rayIntersectSphere(&transformedRay, shape->sphere);
	}
	else if (shape->type == R3_MESH_SHAPE) {
		temp.rayIntersectTriMesh(&transformedRay, shape->mesh);
	}
	else if (shape->type == R3_CYLINDER_SHAPE) {
		temp.rayIntersectCylinder(&transformedRay, shape->cylinder);
	}
	else if (shape->type == R3_CONE_SHAPE) {
		temp.rayIntersectCone(&transformedRay, shape->cone);
	}
	if(temp.intersects)
		recomputeValues(&temp, transforms, ray);
	else
		return;
	//Used to help calculate view frustrum distance
	double scale = scene->Camera().towards.Dot(ray->Line().Vector());
	if ((temp.t < t || (t == 0 && temp.t > 0)) && (dontclip || temp.t*scale > neardist
		&& temp.t*scale < fardist)) {
		//A new shortest ray intersection has been found
		intersects = true;
		t = temp.t;
		position = temp.position;
		normal = temp.normal;
		intersectNode = node;
		hitShape = shape;
		transform = nextTransforms;
		intersectFace = temp.intersectFace;
	}
}

void R3Intersects::rayIntersectScene(R3Ray* ray, R3Scene* scene) {
	rayIntersectNode(ray, scene->Root(), scene, R3identity_matrix);
}